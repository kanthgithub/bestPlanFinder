function IntroModule(headerColor, backgroundColor)
{
	this.asset = new lib.ModuleIntro();
	
	var logo = this.asset.logo;
	var background = this.asset.background;
	var header = this.asset.header;
	
	Utils.SetColor(logo, backgroundColor);
	Utils.SetColor(background, backgroundColor);
	Utils.SetColor(header, headerColor);
}