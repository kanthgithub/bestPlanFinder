(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes

// library properties:
lib.properties = {
	width: 728,
	height: 90,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Frame01728x90.png?1517881323947", id:"Frame01728x90"},
		{src:"images/Frame02728x90.png?1517881323947", id:"Frame02728x90"},
		{src:"images/Frame03728x90.png?1517881323947", id:"Frame03728x90"},
		{src:"images/Frame04728x90.png?1517881323947", id:"Frame04728x90"},
		{src:"images/Frame05728x90.png?1517881323947", id:"Frame05728x90"},
		{src:"images/Referral728x90.png?1517881323947", id:"Referral728x90"},
		{src:"images/TXT01728x90.png?1517881323947", id:"TXT01728x90"},
		{src:"images/TXT02728x90.png?1517881323947", id:"TXT02728x90"},
		{src:"images/TXT03728x90.png?1517881323947", id:"TXT03728x90"},
		{src:"images/TXT04728x90.png?1517881323947", id:"TXT04728x90"},
		{src:"images/TXT05728x90.png?1517881323947", id:"TXT05728x90"}
	]
};



lib.ssMetadata = [];


// symbols:



(lib.Frame01728x90 = function() {
	this.initialize(img.Frame01728x90);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1456,180);


(lib.Frame02728x90 = function() {
	this.initialize(img.Frame02728x90);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1456,180);


(lib.Frame03728x90 = function() {
	this.initialize(img.Frame03728x90);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1456,180);


(lib.Frame04728x90 = function() {
	this.initialize(img.Frame04728x90);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1456,180);


(lib.Frame05728x90 = function() {
	this.initialize(img.Frame05728x90);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1456,180);


(lib.Referral728x90 = function() {
	this.initialize(img.Referral728x90);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1456,180);


(lib.TXT01728x90 = function() {
	this.initialize(img.TXT01728x90);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1456,180);


(lib.TXT02728x90 = function() {
	this.initialize(img.TXT02728x90);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1456,180);


(lib.TXT03728x90 = function() {
	this.initialize(img.TXT03728x90);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1456,180);


(lib.TXT04728x90 = function() {
	this.initialize(img.TXT04728x90);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1456,180);


(lib.TXT05728x90 = function() {
	this.initialize(img.TXT05728x90);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1456,180);


(lib.mctxt05 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib.TXT05728x90();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,728,90);


(lib.mctxt04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib.TXT04728x90();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,728,90);


(lib.mctxt03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib.TXT03728x90();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,728,90);


(lib.mctxt02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib.TXT02728x90();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.instance_1 = new lib.TXT02728x90();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0,0.003);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,728,90);


(lib.mctxt01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib.TXT01728x90();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,728,90);


(lib.mcreferral = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Referral728x90();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1456,180);


(lib.mcframe05 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Frame05728x90();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1456,180);


(lib.mcframe04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Frame04728x90();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1456,180);


(lib.mcframe03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Frame03728x90();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1456,180);


(lib.mcframe02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Frame02728x90();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1456,180);


(lib.mcframe01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Frame01728x90();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1456,180);


(lib.mcbgwhite = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,728,90);


(lib.btntext = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAXA3IgXhHIAAAAIgWBHIgVAAIgehtIAZAAIARBLIAAAAIAXhLIARAAIAXBMIABAAIAQhMIAZAAIgfBtg");
	this.shape.setTransform(159.1,12);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgkApQgNgPAAgZIAAgBQAAgYANgQQAOgQAWAAQAXAAAOAQQANAQAAAYIAAABQAAAZgNAPQgOAQgXAAQgWAAgOgQgAgSgZQgHAJABAQIAAABQgBAQAHAKQAGAKAMABQANgBAGgKQAHgKgBgQIAAgBQABgQgHgJQgGgLgNAAQgMAAgGALg");
	this.shape_1.setTransform(145,12);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAhBKIhAhpIgBAAIAABpIgZAAIAAiTIAZAAIBABqIABgBIAAhpIAZAAIAACTg");
	this.shape_2.setTransform(131.3,10);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAVA4IAAhDQAAgNgFgFQgFgGgKABQgGAAgGADQgFACgEAGIAABPIgZAAIAAhtIAWAAIACAQQAGgIAIgFQAHgFAJAAQARAAALALQAJAKAAAXIAABDg");
	this.shape_3.setTransform(112,11.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgLBPIAAhtIAXAAIAABtgAgLg5IAAgVIAXAAIAAAVg");
	this.shape_4.setTransform(102.9,9.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgkApQgNgPAAgZIAAgBQAAgYANgQQAOgQAWAAQAXAAAOAQQANAQAAAYIAAABQAAAZgNAPQgOAQgXAAQgWAAgOgQgAgSgZQgHAJAAAQIAAABQAAAQAHAKQAGAKAMABQANgBAGgKQAGgKAAgQIAAgBQAAgQgGgJQgGgLgNAAQgMAAgGALg");
	this.shape_5.setTransform(93.9,12);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AghBAQgNgLAAgWIABAAIAYAAQAAAMAGAGQAGAHAJAAQAJAAAHgIQAGgHAAgNIAAhmIAZAAIAABmQAAAWgNANQgOAMgUAAQgUAAgNgLg");
	this.shape_6.setTransform(81.3,10.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(74,-4,95.5,28.7);


(lib.btnshape = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#5686DC").s().p("AJVDKIgqAAIyIAAQgcAAAAgbIAAldQAAgbAcAAISIAAIAzAAQAcAAAAAbIAAFHIAAAWQAAAbgcAAg");
	this.shape.setTransform(128.5,18.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(65.1,-1.8,126.9,40.6);


(lib.ctaBTN = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0033FF").s().p("A3bTiMAAAgnDMAu2AAAMAAAAnDg");
	this.shape.setTransform(150,125);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.clickBTN = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0033FF").s().p("EgJXAu4MAAAhdvISuAAMAAABdvg");
	this.shape.setTransform(60,300);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.CTA = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{Pause:0,Over:1,Out:13});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_12 = function() {
		this.stop();
	}
	this.frame_24 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(12).call(this.frame_12).wait(12).call(this.frame_24).wait(1));

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0)").s().p("AJVDKIgqAAIyIAAQgcAAAAgbIAAldQAAgbAcAAISIAAIAzAAQAcAAAAAbIAAFHIAAAWQAAAbgcAAg");
	this.shape.setTransform(251.5,-45.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.055)").s().p("ApdDKQgcAAAAgbIAAldQAAgbAcAAIS7AAQAcAAAAAbIAAFdQAAAbgcAAg");
	this.shape_1.setTransform(251.5,-45.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.106)").s().p("ApdDKQgcAAAAgbIAAldQAAgbAcAAIS7AAQAcAAAAAbIAAFdQAAAbgcAAg");
	this.shape_2.setTransform(251.5,-45.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.153)").s().p("ApdDKQgcAAAAgbIAAldQAAgbAcAAIS7AAQAcAAAAAbIAAFdQAAAbgcAAg");
	this.shape_3.setTransform(251.5,-45.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.192)").s().p("ApdDKQgcAAAAgbIAAldQAAgbAcAAIS7AAQAcAAAAAbIAAFdQAAAbgcAAg");
	this.shape_4.setTransform(251.5,-45.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.224)").s().p("ApdDKQgcAAAAgbIAAldQAAgbAcAAIS7AAQAcAAAAAbIAAFdQAAAbgcAAg");
	this.shape_5.setTransform(251.5,-45.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.251)").s().p("ApdDKQgcAAAAgbIAAldQAAgbAcAAIS7AAQAcAAAAAbIAAFdQAAAbgcAAg");
	this.shape_6.setTransform(251.5,-45.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,255,255,0.271)").s().p("ApdDKQgcAAAAgbIAAldQAAgbAcAAIS7AAQAcAAAAAbIAAFdQAAAbgcAAg");
	this.shape_7.setTransform(251.5,-45.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(255,255,255,0.286)").s().p("ApdDKQgcAAAAgbIAAldQAAgbAcAAIS7AAQAcAAAAAbIAAFdQAAAbgcAAg");
	this.shape_8.setTransform(251.5,-45.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,255,255,0.294)").s().p("ApdDKQgcAAAAgbIAAldQAAgbAcAAIS7AAQAcAAAAAbIAAFdQAAAbgcAAg");
	this.shape_9.setTransform(251.5,-45.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0.298)").s().p("ApdDKQgcAAAAgbIAAldQAAgbAcAAIS7AAQAcAAAAAbIAAFdQAAAbgcAAg");
	this.shape_10.setTransform(251.5,-45.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(255,255,255,0.247)").s().p("ApdDKQgcAAAAgbIAAldQAAgbAcAAIS7AAQAcAAAAAbIAAFdQAAAbgcAAg");
	this.shape_11.setTransform(251.5,-45.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(255,255,255,0.2)").s().p("ApdDKQgcAAAAgbIAAldQAAgbAcAAIS7AAQAcAAAAAbIAAFdQAAAbgcAAg");
	this.shape_12.setTransform(251.5,-45.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(255,255,255,0.157)").s().p("ApdDKQgcAAAAgbIAAldQAAgbAcAAIS7AAQAcAAAAAbIAAFdQAAAbgcAAg");
	this.shape_13.setTransform(251.5,-45.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0.122)").s().p("ApdDKQgcAAAAgbIAAldQAAgbAcAAIS7AAQAcAAAAAbIAAFdQAAAbgcAAg");
	this.shape_14.setTransform(251.5,-45.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(255,255,255,0.09)").s().p("ApdDKQgcAAAAgbIAAldQAAgbAcAAIS7AAQAcAAAAAbIAAFdQAAAbgcAAg");
	this.shape_15.setTransform(251.5,-45.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(255,255,255,0.063)").s().p("ApdDKQgcAAAAgbIAAldQAAgbAcAAIS7AAQAcAAAAAbIAAFdQAAAbgcAAg");
	this.shape_16.setTransform(251.5,-45.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(255,255,255,0.039)").s().p("ApdDKQgcAAAAgbIAAldQAAgbAcAAIS7AAQAcAAAAAbIAAFdQAAAbgcAAg");
	this.shape_17.setTransform(251.5,-45.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(255,255,255,0.024)").s().p("ApdDKQgcAAAAgbIAAldQAAgbAcAAIS7AAQAcAAAAAbIAAFdQAAAbgcAAg");
	this.shape_18.setTransform(251.5,-45.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(255,255,255,0.012)").s().p("ApdDKQgcAAAAgbIAAldQAAgbAcAAIS7AAQAcAAAAAbIAAFdQAAAbgcAAg");
	this.shape_19.setTransform(251.5,-45.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0.004)").s().p("ApdDKQgcAAAAgbIAAldQAAgbAcAAIS7AAQAcAAAAAbIAAFdQAAAbgcAAg");
	this.shape_20.setTransform(251.5,-45.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape}]},1).wait(1));

	// Layer 5
	this.instance = new lib.btntext();
	this.instance.parent = this;
	this.instance.setTransform(202.7,-46.1,1,1,0,0,0,71.7,10.9);

	this.instance_1 = new lib.btnshape();
	this.instance_1.parent = this;
	this.instance_1.setTransform(213,-47,1,1,0,0,0,90,17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(25));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(188.1,-65.8,126.9,40.6);


// stage content:



(lib.GSuite_Referral_EN_HTML5_728x90 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{Intro:1});

	// timeline functions:
	this.frame_0 = function() {
		var root = this;
		this.loopCount = 1;
		
		//turns mouse pointer into hand
		this.clickBTN.cursor = "pointer";
		this.ctaBTN.cursor = "pointer";
		
		//listens for click event and calls click function
		this.ctaBTN.addEventListener("click", CallClickTag.bind(this));
		this.clickBTN.addEventListener("click", CallClickTag.bind(this));
		
		//click function
		function CallClickTag() {
		 Enabler.exit('Main_Clickthrough');
		}
			
		//stage.enableMouseOver();
		
		this.ctaBTN.addEventListener("mouseover", CallMouseOver.bind(this));
		
		function CallMouseOver()
		{
			this.CTA.gotoAndPlay("Over");
		}
		
		this.ctaBTN.addEventListener("mouseout", CallMouseOut.bind(this));
		
		function CallMouseOut()
		{
			this.CTA.gotoAndPlay("Out");
		}
	}
	this.frame_430 = function() {
		if(!this.alreadyExecuted){
		this.alreadyExecuted=true;
		this.loopNum=1;
		} else {
		this.loopNum++;
		if(this.loopNum==2){
		this.stop();
		}
		}
		
		//this.stop();
	}
	this.frame_448 = function() {
		this.gotoAndPlay("Intro");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(430).call(this.frame_430).wait(18).call(this.frame_448).wait(1));

	// ctaBTN
	this.ctaBTN = new lib.ctaBTN();
	this.ctaBTN.parent = this;
	this.ctaBTN.setTransform(143,271,0.7,0.2);
	new cjs.ButtonHelper(this.ctaBTN, 0, 1, 2, false, new lib.ctaBTN(), 3);

	this.timeline.addTween(cjs.Tween.get(this.ctaBTN).wait(348).to({regX:0.5,regY:0.6,scaleX:0.44,scaleY:0.18,x:208.1,y:21.3},0).wait(87).to({regX:0.1,regY:0.4,scaleX:0.29,scaleY:0.36,x:-93.9,y:89.8},0).wait(14));

	// clickBTN
	this.clickBTN = new lib.clickBTN();
	this.clickBTN.parent = this;
	this.clickBTN.setTransform(910,18.8,6.067,0.15,0,0,0,150,125);
	new cjs.ButtonHelper(this.clickBTN, 0, 1, 2, false, new lib.clickBTN(), 3);

	this.timeline.addTween(cjs.Tween.get(this.clickBTN).wait(449));

	// CTA
	this.CTA = new lib.CTA();
	this.CTA.parent = this;
	this.CTA.setTransform(142.2,199.6,1,1,0,0,0,65.3,14.8);
	this.CTA.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.CTA).wait(338).to({x:86.3,y:95.8},0).to({y:105.8,alpha:1},10,cjs.Ease.get(1)).wait(87).to({alpha:0},11,cjs.Ease.get(-1)).wait(3));

	// TXT05
	this.instance = new lib.mctxt05();
	this.instance.parent = this;
	this.instance.setTransform(144,59.5,1,1,0,0,0,134,59.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(269).to({_off:false},0).to({x:134,alpha:1},5,cjs.Ease.get(1)).wait(54).to({alpha:0},10,cjs.Ease.get(-1)).to({_off:true},1).wait(110));

	// TXT04
	this.instance_1 = new lib.mctxt04();
	this.instance_1.parent = this;
	this.instance_1.setTransform(144,59.5,1,1,0,0,0,134,59.5);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(210).to({_off:false},0).to({x:134,alpha:1},5,cjs.Ease.get(1)).wait(49).to({x:124,alpha:0},5,cjs.Ease.get(-1)).to({_off:true},1).wait(179));

	// TXT03
	this.instance_2 = new lib.mctxt03();
	this.instance_2.parent = this;
	this.instance_2.setTransform(144,59.5,1,1,0,0,0,134,59.5);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(151).to({_off:false},0).to({x:134,alpha:1},5,cjs.Ease.get(1)).wait(49).to({x:124,alpha:0},5,cjs.Ease.get(-1)).to({_off:true},1).wait(238));

	// TXT02
	this.instance_3 = new lib.mctxt02();
	this.instance_3.parent = this;
	this.instance_3.setTransform(154,59.5,1,1,0,0,0,134,59.5);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(87).to({_off:false},0).to({x:134,alpha:1},10,cjs.Ease.get(1)).wait(49).to({x:124,alpha:0},5,cjs.Ease.get(-1)).to({_off:true},1).wait(297));

	// TXT01
	this.instance_4 = new lib.mctxt01();
	this.instance_4.parent = this;
	this.instance_4.setTransform(134,49.5,1,1,0,0,0,134,59.5);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(10).to({_off:false},0).to({y:59.5,alpha:1},9,cjs.Ease.get(1)).wait(58).to({alpha:0},10,cjs.Ease.get(-1)).to({_off:true},1).wait(361));

	// Frame05
	this.instance_5 = new lib.mcframe05();
	this.instance_5.parent = this;
	this.instance_5.setTransform(160,125,0.5,0.5,0,0,0,300,250);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(274).to({_off:false},0).to({x:150,alpha:1},5,cjs.Ease.get(1)).wait(49).to({alpha:0},10,cjs.Ease.get(-1)).to({_off:true},1).wait(110));

	// Frame04
	this.instance_6 = new lib.mcframe04();
	this.instance_6.parent = this;
	this.instance_6.setTransform(160,125,0.5,0.5,0,0,0,300,250);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(215).to({_off:false},0).to({x:150,alpha:1},5,cjs.Ease.get(1)).wait(49).to({x:140,alpha:0},5,cjs.Ease.get(-1)).to({_off:true},1).wait(174));

	// Frame03
	this.instance_7 = new lib.mcframe03();
	this.instance_7.parent = this;
	this.instance_7.setTransform(160,125,0.5,0.5,0,0,0,300,250);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(156).to({_off:false},0).to({x:150,alpha:1},5,cjs.Ease.get(1)).wait(49).to({x:140,alpha:0},5,cjs.Ease.get(-1)).to({_off:true},1).wait(233));

	// Frame02
	this.instance_8 = new lib.mcframe02();
	this.instance_8.parent = this;
	this.instance_8.setTransform(170,125,0.5,0.5,0,0,0,300,250);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(92).to({_off:false},0).to({x:150,alpha:1},10,cjs.Ease.get(1)).wait(49).to({x:140,alpha:0},5,cjs.Ease.get(-1)).to({_off:true},1).wait(292));

	// Frame01
	this.instance_9 = new lib.mcframe01();
	this.instance_9.parent = this;
	this.instance_9.setTransform(150,125,0.5,0.5,0,0,0,300,250);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(1).to({_off:false},0).to({alpha:1},9,cjs.Ease.get(1)).wait(67).to({alpha:0},10,cjs.Ease.get(-1)).to({_off:true},1).wait(361));

	// GSuiteReferral
	this.instance_10 = new lib.mcreferral();
	this.instance_10.parent = this;
	this.instance_10.setTransform(150,125,0.5,0.5,0,0,0,300,250);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(449));

	// BG-white
	this.instance_11 = new lib.mcbgwhite();
	this.instance_11.parent = this;
	this.instance_11.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(449));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(364,45,728,321.1);

})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var lib, images, createjs, ss;