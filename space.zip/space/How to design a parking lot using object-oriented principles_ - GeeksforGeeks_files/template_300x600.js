(function (lib, img, cjs, ss, an) {

var p; // shortcut to reference prototypes
lib.ssMetadata = [];


// symbols:



(lib._300x600_balcony = function() {
	this.initialize(img._300x600_balcony);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,303,97);


(lib._300x600_chair = function() {
	this.initialize(img._300x600_chair);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,391,612);


(lib._300x600_chairText = function() {
	this.initialize(img._300x600_chairText);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,147,80);


(lib._300x600_sitArm = function() {
	this.initialize(img._300x600_sitArm);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,50,229);


(lib._300x600_sitBag = function() {
	this.initialize(img._300x600_sitBag);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,153,167);


(lib._300x600_sitChest2 = function() {
	this.initialize(img._300x600_sitChest2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,228,334);


(lib._300x600_sitChest3 = function() {
	this.initialize(img._300x600_sitChest3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,228,334);


(lib._300x600_sitChest4 = function() {
	this.initialize(img._300x600_sitChest4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,228,334);


(lib._300x600_sitEar = function() {
	this.initialize(img._300x600_sitEar);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,10,19);


(lib._300x600_sitFace = function() {
	this.initialize(img._300x600_sitFace);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,54,79);


(lib._300x600_sitForearm = function() {
	this.initialize(img._300x600_sitForearm);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,129,38);


(lib._300x600_sitGlasses = function() {
	this.initialize(img._300x600_sitGlasses);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,59,21);


(lib._300x600_sitHair = function() {
	this.initialize(img._300x600_sitHair);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,70,75);


(lib._300x600_sitHairWick1 = function() {
	this.initialize(img._300x600_sitHairWick1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,53,55);


(lib._300x600_sitHairWick2 = function() {
	this.initialize(img._300x600_sitHairWick2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,33,24);


(lib._300x600_sitHairWick3 = function() {
	this.initialize(img._300x600_sitHairWick3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,21,54);


(lib._300x600_sitHand = function() {
	this.initialize(img._300x600_sitHand);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,86,42);


(lib._300x600_sitHeadband = function() {
	this.initialize(img._300x600_sitHeadband);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,67,26);


(lib._300x600_sitLeg = function() {
	this.initialize(img._300x600_sitLeg);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,113,154);


(lib._300x600_sitMouth1 = function() {
	this.initialize(img._300x600_sitMouth1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4,4);


(lib._300x600_sitMouth2 = function() {
	this.initialize(img._300x600_sitMouth2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,15,5);


(lib._300x600_sitMouth3a = function() {
	this.initialize(img._300x600_sitMouth3a);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,15,4);


(lib._300x600_sitMouth3b = function() {
	this.initialize(img._300x600_sitMouth3b);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,17,4);


(lib._300x600_sitNeck = function() {
	this.initialize(img._300x600_sitNeck);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,42,49);


(lib._300x600_sitNeckShadow = function() {
	this.initialize(img._300x600_sitNeckShadow);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,26,28);


(lib._300x600_sitNose = function() {
	this.initialize(img._300x600_sitNose);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,9,10);


(lib._300x600_sitSkirt = function() {
	this.initialize(img._300x600_sitSkirt);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,119,117);


(lib._300x600_walkKneeBack = function() {
	this.initialize(img._300x600_walkKneeBack);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,10,27);


(lib._300x600_walkKneeFront = function() {
	this.initialize(img._300x600_walkKneeFront);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,10,27);


(lib._300x600_walkThighBack = function() {
	this.initialize(img._300x600_walkThighBack);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,86,171);


(lib._300x600_walkThighFront = function() {
	this.initialize(img._300x600_walkThighFront);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,86,171);


(lib._300x600_walkTibiaBack = function() {
	this.initialize(img._300x600_walkTibiaBack);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,56,206);


(lib._300x600_walkTibiaFront = function() {
	this.initialize(img._300x600_walkTibiaFront);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,56,206);


(lib._pixel_hack_dont_remove_ = function() {
	this.initialize(img._pixel_hack_dont_remove_);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1,1);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.textReserved = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("RÉSERVÉ", "bold 18px 'Excellence In Motion V2'");
	this.text.name = "text";
	this.text.textAlign = "center";
	this.text.lineHeight = 23;
	this.text.lineWidth = 534;
	this.text.parent = this;
	this.text.setTransform(269,2);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = getMCSymbolPrototype(lib.textReserved, new cjs.Rectangle(0,0,538.1,25), null);


(lib.textAnimationPlace2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("RÉSERVEZ VITE !", "bold 26px 'Excellence In Motion V2'");
	this.text.name = "text";
	this.text.textAlign = "center";
	this.text.lineHeight = 32;
	this.text.lineWidth = 596;
	this.text.parent = this;
	this.text.setTransform(300,2);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = getMCSymbolPrototype(lib.textAnimationPlace2, new cjs.Rectangle(0,0,600,34.3), null);


(lib.textAnimationPlace1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("CHIC !\nIL EN RESTE UNE !\nET DEMAIN ?", "bold 26px 'Excellence In Motion V2'");
	this.text.name = "text";
	this.text.textAlign = "center";
	this.text.lineHeight = 32;
	this.text.lineWidth = 596;
	this.text.parent = this;
	this.text.setTransform(300,2);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = getMCSymbolPrototype(lib.textAnimationPlace1, new cjs.Rectangle(0,0,600,98.9), null);


(lib.text_priceEndshot_title = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("NEW YORK", "bold 26px 'Excellence In Motion V2'");
	this.text.name = "text";
	this.text.textAlign = "center";
	this.text.lineHeight = 32;
	this.text.lineWidth = 1174;
	this.text.parent = this;
	this.text.setTransform(0,-12);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = getMCSymbolPrototype(lib.text_priceEndshot_title, new cjs.Rectangle(-589,-14,1178.1,34.3), null);


(lib.text_price_title = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("NEW YORK", "bold 30px 'Excellence In Motion V2'");
	this.text.name = "text";
	this.text.textAlign = "center";
	this.text.lineHeight = 37;
	this.text.lineWidth = 596;
	this.text.parent = this;
	this.text.setTransform(0,-18);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = getMCSymbolPrototype(lib.text_price_title, new cjs.Rectangle(-300,-20,600,39), null);


(lib.text_price_price = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("570", "bold 46px 'Excellence In Motion V2'");
	this.text.name = "text";
	this.text.textAlign = "right";
	this.text.lineHeight = 56;
	this.text.lineWidth = 287;
	this.text.parent = this;
	this.text.setTransform(-2,-28);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = getMCSymbolPrototype(lib.text_price_price, new cjs.Rectangle(-291,-30,291,57.6), null);


(lib.text_price_fromPrice = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("From", "bold 12px 'Excellence In Motion V2'");
	this.text.name = "text";
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 596;
	this.text.parent = this;
	this.text.setTransform(0,-5.6);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = getMCSymbolPrototype(lib.text_price_fromPrice, new cjs.Rectangle(-300,-7.6,600,18), null);


(lib.text_price_from = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("AU DÉPART DE AMSTERDAM", "bold 16px 'Excellence In Motion V2'");
	this.text.name = "text";
	this.text.textAlign = "center";
	this.text.lineHeight = 21;
	this.text.lineWidth = 596;
	this.text.parent = this;
	this.text.setTransform(0,-10);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = getMCSymbolPrototype(lib.text_price_from, new cjs.Rectangle(-300,-12,600,22.7), null);


(lib.text_price_currency = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("€", "bold 36px 'Excellence In Motion V2'");
	this.text.name = "text";
	this.text.lineHeight = 44;
	this.text.lineWidth = 210;
	this.text.parent = this;
	this.text.setTransform(2,-22);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = getMCSymbolPrototype(lib.text_price_currency, new cjs.Rectangle(0,-24,214,46), null);


(lib.text_price_cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("CLIQUEZ, DECOLLEZ", "bold 14px 'Excellence In Motion V2'");
	this.text.name = "text";
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 596;
	this.text.parent = this;
	this.text.setTransform(0,-9);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = getMCSymbolPrototype(lib.text_price_cta, new cjs.Rectangle(-300,-11,600,20.4), null);


(lib.text_price_conditions = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("VOIR CONDITIONS", "bold 11px 'Excellence In Motion V2'");
	this.text.name = "text";
	this.text.textAlign = "center";
	this.text.lineHeight = 13;
	this.text.lineWidth = 596;
	this.text.parent = this;
	this.text.setTransform(0,2);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = getMCSymbolPrototype(lib.text_price_conditions, new cjs.Rectangle(-300,0,600,32), null);


(lib.text_price_ati = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("A/R\nTTC", "bold 14px 'Excellence In Motion V2'");
	this.text.name = "text";
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 445;
	this.text.parent = this;
	this.text.setTransform(0.4,-17);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = getMCSymbolPrototype(lib.text_price_ati, new cjs.Rectangle(-224,-19,449,36.7), null);


(lib.text_endshot_price = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("570", "bold 34px 'Excellence In Motion V2'");
	this.text.name = "text";
	this.text.textAlign = "right";
	this.text.lineHeight = 42;
	this.text.lineWidth = 287;
	this.text.parent = this;
	this.text.setTransform(-2,-21);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = getMCSymbolPrototype(lib.text_endshot_price, new cjs.Rectangle(-291,-23,291,46), null);


(lib.text_endshot_fromPrice = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("From", "bold 9px 'Excellence In Motion V2'");
	this.text.name = "text";
	this.text.textAlign = "center";
	this.text.lineHeight = 13;
	this.text.lineWidth = 596;
	this.text.parent = this;
	this.text.setTransform(0,-5.6);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = getMCSymbolPrototype(lib.text_endshot_fromPrice, new cjs.Rectangle(-300,-7.6,600,14.5), null);


(lib.text_endshot_currency = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("€", "bold 28px 'Excellence In Motion V2'");
	this.text.name = "text";
	this.text.lineHeight = 35;
	this.text.lineWidth = 210;
	this.text.parent = this;
	this.text.setTransform(2,-16);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = getMCSymbolPrototype(lib.text_endshot_currency, new cjs.Rectangle(0,-18,214,36.6), null);


(lib.text_endshot_ati = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("A/R\nTTC", "bold 12px 'Excellence In Motion V2'");
	this.text.name = "text";
	this.text.textAlign = "center";
	this.text.lineHeight = 14;
	this.text.lineWidth = 397;
	this.text.parent = this;
	this.text.setTransform(-0.5,-15);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = getMCSymbolPrototype(lib.text_endshot_ati, new cjs.Rectangle(-201,-17,401.1,32), null);


(lib.text_conditionsScreen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.text = new cjs.Text("Terms and conditions apply\nCredit cards surcharge applies\nFares subject to change\n40 days advanced purchase\n\n\n\n\n\n", "bold 13px 'Excellence In Motion V2'");
	this.text.name = "text";
	this.text.textAlign = "center";
	this.text.lineHeight = 15;
	this.text.lineWidth = 232;
	this.text.parent = this;
	this.text.setTransform(0,2);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = getMCSymbolPrototype(lib.text_conditionsScreen, new cjs.Rectangle(-118,0,236,193.8), null);


(lib.square = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().dr(-50,-50,100,100);
	this.shape.setTransform(50,50);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.square, new cjs.Rectangle(0,0,100,100), null);


(lib.empty = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = getMCSymbolPrototype(lib.empty, null, null);


(lib.btn_square = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().dr(-50,-50,100,100);
	this.shape.setTransform(50,50);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.screenConditionsBackground = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.749)").s().dr(-133,-165,266,330);
	this.shape.setTransform(133,165);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.screenConditionsBackground, new cjs.Rectangle(0,0,266,330), null);


(lib.logo_ohlalaBig = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#222222").s().p("ANNA4IiyAAIg2BgIgVgLICkkkIBqC9IABAAIA4BnIgUALgAKnAhICaAAIhNiIgADfA4IizAAIg1BgIgUgLICikkIBrC9IAAAAIA5BnIgUALgAA5AhICaAAIhOiIgAGICUIAAkfIAYAAIAAEIICbAAIAAAXgAjlCUIAAkfIAYAAIAAEIICbAAIAAAXgAltCUIAAiFIjEAAIAACFIgWAAIAAkfIAWAAIAACFIDEAAIAAiFIAXAAIAAEfgAtsBqQgqgrAAg7QAAg7AqgqQAqgqA7AAQA9AAAqAqQApAqAAA7QAAA7gpArQgqAqg9AAQg7AAgqgqgAtchRQgjAjAAAyQAAAyAjAkQAjAjAyAAQAzAAAkgjQAigkABgyQgBgygigjQgkgjgzAAQgyAAgjAjg");
	this.shape.setTransform(-94.5,0.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AFpCOQgdgMgWgRIAfgzQAQAOAWAKQAWAJASAAQAWABALgIQAMgIAAgMQAAgKgGgHQgGgGgNgGIhAgbQg8gbAAg0QAAgmAegYQAfgYAvAAQA6AAAuAjIghAtQghgXgkAAQgWAAgLAGQgMAIAAANQAAAJAHAIQAHAGAOAGIA/AaQAgAOARASQARATAAAdQAAAlghAaQghAZgzAAQgeAAgdgMgALBCVIgQgtIgRAOIANgTIgvgMIgFgSIBMgDIA/hWIiUg2IAAgOIA+ACIAOgbIAPACIgGAaIAnABIAQgdIAOACIgGAcIA3ACIA9hDIAfgCIABAgIg+BDIAHA2IAbgIIADAMIgcATIAFAnIAZgHIADANIgaARIAIA9IgPABIhCiPIhQBGIACBNgABJCTIAAkmIBBAAIAADuICDAAIAAA4gAg0CTIgihGIieAAIgiBGIhGAAICWkmIBGAAICXEmgAjbAZIBtAAIg2hvgApWCTIAAkmIDOAAIAAA4IiMAAIAABAICFAAIAAA0IiFAAIAABCICMAAIAAA4gAuXCTIAAkmIBnAAQBPAAAsAkQArAlAABGQAABEgsAqQgsAphNAAgAtWBbIAmAAQAxAAAagZQAbgZAAgsQAAgqgagWQgbgYgxAAIgmAAg");
	this.shape_1.setTransform(94.4,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_ohlalaBig, new cjs.Rectangle(-186.4,-15.4,372.8,30.8), null);


(lib.logo_ohlala = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#222222").s().p("ALfAxIibAAIgvBTIgSgJICOj+IBdClIAAAAIAxBZIgRAJgAJPAcICFAAIhDh2gADCAxIibAAIguBTIgSgJICNj+IBdClIAAAAIAxBZIgRAJgAAyAcICFAAIhDh2gAFVCAIAAj4IAUAAIAADkICHAAIAAAUgAjHCAIAAj4IAUAAIAADkICHAAIAAAUgAk9CAIAAhyIiqAAIAAByIgUAAIAAj4IAUAAIAAByICqAAIAAhyIAUAAIAAD4gAr6BcQgkglAAgzQAAgzAkglQAlgkA0AAQA0AAAkAkQAlAlAAAzQAAAzglAlQgkAlg0gBQg0ABglglgArshGQgeAeAAAsQAAArAeAfQAfAfAsgBQAsABAegfQAfgfAAgrQAAgsgfgeQgegegsAAQgsAAgfAeg");
	this.shape.setTransform(-82.2,0.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AE6B7QgagKgTgPIAcgrQAOALATAJQASAIAQAAQATAAAKgGQAKgHAAgLQAAgJgFgFQgFgGgLgGIg4gWQg0gYAAgtQAAghAagVQAbgVApAAQAyAAAoAeIgcAoQgdgVgfAAQgTAAgKAHQgKAGAAALQAAAIAGAGQAGAGAMAFIA3AXQAbALAPAQQAPARAAAaQAAAggdAWQgcAWgtAAQgaAAgZgLgAJlCCIgOgnIgPALIAMgQIgpgKIgFgQIBDgDIA2hKIiBgvIAAgMIA2ABIANgXIAMACIgFAWIAjABIANgZIANACIgGAYIAwACIA1g7IAbgBIABAcIg2A5IAGAvIAXgGIADAKIgYARIAEAiIAWgHIADAMIgXAPIAHA1IgNABIg5h9IhGA9IACBCgAA/CAIAAkAIA5AAIAADPIByAAIAAAxgAgtCAIgeg9IiJAAIgeA9Ig8AAICCkAIA9AAICDEAgAi+AWIBeAAIgvhhgAoICAIAAkAICzAAIAAAyIh6AAIAAA3IB0AAIAAAtIh0AAIAAA5IB6AAIAAAxgAsfCAIAAkAIBZAAQBFABAmAfQAmAgAAA8QAAA8gmAkQgnAkhDAAgArmBPIAhAAQAqAAAXgWQAXgVAAgmQAAglgXgTQgXgVgqABIghAAg");
	this.shape_1.setTransform(82.1,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_ohlala, new cjs.Rectangle(-162.1,-13.4,324.2,26.8), null);


(lib.logo_airfrance = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("EAItAs+QgsgEgggVQgngagHgoQgKg6AvgkQAfgYAvgHQA9gHA8AWQAHACAAAIIAAAsQgbgMgOgEQg3gOgnANQgLAEgIAFQgaASAAAcQAAAcAaASQAYARAhAAQAxAAAqgZIAHgEIABAGIAAAoQAAAGgGACQgsAWgyAAIgXgBgEAPZAs7IgHgBIAFgFQAogGAbgpIBzirQAEgHAIAAICDgDIh3C4QgUAcgXAOQgRAIgRAAgEABhAs6QgFAAgBgDIgVglQgDgGgFAAIhkAAQgFAAgCAGIgSAkQgCAEgEAAQgXACgZgCIgCAAIBqjLQADgGAHAAIAlAAQADAAAEAEIB4DKIABAEgEgAUArhIA/AAIghhBgEgC+As6QgOAAgNgMIgzgzQgEgEgIgCIghAAIgBAIIAAA3QAAAHgGAAQgXgBgYABQgGAAAAgGIAAjIIAAgEICIAAQAhABAXANQAaAPAEAcQAEAcgVAWIgRAOIgTAKIBSBPgEgE6AqWIAAAzIACAAIBCAAQALAAAJgHQALgIgBgNQgBgNgNgGQgJgEgKAAIg8gBgEgK5As6QgRAAgLgNIg0gzQgEgFgHAAIgiAAIAABFIg7AAIAAjRIAGAAICCAAQAhABAXANQAaAOAEAdQAEAcgVAWQgFAGgMAIIgTAKIBRBOIgHABgEgM2ArJIBGAAQAIAAAKgHQAKgIAAgNQgBgNgMgGQgKgEgKAAIhBgBgEgQ5As7QgIAAgDgGIgTgjQgDgGgGAAIhnAAQgGAAgCAFIgSAlQgDAFgGAAIgxAAIADgHIBqjGQADgFAGAAIApAAQADAAAEAEIB7DKIABADIgHABgEgS1ArhIBCAAIgjhBgEALKAs6IAAjRIDMAAIAAAsIiRAAIAAAlICPAAIAAAtIiPAAIAAAnICRAAIAAAsgEAFyAs6IgGgDIiJh5IAAB8IgyAAIAAjRIApAAQABAAAEAEICIB2IAAh6IAyAAIAADRgEgJeAs6IAAjRIDEAAIAAAsIiKAAIAAA1ICHAAIAAAtIiHAAIAABDgEgPkAs6IAAjRIA6AAIAADRgEAItgpRQgsgEgggVQgngagHgoQgKg6AvgkQAfgYAvgHQA9gHA8AWQAHACAAAIIAAAsQgbgMgOgEQg3gOgnANQgLAEgIAFQgaASAAAcQAAAcAaASQAYARAhAAQAxAAAqgZIAHgEIABAGIAAAoQAAAGgGACQgsAWgyAAIgXgBgEAPZgpUIgHgBIAFgFQAogGAbgpIBzirQAEgHAIAAICDgDIh3C4QgUAcgXAOQgRAIgRAAgEABhgpVQgFAAgBgDIgVglQgDgGgFAAIhkAAQgFAAgCAGIgSAkQgCAEgEAAQgXACgZgCIgCAAIBqjLQADgGAHAAIAlAAQADAAAEAEIB4DKIABAEgEgAUgquIA/AAIghhBgEgC+gpVQgOAAgNgMIgzgzQgEgEgIgCIghAAIgBAIIAAA3QAAAHgGAAQgXgBgYABQgGAAAAgGIAAjIIAAgEICIAAQAhABAXANQAaAPAEAcQAEAcgVAWIgRAOIgTAKIBSBPgEgE6gr5IAAAzIACAAIBCAAQALAAAJgHQALgIgBgNQgBgNgNgGQgJgEgKAAIg8gBgEgK5gpVQgRAAgLgNIg0gzQgEgFgHAAIgiAAIAABFIg7AAIAAjRIAGAAICCAAQAhABAXANQAaAOAEAdQAEAcgVAWQgFAGgMAIIgTAKIBRBOIgHABgEgM2grGIBGAAQAIAAAKgHQAKgIAAgNQgBgNgMgGQgKgEgKAAIhBgBgEgQ5gpUQgIAAgDgGIgTgjQgDgGgGAAIhnAAQgGAAgCAFIgSAlQgDAFgGAAIgxAAIADgHIBqjGQADgFAGAAIApAAQADAAAEAEIB7DKIABADIgHABgEgS1gquIBCAAIgjhBgEALKgpVIAAjRIDMAAIAAAsIiRAAIAAAlICPAAIAAAtIiPAAIAAAnICRAAIAAAsgEAFygpVIgGgDIiJh5IAAB8IgyAAIAAjRIApAAQABAAAEAEICIB2IAAh6IAyAAIAADRgEgJegpVIAAjRIDEAAIAAAsIiKAAIAAA1ICHAAIAAAtIiHAAIAABDgEgPkgpVIAAjRIA6AAIAADRg");
	this.shape.setTransform(151.6,299.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_airfrance, new cjs.Rectangle(20.8,12,261.7,575.8), null);


(lib.header = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvgA0xMCMApjAAAMAAAgzjMgpjAAAg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.header, new cjs.Rectangle(0,0,300,600), null);


(lib.ctaBackground = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().dr(-66.5,-13,133,26);
	this.shape.setTransform(66.5,13);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ctaBackground, new cjs.Rectangle(0,0,133,26), null);


(lib.background = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().dr(-133,-165,266,330);
	this.shape.setTransform(133,165);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.background, new cjs.Rectangle(0,0,266,330), null);


(lib.tibiaFront = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib._300x600_walkTibiaFront();
	this.instance.parent = this;
	this.instance.setTransform(-30,-75);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tibiaFront, new cjs.Rectangle(-30,-75,56,206), null);


(lib.tibiaBack = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib._300x600_walkTibiaBack();
	this.instance.parent = this;
	this.instance.setTransform(-30,-82);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tibiaBack, new cjs.Rectangle(-30,-82,56,206), null);


(lib.thighFront = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Calque 1
	this.instance = new lib._300x600_walkThighFront();
	this.instance.parent = this;
	this.instance.setTransform(-51,-94);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.thighFront, new cjs.Rectangle(-51,-94,86,171), null);


(lib.thighBack = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Calque 1
	this.instance = new lib._300x600_walkThighBack();
	this.instance.parent = this;
	this.instance.setTransform(-50,-94);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.thighBack, new cjs.Rectangle(-50,-94,86,171), null);


(lib.square_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().dr(-50,-50,100,100);
	this.shape_1.setTransform(50,50);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.square_1, new cjs.Rectangle(0,0,100,100), null);


(lib.skirt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AqpThQAkgygClrQgDlrgPhSQgPhSALkuIACgpQAQkWBgj+QBnkRByiPQDokkD3gmQBggOBKA6QA9AwAQBNQAPBNB5MaIAjDuQBcKUAfJTQhrh/oKCSQkMBMi7AAQiwAAhnhDg");
	this.shape.setTransform(4.3,-38.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AqpTlQAkgygClpIAAgCQgDlkgOhWIgBgDQgPhSALkoIAAgGIACgqQAQkSBdj5IADgIQBkkKBwiPIAGgIQDhkcDwgrIANgCQBZgNBGAxIAMAJQA2ArASBEIAEAOQAQBPB1MEIADAUIAjDuQBaKIAgJKIABAVQhihqneBuIg1ANQkOBEi8AAQiuAAhmg6g");
	this.shape_1.setTransform(4.3,-38.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AqpTpQAkgygClpIAAgCQgDlkgOhWIgBgDQgPhSAMkoIAAgGIABgpQAQkTBej5IADgIQBkkKBviPIAHgIQDhkcDxgqIAMgCQBagNBGAxIALAJQA2AsASBDIADAPQARBRB1MCIADAUIAiDtQBbKJAfJKIABAVQhehcnjBfIg0AMQkRA8i9AAQirAAhlgyg");
	this.shape_2.setTransform(4.3,-39);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AqpTuQAkgygClqIAAgCQgDlkgOhVIgBgEQgPhSAMkoIAAgGIABgpQARkSBdj6IADgIQBlkKBuiPIAHgIQDikcDwgqIANgCQBZgNBGAyIALAJQA2AsASBDIADAPQARBVB1L/IADAUIAjDtQBaKJAfJJIABAWQhbhNnmBQIg0AJQkVA1i+AAQioAAhjgpg");
	this.shape_3.setTransform(4.3,-39.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AqpTzQAkgygClqIAAgCQgDllgOhVIgBgDQgPhSAMkoIAAgGIABgqQARkSBdj6IADgHQBkkKBwiPIAGgIQDikcDxgqIANgCQBZgNBGAzIALAIQA2AtARBDIAEAPQARBYB0L8IADAUIAjDtQBaKJAfJKIABAVQhXg8nqA+Ig0AIQkbAsjAAAQijAAhggfg");
	this.shape_4.setTransform(4.3,-39.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AqpT3QAkgygClpIAAgCQgDllgOhVIgBgEQgOhSALkoIAAgGIABgqQAQkSBej6IAEgHQBkkLBviOIAHgIQDikcDxgqIANgCQBYgMBGAzIAMAJQA1AsARBEIAEAPQASBbBzL5IAEATIAiDuQBaKJAgJKIAAAVQhTgsnuAuIg0AGQklAjjDAAQiaAAhcgWg");
	this.shape_5.setTransform(4.3,-40.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AqpT8QAkgygClpIAAgCQgDlmgOhVIgBgDQgOhTALknIAAgGIABgqQAQkSBej6IAEgIQBkkKBviPIAHgIQDjkcDxgpIANgCQBYgMBGAzIALAJQA2AtARBEIAEAPQARBfBzL1IAEAUIAiDtQBaKJAgJKIgBAVQhOganyAbIg0AFQk6AajJAAQiHAAhUgMg");
	this.shape_6.setTransform(4.3,-40.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AqpUBQAkgygClqIAAgCQgDlmgOhUIgBgEQgOhTALknIAAgGIABgqQAQkSBfj6IADgIQBlkKBviPIAGgIQDjkcDxgpIAOgBQBZgMBFAzIALAJQA1AtARBEIAEAQQASBiBzLyIADAUIAjDsQBZKKAgJKIgBAVQhJgIn3AJIg0ACQmBASjWAAQhPAAg4gCg");
	this.shape_7.setTransform(4.3,-41.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AqHNmIAAgCQgDlmgOhUIgBgEQgOhTAKknIAAgGIACgqQARkSBej6IADgIQBlkLBviOIAHgIQDjkcDxgoIAOgCQBYgLBGA0IALAJQA1AsAQBFIAEAQQASBlBzLvIADATIAiDtQBaKKAgJKQAAALgBAKQhFALn8gLIgzABQoQAEjOAMQAkgygClqg");
	this.shape_8.setTransform(4.3,-41.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AqHNmIAAgCQgDlngOhTIgBgEQgOhTAKkoIAAgGIACgqQARkSBej6IADgHQBlkLBwiOIAGgIQDjkdDygnIAOgCQBYgLBFA0IAMAJQA0AtAQBFIAEAQQATBqByLqIADAUQASB3AQB1QBaKKAgJLQAAALgBAKQhAAeoBgfIgzgCQoRgQjNAiQAkgygClqg");
	this.shape_9.setTransform(4.3,-41.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("ABoTtIgzgDQoSgnjMA6QAkgygClrIAAgCQgDlngOhTIgBgEQgOhUAKknIAAgGIACgqQARkSBej6IADgHQBlkMBwiOIAHgIQDjkcDygnIAOgCQBYgKBFA0IAMAKQA0AtAQBEIADARQAUBtBxLoIADATIAjDsQBaKLAfJKQAAALgBAKQgdAZiNAAQiQAAkHgbg");
	this.shape_10.setTransform(4.3,-40.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("ABoToIgzgGQoTg8jLBRQAkgygClrIAAgCQgDlngOhTIgBgEQgOhUAKknIAAgGIACgqQARkSBej7IADgHQBmkLBwiOIAGgIQDkkdDygmIAOgCQBYgKBFA1IAMAJQAzAuAQBFIADARQAVBxBwLjIADATIAjDtQBaKKAfJLQAAALgCAJQgaAjiMAAQiQAAkKglg");
	this.shape_11.setTransform(4.3,-40.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("ABoTjIgzgIQoUhUjKBqQAkgygClrIAAgCQgDlogPhTIgBgEQgNhUAKknIAAgGIADgqQAQkSBfj6IADgIQBlkLBwiOIAHgIQDkkcDygmIAOgCQBYgKBFA2IAMAJQAzAuAPBFIAEARQAVB1BwLgIADATQASB3AQB2QBaKKAfJLQAAALgCAJQgYAtiLAAQiQAAkNgwg");
	this.shape_12.setTransform(4.3,-39.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("ABnTdIgygKQoVhrjJCCQAkgygClrIAAgCQgDlogPhSIgBgEQgNhVAKknIAAgGIADgqQAQkSBfj7IADgHQBlkLBxiOIAHgIQDjkdD0glIANgCQBYgJBFA2IAMAJQAzAuAOBFIAEASQAVB6BwLbIADATIAiDtQBaKKAfJLQAAALgCAJQgVA5iMAAQiQAAkQg9g");
	this.shape_13.setTransform(4.3,-39.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("ABGNOQmIhoiOBwQAYgigBj4QgCj3gKg4QgKg5AHjNQAHjMBHi6QBGi6BOhiQCejHCogaQBCgKAyAoQApAgALA1QALA1BSIdQBTIcAZHeQgBA8hsAAQhjAAi7gxg");
	this.shape_14.setTransform(4.3,-38.4,1.466,1.466);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("ABoTdIgzgKQoVhrjJCCQAkgygClrIAAgBQgDlpgPhSIgBgEQgOhVALknIAAgFQAMkpBmkPIADgHQBlkLBxiOIAGgHQDkkeD0glIAMgCQBZgJBFA2IAKAIQA1AuAOBHIADAPQAWB2BwLhIACAQQB4MPAkK2QAAALgCAKQgWA4iKAAQiRAAkPg9g");
	this.shape_15.setTransform(4.3,-39.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("ABoTjIgzgIQoUhUjKBqQAkgygClrIAAgBQgDlpgPhTIgBgDQgOhVALknIAAgFQAMkpBmkPIADgHQBlkLBwiOIAGgHQDkkdD0gmIAMgCQBZgKBGA2IAJAIQA1AuAPBGIADAPQAVByBxLlIACAQQB3MOAlK2QAAAMgCAKQgZAtiJAAQiRAAkNgxg");
	this.shape_16.setTransform(4.3,-39.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("ABoToIgzgGQoTg8jLBRQAkgygClrIAAgBQgDlpgPhSIAAgEQgPhUALknIAAgFQALkqBmkOIADgHQBmkLBwiOIAGgHQDkkeDzgmIAMgCQBZgKBGA1IAJAIQA2AuAPBGIADAPQAUBuBxLpIADAQQB3MOAlK2QAAALgCAKQgbAiiJAAQiRAAkLglg");
	this.shape_17.setTransform(4.3,-40.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("ABoTtIgzgDQoSgnjMA6QAkgygClrIAAgBQgDlogPhTIAAgEQgPhTALkoIAAgFQALkpBmkOIADgHQBlkMBwiOIAGgHQDkkdDzgnIAMgCQBZgLBGA2IAKAIQA1AtAQBGIADAPQAUBqBxLtIADAQQB3MNAlK2QAAALgCALQgdAYiJAAQiRAAkJgbg");
	this.shape_18.setTransform(4.3,-40.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AqHNmIAAgBQgDlogPhUIAAgDQgPhTALkoIAAgFQALkpBmkOIADgHQBlkMBwiOIAGgHQDjkdDzgnIAMgCQBZgLBGA1IAKAHQA2AuAQBGIADAOQATBnByLwIACAQQB4MNAlK2QAAALgCAKQhAAeoAgfIgzgCQoRgQjNAiQAkgygClqg");
	this.shape_19.setTransform(4.3,-41.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AqHNmIAAgBQgDlogPhTIAAgEQgPhTALkoIAAgFQALkpBmkOIADgHQBlkLBviOIAGgHQDkkeDygnIAMgCQBZgLBGA0IAKAIQA2AtAQBGIADAOQATBjBzLzIACARQB4MNAlK1QAAALgBALQhGAKn6gLIg0ABQoQAEjOAMQAkgygClqg");
	this.shape_20.setTransform(4.3,-41.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AqpUBQAkgygClqIAAgCQgDlngOhUIgBgDQgOhTALkoIAAgFQAKkpBmkOIADgHQBlkLBviOIAGgHQDjkeDygoIANgBQBZgMBGA0IAJAIQA3AtAQBFIAEAOQARBgB0L3IADAQQB2MNAmK1IgBAWQhKgJn2AJIg0ACQmBASjWAAQhPAAg4gCg");
	this.shape_21.setTransform(4.3,-41.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AqpT8QAkgygClpIAAgCQgDlngOhUIgBgDQgOhTALkoIAAgFQALkpBkkOIAEgHQBkkLBviOIAHgHQDjkeDxgoIAMgCQBagMBGA0IAKAIQA2AtARBFIADAOQASBdBzL5IADARQB4MMAlK1IgBAWQhOgbnyAbIg0AFQk6AajJAAQiHAAhUgMg");
	this.shape_22.setTransform(4.3,-40.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AqpT3QAkgygClpIAAgCQgDlmgOhVIgBgDQgOhSALkpIAAgFQALkpBkkNIAEgHQBkkLBviPIAHgHQDikdDxgpIAMgCQBbgMBFAzIAKAIQA3AtARBFIADAOQASBZBzL9IADARQB3MMAmK0IgBAWQhSgsnuAuIg0AGQklAjjDAAQiaAAhcgWg");
	this.shape_23.setTransform(4.3,-40.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AqpTzQAkgygClqIAAgBQgDlmgOhVIgBgDQgPhSAMkpIAAgFQAKkpBlkNIADgHQBlkLBviPIAGgHQDikdDygpIAMgCQBZgNBHA0IAJAHQA4AtAQBFIADANQASBXB0L/IADARQB3MMAlK0IABAWQhXg8npA+Ig1AIQkbAsjAAAQijAAhggfg");
	this.shape_24.setTransform(4.3,-39.9);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AqpTuQAkgygClqIAAgBQgDlmgOhVIgBgDQgPhSAMkpIAAgFQAKkoBlkOIADgHQBlkKBuiPIAHgHQDikeDxgpIAMgCQBagNBGAzIAKAIQA3AsARBFIADANQARBUB1MCIADARQB3MMAlK0IABAWQhbhNnlBQIg1AJQkVA1i+AAQioAAhjgpg");
	this.shape_25.setTransform(4.3,-39.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AqpTpQAkgygClpIAAgCQgDllgOhVIgBgDQgPhSAMkpIAAgFQAKkoBlkOIADgHQBkkKBviQIAGgHQDjkdDxgpIALgCQBagNBHAyIAJAIQA4AsARBFIADANQARBRB1MFIADARQB3MLAlK0IABAWQhfhcnhBfIg1AMQkRA8i9AAQirAAhlgyg");
	this.shape_26.setTransform(4.3,-39);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AqpTlQAkgygClpIAAgCQgDllgOhVIgBgDQgPhSALkpIAAgFQALkpBkkNIADgHQBlkKBviQIAGgHQDikdDwgqIAMgCQBagNBHAyIAKAIQA3AsASBEIADANQAQBPB1MHIADARQB3MLAmK0IABAWQhihqneBuIg1ANQkOBEi8AAQiuAAhmg6g");
	this.shape_27.setTransform(4.3,-38.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[]},1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63.9,-169.7,136.5,263.1);


(lib.sitSkirt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Calque 1
	this.instance = new lib._300x600_sitSkirt();
	this.instance.parent = this;
	this.instance.setTransform(-59,-58);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sitSkirt, new cjs.Rectangle(-59,-58,119,117), null);


(lib.sitNose = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib._300x600_sitNose();
	this.instance.parent = this;
	this.instance.setTransform(-6,-7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sitNose, new cjs.Rectangle(-6,-7,9,10), null);


(lib.sitNeckShadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib._300x600_sitNeckShadow();
	this.instance.parent = this;
	this.instance.setTransform(-13,-14);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sitNeckShadow, new cjs.Rectangle(-13,-14,26,28), null);


(lib.sitNeck = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib._300x600_sitNeck();
	this.instance.parent = this;
	this.instance.setTransform(-21,-25);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sitNeck, new cjs.Rectangle(-21,-25,42,49), null);


(lib.sitMouth3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.instance = new lib._300x600_sitMouth3b();
	this.instance.parent = this;
	this.instance.setTransform(-9,-2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(7).to({_off:false},0).wait(8));

	// Layer 2
	this.instance_1 = new lib._300x600_sitMouth3a();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-8,-2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},7).wait(8));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8,-2,15,4);


(lib.sitMouth2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib._300x600_sitMouth2();
	this.instance.parent = this;
	this.instance.setTransform(-7,-3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(15));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7,-3,15,5);


(lib.sitMouth1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib._300x600_sitMouth1();
	this.instance.parent = this;
	this.instance.setTransform(-2,-2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sitMouth1, new cjs.Rectangle(-2,-2,4,4), null);


(lib.sitLeg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib._300x600_sitLeg();
	this.instance.parent = this;
	this.instance.setTransform(-57,-77);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sitLeg, new cjs.Rectangle(-57,-77,113,154), null);


(lib.sitHeadband = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib._300x600_sitHeadband();
	this.instance.parent = this;
	this.instance.setTransform(-38,-4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sitHeadband, new cjs.Rectangle(-38,-4,67,26), null);


(lib.sitHand = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.instance = new lib._300x600_sitHand();
	this.instance.parent = this;
	this.instance.setTransform(-47,-22);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sitHand, new cjs.Rectangle(-47,-22,86,42), null);


(lib.sitHairWick3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib._300x600_sitHairWick3();
	this.instance.parent = this;
	this.instance.setTransform(-11,-29);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sitHairWick3, new cjs.Rectangle(-11,-29,21,54), null);


(lib.sitHairWick2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib._300x600_sitHairWick2();
	this.instance.parent = this;
	this.instance.setTransform(-16,-12);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sitHairWick2, new cjs.Rectangle(-16,-12,33,24), null);


(lib.sitHairWick1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib._300x600_sitHairWick1();
	this.instance.parent = this;
	this.instance.setTransform(-25,-28);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sitHairWick1, new cjs.Rectangle(-25,-28,53,55), null);


(lib.sitHair = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib._300x600_sitHair();
	this.instance.parent = this;
	this.instance.setTransform(-36,-37);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sitHair, new cjs.Rectangle(-36,-37,70,75), null);


(lib.sitGlasses = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib._300x600_sitGlasses();
	this.instance.parent = this;
	this.instance.setTransform(-29,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sitGlasses, new cjs.Rectangle(-29,-10,59,21), null);


(lib.sitForeArm = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib._300x600_sitForearm();
	this.instance.parent = this;
	this.instance.setTransform(-64,-15);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sitForeArm, new cjs.Rectangle(-64,-15,129,38), null);


(lib.sitFace = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Calque 1
	this.instance = new lib._300x600_sitFace();
	this.instance.parent = this;
	this.instance.setTransform(-26,-42);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(11));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26,-42,54,79);


(lib.sitEar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib._300x600_sitEar();
	this.instance.parent = this;
	this.instance.setTransform(-5,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sitEar, new cjs.Rectangle(-5,-10,10,19), null);


(lib.sitBust = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Calque 1
	this.instance = new lib._300x600_sitChest4();
	this.instance.parent = this;
	this.instance.setTransform(-114,-176);

	this.instance_1 = new lib._300x600_sitChest2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-114,-176);

	this.instance_2 = new lib._300x600_sitChest3();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-114,-176);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[]},1).to({state:[{t:this.instance_1}]},2).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.instance}]},2).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-114,-176,228,334);


(lib.sitBag = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib._300x600_sitBag();
	this.instance.parent = this;
	this.instance.setTransform(-76,-83);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sitBag, new cjs.Rectangle(-76,-83,153,167), null);


(lib.sitArm = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib._300x600_sitArm();
	this.instance.parent = this;
	this.instance.setTransform(-25,-114);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sitArm, new cjs.Rectangle(-25,-114,50,229), null);


(lib.kneeFront = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib._300x600_walkKneeFront();
	this.instance.parent = this;
	this.instance.setTransform(-5,-12);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.kneeFront, new cjs.Rectangle(-5,-12,10,27), null);


(lib.kneeBack = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib._300x600_walkKneeBack();
	this.instance.parent = this;
	this.instance.setTransform(-3.9,-10.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.kneeBack, new cjs.Rectangle(-3.9,-10.2,10,27), null);


(lib.chairFree = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib._300x600_chair();
	this.instance.parent = this;
	this.instance.setTransform(-233,-304);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.chairFree, new cjs.Rectangle(-233,-304,391,612), null);


(lib.ModuleIntro = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{idle:0,show:4,shown:9});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_9 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(7));

	// logo
	this.logo = new lib.logo_airfrance();
	this.logo.parent = this;
	this.logo.setTransform(151.6,299.9,1,1,0,0,0,151.6,299.9);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(16));

	// background
	this.background = new lib.background();
	this.background.parent = this;
	this.background.setTransform(17,47);

	this.timeline.addTween(cjs.Tween.get(this.background).wait(16));

	// header
	this.header = new lib.header();
	this.header.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.header).wait(16));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.text_priceGroupBottom = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.textPriceFrom = new lib.text_price_fromPrice();
	this.textPriceFrom.parent = this;
	this.textPriceFrom.setTransform(0,-18);

	this.timeline.addTween(cjs.Tween.get(this.textPriceFrom).wait(1));

	// Layer 1
	this.textPricePrice = new lib.text_price_price();
	this.textPricePrice.parent = this;
	this.textPricePrice.setTransform(0,9);

	this.textPriceAti = new lib.text_price_ati();
	this.textPriceAti.parent = this;
	this.textPriceAti.setTransform(0,44);

	this.textPriceCurrency = new lib.text_price_currency();
	this.textPriceCurrency.parent = this;
	this.textPriceCurrency.setTransform(0,11);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.textPriceCurrency},{t:this.textPriceAti},{t:this.textPricePrice}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text_priceGroupBottom, new cjs.Rectangle(-300,-25.6,600,87.4), null);


(lib.text_priceGroup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// textPriceTitle
	this.textPriceTitle = new lib.text_price_title();
	this.textPriceTitle.parent = this;
	this.textPriceTitle.setTransform(0,-18);

	this.timeline.addTween(cjs.Tween.get(this.textPriceTitle).wait(1));

	// textPriceGroupLine2
	this.textPriceGroupLine2 = new lib.text_priceGroupBottom();
	this.textPriceGroupLine2.parent = this;
	this.textPriceGroupLine2.setTransform(0,22);

	this.timeline.addTween(cjs.Tween.get(this.textPriceGroupLine2).wait(1));

}).prototype = getMCSymbolPrototype(lib.text_priceGroup, new cjs.Rectangle(-300,-38,600,121.7), null);


(lib.text_priceEndshot_price = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.textPriceFrom = new lib.text_endshot_fromPrice();
	this.textPriceFrom.parent = this;
	this.textPriceFrom.setTransform(0,-17.6);

	this.textPricePrice = new lib.text_endshot_price();
	this.textPricePrice.parent = this;
	this.textPricePrice.setTransform(0,2.5,1,1,0,0,0,0,0.1);

	this.textPriceCurrency = new lib.text_endshot_currency();
	this.textPriceCurrency.parent = this;
	this.textPriceCurrency.setTransform(0.1,1.5,1,1,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.textPriceCurrency},{t:this.textPricePrice},{t:this.textPriceFrom}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text_priceEndshot_price, new cjs.Rectangle(-300,-25.3,600,50.6), null);


(lib.text_priceEndshot_line = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// textPriceTitle
	this.textPriceTitle = new lib.text_priceEndshot_title();
	this.textPriceTitle.parent = this;
	this.textPriceTitle.setTransform(0,-26.3);

	this.timeline.addTween(cjs.Tween.get(this.textPriceTitle).wait(1));

	// textPricePrice
	this.textPricePrice = new lib.text_priceEndshot_price();
	this.textPricePrice.parent = this;
	this.textPricePrice.setTransform(0,10.7);

	this.timeline.addTween(cjs.Tween.get(this.textPricePrice).wait(1));

	// textPriceAti
	this.textPriceAti = new lib.text_endshot_ati();
	this.textPriceAti.parent = this;
	this.textPriceAti.setTransform(0,36);

	this.timeline.addTween(cjs.Tween.get(this.textPriceAti).wait(1));

}).prototype = getMCSymbolPrototype(lib.text_priceEndshot_line, new cjs.Rectangle(-589,-40.3,1178.1,91.4), null);


(lib.text_price = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// textPrice
	this.textPriceGroup = new lib.text_priceGroup();
	this.textPriceGroup.parent = this;
	this.textPriceGroup.setTransform(150,163);

	this.timeline.addTween(cjs.Tween.get(this.textPriceGroup).wait(1));

	// textPriceFrom
	this.textPriceFrom = new lib.text_price_from();
	this.textPriceFrom.parent = this;
	this.textPriceFrom.setTransform(150,313);

	this.timeline.addTween(cjs.Tween.get(this.textPriceFrom).wait(1));

	// textPriceCta
	this.textPriceCta = new lib.text_price_cta();
	this.textPriceCta.parent = this;
	this.textPriceCta.setTransform(150,479);

	this.timeline.addTween(cjs.Tween.get(this.textPriceCta).wait(1));

	// textPriceConditions
	this.textPriceConditions = new lib.text_price_conditions();
	this.textPriceConditions.parent = this;
	this.textPriceConditions.setTransform(150,506);

	this.timeline.addTween(cjs.Tween.get(this.textPriceConditions).wait(1));

	// ctaBackground
	this.ctaBackground = new lib.ctaBackground();
	this.ctaBackground.parent = this;
	this.ctaBackground.setTransform(150.5,477,1,1,0,0,0,66.5,13);

	this.timeline.addTween(cjs.Tween.get(this.ctaBackground).wait(1));

}).prototype = getMCSymbolPrototype(lib.text_price, new cjs.Rectangle(-150,125,600,413), null);


(lib.TextOhlalaPricesEndshot3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// textPriceEndshotLine1
	this.textPriceEndshotLine1 = new lib.text_priceEndshot_line();
	this.textPriceEndshotLine1.parent = this;
	this.textPriceEndshotLine1.setTransform(150,119);

	this.timeline.addTween(cjs.Tween.get(this.textPriceEndshotLine1).wait(1));

	// textPriceEndshotLine2
	this.textPriceEndshotLine2 = new lib.text_priceEndshot_line();
	this.textPriceEndshotLine2.parent = this;
	this.textPriceEndshotLine2.setTransform(150,205);

	this.timeline.addTween(cjs.Tween.get(this.textPriceEndshotLine2).wait(1));

	// textPriceEndshotLine3
	this.textPriceEndshotLine3 = new lib.text_priceEndshot_line();
	this.textPriceEndshotLine3.parent = this;
	this.textPriceEndshotLine3.setTransform(150,291);

	this.timeline.addTween(cjs.Tween.get(this.textPriceEndshotLine3).wait(1));

	// textPriceFrom
	this.textPriceFrom = new lib.text_price_from();
	this.textPriceFrom.parent = this;
	this.textPriceFrom.setTransform(150,358);

	this.timeline.addTween(cjs.Tween.get(this.textPriceFrom).wait(1));

	// textPriceCta
	this.textPriceCta = new lib.text_price_cta();
	this.textPriceCta.parent = this;
	this.textPriceCta.setTransform(150,449);

	this.timeline.addTween(cjs.Tween.get(this.textPriceCta).wait(1));

	// textPriceConditions
	this.textPriceConditions = new lib.text_price_conditions();
	this.textPriceConditions.parent = this;
	this.textPriceConditions.setTransform(150,506);

	this.timeline.addTween(cjs.Tween.get(this.textPriceConditions).wait(1));

	// ctaBackground
	this.ctaBackground = new lib.ctaBackground();
	this.ctaBackground.parent = this;
	this.ctaBackground.setTransform(150.5,447,1,1,0,0,0,66.5,13);

	this.timeline.addTween(cjs.Tween.get(this.ctaBackground).wait(1));

}).prototype = getMCSymbolPrototype(lib.TextOhlalaPricesEndshot3, new cjs.Rectangle(-439,78.7,1178.1,459.4), null);


(lib.TextOhlalaPricesEndshot2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// textPriceEndshotLine1
	this.textPriceEndshotLine1 = new lib.text_priceEndshot_line();
	this.textPriceEndshotLine1.parent = this;
	this.textPriceEndshotLine1.setTransform(150,162);

	this.timeline.addTween(cjs.Tween.get(this.textPriceEndshotLine1).wait(1));

	// textPriceEndshotLine2
	this.textPriceEndshotLine2 = new lib.text_priceEndshot_line();
	this.textPriceEndshotLine2.parent = this;
	this.textPriceEndshotLine2.setTransform(150,252);

	this.timeline.addTween(cjs.Tween.get(this.textPriceEndshotLine2).wait(1));

	// textPriceFrom
	this.textPriceFrom = new lib.text_price_from();
	this.textPriceFrom.parent = this;
	this.textPriceFrom.setTransform(150,358);

	this.timeline.addTween(cjs.Tween.get(this.textPriceFrom).wait(1));

	// textPriceCta
	this.textPriceCta = new lib.text_price_cta();
	this.textPriceCta.parent = this;
	this.textPriceCta.setTransform(150,449);

	this.timeline.addTween(cjs.Tween.get(this.textPriceCta).wait(1));

	// textPriceConditions
	this.textPriceConditions = new lib.text_price_conditions();
	this.textPriceConditions.parent = this;
	this.textPriceConditions.setTransform(150,506);

	this.timeline.addTween(cjs.Tween.get(this.textPriceConditions).wait(1));

	// ctaBackground
	this.ctaBackground = new lib.ctaBackground();
	this.ctaBackground.parent = this;
	this.ctaBackground.setTransform(150,447,1,1,0,0,0,66,13);

	this.timeline.addTween(cjs.Tween.get(this.ctaBackground).wait(1));

}).prototype = getMCSymbolPrototype(lib.TextOhlalaPricesEndshot2, new cjs.Rectangle(-439,121.7,1178.1,416.4), null);


(lib.TextOhlalaPricesEndshot1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// textPriceEndshotLine1
	this.textPriceEndshotLine1 = new lib.text_priceEndshot_line();
	this.textPriceEndshotLine1.parent = this;
	this.textPriceEndshotLine1.setTransform(150,205);

	this.timeline.addTween(cjs.Tween.get(this.textPriceEndshotLine1).wait(1));

	// textPriceFrom
	this.textPriceFrom = new lib.text_price_from();
	this.textPriceFrom.parent = this;
	this.textPriceFrom.setTransform(150,358);

	this.timeline.addTween(cjs.Tween.get(this.textPriceFrom).wait(1));

	// textPriceCta
	this.textPriceCta = new lib.text_price_cta();
	this.textPriceCta.parent = this;
	this.textPriceCta.setTransform(150,449);

	this.timeline.addTween(cjs.Tween.get(this.textPriceCta).wait(1));

	// textPriceConditions
	this.textPriceConditions = new lib.text_price_conditions();
	this.textPriceConditions.parent = this;
	this.textPriceConditions.setTransform(150,506);

	this.timeline.addTween(cjs.Tween.get(this.textPriceConditions).wait(1));

	// ctaBackground
	this.ctaBackground = new lib.ctaBackground();
	this.ctaBackground.parent = this;
	this.ctaBackground.setTransform(150.5,447,1,1,0,0,0,66.5,13);

	this.timeline.addTween(cjs.Tween.get(this.ctaBackground).wait(1));

}).prototype = getMCSymbolPrototype(lib.TextOhlalaPricesEndshot1, new cjs.Rectangle(-439,164.7,1178.1,373.4), null);


(lib.text_ohlalaPrice = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// textPrice
	this.textPriceGroup = new lib.text_priceGroup();
	this.textPriceGroup.parent = this;
	this.textPriceGroup.setTransform(150,173);

	this.timeline.addTween(cjs.Tween.get(this.textPriceGroup).wait(1));

	// textPriceFrom
	this.textPriceFrom = new lib.text_price_from();
	this.textPriceFrom.parent = this;
	this.textPriceFrom.setTransform(150,313);

	this.timeline.addTween(cjs.Tween.get(this.textPriceFrom).wait(1));

	// textPriceCta
	this.textPriceCta = new lib.text_price_cta();
	this.textPriceCta.parent = this;
	this.textPriceCta.setTransform(150,479);

	this.timeline.addTween(cjs.Tween.get(this.textPriceCta).wait(1));

	// textPriceConditions
	this.textPriceConditions = new lib.text_price_conditions();
	this.textPriceConditions.parent = this;
	this.textPriceConditions.setTransform(150,506);

	this.timeline.addTween(cjs.Tween.get(this.textPriceConditions).wait(1));

	// ctaBackground
	this.ctaBackground = new lib.ctaBackground();
	this.ctaBackground.parent = this;
	this.ctaBackground.setTransform(150.5,477,1,1,0,0,0,66.5,13);

	this.timeline.addTween(cjs.Tween.get(this.ctaBackground).wait(1));

}).prototype = getMCSymbolPrototype(lib.text_ohlalaPrice, new cjs.Rectangle(-150,135,600,403), null);


(lib.text_imagePrice = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// textPriceCta
	this.textPriceCta = new lib.text_price_cta();
	this.textPriceCta.parent = this;
	this.textPriceCta.setTransform(150,479);

	this.timeline.addTween(cjs.Tween.get(this.textPriceCta).wait(1));

	// textPriceConditions
	this.textPriceConditions = new lib.text_price_conditions();
	this.textPriceConditions.parent = this;
	this.textPriceConditions.setTransform(150,506);

	this.timeline.addTween(cjs.Tween.get(this.textPriceConditions).wait(1));

	// ctaBackground
	this.ctaBackground = new lib.ctaBackground();
	this.ctaBackground.parent = this;
	this.ctaBackground.setTransform(150.5,477,1,1,0,0,0,66.5,13);

	this.timeline.addTween(cjs.Tween.get(this.ctaBackground).wait(1));

}).prototype = getMCSymbolPrototype(lib.text_imagePrice, new cjs.Rectangle(-150,464,600,74), null);


(lib.strokes = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"idle":0,"show":4,"shown":33});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_33 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(33).call(this.frame_33).wait(7));

	// top
	this.top = new lib.square();
	this.top.parent = this;
	this.top.setTransform(0,-111);

	this.timeline.addTween(cjs.Tween.get(this.top).wait(13).to({regX:52.9,regY:54.4,scaleX:0.02,scaleY:0.71,skewX:44.9,x:326.4,y:24.2},0).to({regX:52.6,scaleX:3.6,x:156.3},13,cjs.Ease.get(-1)).wait(14));

	// right
	this.right = new lib.square();
	this.right.parent = this;
	this.right.setTransform(309,500);

	this.timeline.addTween(cjs.Tween.get(this.right).wait(13).to({regX:50,regY:49.8,scaleX:0.23,scaleY:0.03,skewY:-43.3,x:291.5,y:612.3},0).to({regY:50,scaleY:6.28,y:299.2},13,cjs.Ease.get(-1)).wait(14));

	// left
	this.left = new lib.square();
	this.left.parent = this;
	this.left.setTransform(-109,0);

	this.timeline.addTween(cjs.Tween.get(this.left).wait(13).to({regX:50,regY:50,scaleX:0.23,scaleY:0.03,skewY:-43.3,x:8.5,y:-13.6},0).to({scaleY:6.28,y:299.2},13,cjs.Ease.get(-1)).wait(14));

	// bottom
	this.bottom = new lib.square();
	this.bottom.parent = this;
	this.bottom.setTransform(0,631.1);

	this.timeline.addTween(cjs.Tween.get(this.bottom).wait(13).to({regX:50.1,regY:50,scaleX:0.05,scaleY:3.22,skewX:45,x:-125.7,y:490.7},0).to({scaleX:5.35,x:139.7},13,cjs.Ease.get(-1)).wait(14));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-109,-111,518,842.1);


(lib.sides = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"idle":0,"show":4,"shown":42,hide:48});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_42 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(42).call(this.frame_42).wait(16));

	// left
	this.left = new lib.square();
	this.left.parent = this;
	this.left.setTransform(-110,0);

	this.timeline.addTween(cjs.Tween.get(this.left).wait(29).to({regX:51.5,regY:50.3,scaleX:0.24,scaleY:0.03,skewY:-44.9,x:8.8,y:183},0).to({regX:51.2,regY:50.1,scaleY:1.66,x:8.7,y:264.7},13,cjs.Ease.get(-1)).wait(6).to({regX:51.5,regY:50.3,scaleY:0.03,x:8.8,y:183},9,cjs.Ease.get(-1)).wait(1));

	// right
	this.right = new lib.square();
	this.right.parent = this;
	this.right.setTransform(309.1,150);

	this.timeline.addTween(cjs.Tween.get(this.right).wait(29).to({regX:51.5,regY:50.3,scaleX:0.24,scaleY:0.03,skewY:-44.9,x:291.8,y:77},0).to({regX:51.2,regY:50.1,scaleY:1.66,x:291.7,y:158.7},13,cjs.Ease.get(-1)).wait(6).to({regX:51.5,regY:50.3,scaleY:0.03,x:291.8,y:77},9,cjs.Ease.get(-1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-110,0,519.1,250);


(lib.screen_conditions = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"idle":0,"show":4,"shown":9,"hide":15,hidden:20});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_9 = function() {
		this.stop();
	}
	this.frame_20 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(11).call(this.frame_20).wait(6));

	// textConditions
	this.textConditions = new lib.text_conditionsScreen();
	this.textConditions.parent = this;
	this.textConditions.setTransform(150,47);
	this.textConditions.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.textConditions).wait(4).to({alpha:1},5).wait(6).to({alpha:0},5).wait(6));

	// background
	this.instance = new lib.screenConditionsBackground();
	this.instance.parent = this;
	this.instance.setTransform(17,47);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({_off:false},0).to({alpha:1},5).wait(6).to({alpha:0},5).to({_off:true},1).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(32,47,236,193.8);


(lib.ohlalaTitleBig = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.logo_ohlalaBig();
	this.instance.parent = this;
	this.instance.setTransform(122,10.1,0.655,0.655);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ohlalaTitleBig, new cjs.Rectangle(0,0,244,20.2), null);


(lib.ohlalaTitle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.logo_ohlala();
	this.instance.parent = this;
	this.instance.setTransform(107,10,0.655,0.655);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ohlalaTitle, new cjs.Rectangle(0.9,1.3,212.2,17.5), null);


(lib.MainAnim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"idle":0,"show":4,"shown":9,"hide":15,"hidden":20});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_9 = function() {
		this.stop();
	}
	this.frame_20 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(11).call(this.frame_20).wait(6));

	// btnConditions
	this.btnConditions = new lib.btn_square();
	this.btnConditions.parent = this;
	this.btnConditions.setTransform(150,550.1,3,1,0,0,0,50,50.1);
	this.btnConditions.alpha = 0;
	new cjs.ButtonHelper(this.btnConditions, 0, 1, 2, false, new lib.btn_square(), 3);

	this.timeline.addTween(cjs.Tween.get(this.btnConditions).wait(26));

	// btnClickThrough
	this.btnClickThrough = new lib.btn_square();
	this.btnClickThrough.parent = this;
	this.btnClickThrough.setTransform(0,0,3,5);
	new cjs.ButtonHelper(this.btnClickThrough, 0, 1, 2, false, new lib.btn_square(), 3);

	this.timeline.addTween(cjs.Tween.get(this.btnClickThrough).wait(26));

	// screenConditions
	this.screenConditions = new lib.screen_conditions();
	this.screenConditions.parent = this;
	this.screenConditions.setTransform(150,135.5,1,1,0,0,0,150,135.5);

	this.timeline.addTween(cjs.Tween.get(this.screenConditions).wait(26));

	// modulesHolder
	this.modulesHolder = new lib.empty();
	this.modulesHolder.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.modulesHolder).wait(26));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.imageContent = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"idle":0,"show":4,"shown":50});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_50 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(50).call(this.frame_50).wait(7));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AxmmMIPoAAIAAPoIvoAAg");
	var mask_graphics_10 = new cjs.Graphics().p("EAVggtzIYUYUMhDTBDTI4U4Ug");
	var mask_graphics_11 = new cjs.Graphics().p("EAWGgtMIXHXGMhDSBDTI3H3Gg");
	var mask_graphics_12 = new cjs.Graphics().p("EAWsgslIV6V4MhDRBDTI1614g");
	var mask_graphics_13 = new cjs.Graphics().p("EAXRgsAIUwUuMhDRBDTI0w0ug");
	var mask_graphics_14 = new cjs.Graphics().p("EAX0grbITpTkMhDQBDTIzpzkg");
	var mask_graphics_15 = new cjs.Graphics().p("EAYXgq4ISjSeMhDQBDTIyjyeg");
	var mask_graphics_16 = new cjs.Graphics().p("EAY5gqWIReRaMhDPBDTIxexag");
	var mask_graphics_17 = new cjs.Graphics().p("EAZZgp1IQdQYMhDOBDTIwdwYg");
	var mask_graphics_18 = new cjs.Graphics().p("EAZ5gpUIPdPXMhDOBDSIvdvXg");
	var mask_graphics_19 = new cjs.Graphics().p("EAaYgo1IOeOYMhDNBDTIueuYg");
	var mask_graphics_20 = new cjs.Graphics().p("EAa1goXINjNcMhDMBDTItjtcg");
	var mask_graphics_21 = new cjs.Graphics().p("EAbSgn6IMpMiMhDMBDTIspsig");
	var mask_graphics_22 = new cjs.Graphics().p("EAbugneILwLqMhDLBDTIrwrqg");
	var mask_graphics_23 = new cjs.Graphics().p("EAcJgnDIK6K0MhDLBDTIq6q0g");
	var mask_graphics_24 = new cjs.Graphics().p("EAcjgmpIKGKAMhDLBDTIqGqAg");
	var mask_graphics_25 = new cjs.Graphics().p("EAc7gmQIJVJPMhDKBDSIpVpPg");
	var mask_graphics_26 = new cjs.Graphics().p("EAdTgl5IIlIgMhDKBDTIologg");
	var mask_graphics_27 = new cjs.Graphics().p("EAdqgliIH2HyMhDJBDTIn2nyg");
	var mask_graphics_28 = new cjs.Graphics().p("EAeAglMIHKHGMhDJBDTInKnGg");
	var mask_graphics_29 = new cjs.Graphics().p("EAeUgk3IGhGcMhDIBDTImhmcg");
	var mask_graphics_30 = new cjs.Graphics().p("EAeogkjIF5F0MhDIBDTIl5l0g");
	var mask_graphics_31 = new cjs.Graphics().p("EAe7gkQIFTFPMhDIBDSIlTlPg");
	var mask_graphics_32 = new cjs.Graphics().p("EAfNgj/IEvEsMhDIBDTIkvksg");
	var mask_graphics_33 = new cjs.Graphics().p("EAgLgjuIEOEKMhDHBDTIkOkKg");
	var mask_graphics_34 = new cjs.Graphics().p("EAhfgjeIDuDqMhDHBDTIjujqg");
	var mask_graphics_35 = new cjs.Graphics().p("EAiugjQIDQDOMhDHBDTIjQjOg");
	var mask_graphics_36 = new cjs.Graphics().p("EAj3gjCIC0CyMhDGBDTIi0iyg");
	var mask_graphics_37 = new cjs.Graphics().p("EAk7gi1ICaCYMhDGBDTIiaiYg");
	var mask_graphics_38 = new cjs.Graphics().p("EAl5giqICDCCMhDGBDTIiDiCg");
	var mask_graphics_39 = new cjs.Graphics().p("EAmygifIBuBsMhDGBDTIhuhsg");
	var mask_graphics_40 = new cjs.Graphics().p("EAnlgiVIBbBZMhDGBDSIhahZg");
	var mask_graphics_41 = new cjs.Graphics().p("EAoTgiNIBJBIMhDFBDTIhJhIg");
	var mask_graphics_42 = new cjs.Graphics().p("EAo8giFIA5A4MhDFBDTIg5g4g");
	var mask_graphics_43 = new cjs.Graphics().p("EApfgh/IAsAsMhDFBDTIgsgsg");
	var mask_graphics_44 = new cjs.Graphics().p("EAp9gh5IAhAgMhDFBDTIghggg");
	var mask_graphics_45 = new cjs.Graphics().p("EAqWgh0IAXAXMhDFBDSIgXgXg");
	var mask_graphics_46 = new cjs.Graphics().p("EAqpghxIAQAQMhDFBDTIgQgQg");
	var mask_graphics_47 = new cjs.Graphics().p("EAq2ghuIALALMhDEBDSIgMgLg");
	var mask_graphics_48 = new cjs.Graphics().p("EAq+ghtIAIAIMhDEBDTIgIgIg");
	var mask_graphics_49 = new cjs.Graphics().p("EArBghsIAHAHMhDFBDSIgHgHg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-112.6,y:60.4}).wait(10).to({graphics:mask_graphics_10,x:-254.3,y:108.7}).wait(1).to({graphics:mask_graphics_11,x:-224.4,y:113}).wait(1).to({graphics:mask_graphics_12,x:-195.2,y:117.2}).wait(1).to({graphics:mask_graphics_13,x:-166.9,y:121.3}).wait(1).to({graphics:mask_graphics_14,x:-139.3,y:125.3}).wait(1).to({graphics:mask_graphics_15,x:-112.4,y:129.2}).wait(1).to({graphics:mask_graphics_16,x:-86.4,y:132.9}).wait(1).to({graphics:mask_graphics_17,x:-61.1,y:136.6}).wait(1).to({graphics:mask_graphics_18,x:-36.6,y:140.1}).wait(1).to({graphics:mask_graphics_19,x:-12.9,y:143.5}).wait(1).to({graphics:mask_graphics_20,x:10,y:146.9}).wait(1).to({graphics:mask_graphics_21,x:32.2,y:150.1}).wait(1).to({graphics:mask_graphics_22,x:53.6,y:153.1}).wait(1).to({graphics:mask_graphics_23,x:74.2,y:156.1}).wait(1).to({graphics:mask_graphics_24,x:94,y:159}).wait(1).to({graphics:mask_graphics_25,x:113,y:161.7}).wait(1).to({graphics:mask_graphics_26,x:131.3,y:164.4}).wait(1).to({graphics:mask_graphics_27,x:148.8,y:166.9}).wait(1).to({graphics:mask_graphics_28,x:165.5,y:169.3}).wait(1).to({graphics:mask_graphics_29,x:181.5,y:171.6}).wait(1).to({graphics:mask_graphics_30,x:196.6,y:173.8}).wait(1).to({graphics:mask_graphics_31,x:211,y:175.9}).wait(1).to({graphics:mask_graphics_32,x:224.6,y:177.9}).wait(1).to({graphics:mask_graphics_33,x:232.9,y:179.7}).wait(1).to({graphics:mask_graphics_34,x:238.1,y:181.5}).wait(1).to({graphics:mask_graphics_35,x:243,y:183.1}).wait(1).to({graphics:mask_graphics_36,x:247.5,y:184.6}).wait(1).to({graphics:mask_graphics_37,x:251.7,y:186}).wait(1).to({graphics:mask_graphics_38,x:255.6,y:187.3}).wait(1).to({graphics:mask_graphics_39,x:259.2,y:188.5}).wait(1).to({graphics:mask_graphics_40,x:262.4,y:189.5}).wait(1).to({graphics:mask_graphics_41,x:265.2,y:190.5}).wait(1).to({graphics:mask_graphics_42,x:267.7,y:191.3}).wait(1).to({graphics:mask_graphics_43,x:269.9,y:192.1}).wait(1).to({graphics:mask_graphics_44,x:271.8,y:192.7}).wait(1).to({graphics:mask_graphics_45,x:273.3,y:193.2}).wait(1).to({graphics:mask_graphics_46,x:274.5,y:193.6}).wait(1).to({graphics:mask_graphics_47,x:275.3,y:193.9}).wait(1).to({graphics:mask_graphics_48,x:275.8,y:194}).wait(1).to({graphics:mask_graphics_49,x:276,y:194.1}).wait(1).to({graphics:null,x:0,y:0}).wait(7));

	// imageHolder1
	this.imageHolder1 = new lib.empty();
	this.imageHolder1.parent = this;
	this.imageHolder1.setTransform(-77.9,-17,1.15,1.15,0,0,0,-0.1,-0.1);

	var maskedShapeInstanceList = [this.imageHolder1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.imageHolder1).wait(10).to({x:-8.9},39,cjs.Ease.get(1)).to({_off:true},1).wait(7));

	// imageHolder2
	this.imageHolder2 = new lib.empty();
	this.imageHolder2.parent = this;
	this.imageHolder2.setTransform(-30,0);

	this.timeline.addTween(cjs.Tween.get(this.imageHolder2).wait(4).to({x:-10,y:-10},39,cjs.Ease.get(1)).wait(14));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.stop = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// skirt
	this.instance = new lib.skirt("single",21);
	this.instance.parent = this;
	this.instance.setTransform(69.3,-81.2,0.718,1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:70.5,y:-81.6},3).to({scaleY:1,skewX:1.2,skewY:2.5,x:72.4,y:-79.2},3,cjs.Ease.get(1)).wait(1).to({regX:4.3,regY:-38.1,skewX:1.1,skewY:2.2,x:75.8,y:-117.6},0).wait(1).to({skewX:0.7,skewY:1.7,x:74.7,y:-118.6},0).wait(1).to({skewX:0.2,skewY:0.9,x:73.1,y:-120},0).wait(1).to({skewX:-0.1,skewY:0.3,x:72,y:-121.1},0).wait(1).to({regX:0,regY:0,skewX:-0.3,skewY:0,x:68.6,y:-83.5},0).wait(1));

	// kneeFront
	this.instance_1 = new lib.kneeFront("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(78.7,35.5,1.224,1.005,0,22.7,18);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:1.22,scaleY:1.01,skewX:23.3,x:80.6},3).to({scaleX:1.22,scaleY:1,skewX:15.7,x:79.6,y:35.7},3,cjs.Ease.get(1)).wait(1).to({regY:1.5,scaleX:1.22,skewX:15.9,skewY:17.2,x:78.9,y:36.9},0).wait(1).to({scaleX:1.23,scaleY:1,skewX:16.3,skewY:15.4,x:78.1,y:36.4},0).wait(1).to({scaleX:1.23,scaleY:1,skewX:16.8,skewY:13,x:77.1,y:35.7},0).wait(1).to({scaleX:1.24,scaleY:1,skewX:17.2,skewY:11.1,x:76.3,y:35.1},0).wait(1).to({regY:0,scaleX:1.24,skewX:17.4,skewY:10.3,x:76.5,y:33.4},0).wait(1));

	// thighFront
	this.instance_2 = new lib.thighFront("single",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(74,-95.3,0.992,1.081,0,20.8,17.4,-21.8,-53.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({scaleX:0.99,scaleY:1.09,skewX:21.4,skewY:17.5,x:77.6},3).to({regX:-21.9,scaleY:1.09,skewX:22,skewY:16.3,x:77.4,y:-95.5},3,cjs.Ease.get(1)).wait(1).to({regX:-8,regY:-8.5,scaleY:1.09,skewX:21.9,skewY:16.2,x:71.6,y:-46.6},0).wait(1).to({scaleY:1.09,skewX:21.6,skewY:15.9,x:70.4,y:-47.3},0).wait(1).to({scaleY:1.1,skewX:21.2,skewY:15.5,x:68.6,y:-48.3},0).wait(1).to({scaleY:1.1,skewX:20.8,skewY:15.2,x:67.2,y:-49.1},0).wait(1).to({regX:-21.9,regY:-53.4,scaleY:1.1,skewX:20.7,skewY:15.1,x:70.9,y:-99.5},0).wait(1));

	// tibiaFront
	this.instance_3 = new lib.tibiaFront("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(68.5,35.1,0.998,1.002,0,6.8,4.8,-6.4,-73.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({regX:-6.3,scaleX:1,scaleY:1,skewX:7.5,x:70.4},3).to({regX:-6.4,scaleX:1,scaleY:1,skewX:6.9,x:68.7},3,cjs.Ease.get(1)).wait(1).to({regX:-2,regY:28,skewX:6.8,x:60.8,y:136.4},0).wait(1).to({scaleY:1,skewX:6.6,x:60.5,y:136.5},0).wait(1).to({scaleX:1,skewX:6.2,x:60.2,y:136.4},0).wait(1).to({scaleY:1,skewX:6,x:60.1},0).wait(1).to({regX:-6.3,regY:-73.5,skewX:5.9,x:66,y:35},0).wait(1));

	// kneeBack
	this.instance_4 = new lib.kneeBack("single",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(95.8,30.3,1.065,1.011,0,32.3,36.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({scaleX:1.08,scaleY:1,skewX:31.5,skewY:36.2,x:99.9,y:29.4},3).to({scaleY:1,skewX:34.6,skewY:38.7,x:105.1,y:34.1},3,cjs.Ease.get(1)).wait(1).to({regX:1.1,regY:3.3,skewX:33.7,skewY:38.1,x:103.8,y:37.3},0).wait(1).to({scaleY:1,skewX:31.9,skewY:36.8,x:103,y:36.6},0).wait(1).to({scaleY:1,skewX:29.3,skewY:35.1,x:102,y:35.9},0).wait(1).to({scaleY:1,skewX:27.4,skewY:33.8,x:101.2,y:35.2},0).wait(1).to({regX:0,regY:0,skewX:26.5,skewY:33.2,x:101.4,y:31.3},0).wait(1));

	// thighBack
	this.instance_5 = new lib.thighBack("single",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(81.2,-95.1,0.999,0.996,0,17.3,10.3,-21.8,-53.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({regY:-53.8,scaleX:1,scaleY:0.99,skewX:16.3,x:82.8,y:-96.1},3).to({regX:-21.7,regY:-53.6,scaleX:1,scaleY:0.99,skewX:14.6,skewY:8.5,x:84.5,y:-89.9},3,cjs.Ease.get(1)).wait(1).to({regX:-7,regY:-8.5,skewX:14.5,skewY:8.6,x:87.3,y:-44.9},0).wait(1).to({scaleX:1,skewX:14.3,skewY:8.9,x:86,y:-45.7},0).wait(1).to({scaleX:1,skewX:13.9,skewY:9.2,x:84.3,y:-46.7},0).wait(1).to({scaleX:1,skewX:13.6,skewY:9.5,x:83,y:-47.6},0).wait(1).to({regX:-21.7,regY:-53.5,skewX:13.5,skewY:9.6,x:78.3,y:-93.8},0).wait(1));

	// tibiaBack
	this.instance_6 = new lib.tibiaBack("single",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(84.6,28.7,1,1.009,0,28.8,32.8,-6.4,-73.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({scaleX:1.01,scaleY:1,skewX:27.9,skewY:32.5,x:88.7,y:27.8},3).to({regX:-6.5,regY:-73.4,skewX:30.4,skewY:35,x:94,y:32},3,cjs.Ease.get(1)).wait(1).to({regX:-2,regY:21,skewX:30.3,skewY:34.8,x:49.7,y:116},0).wait(1).to({skewX:30,skewY:34.5,x:49.4,y:115.8},0).wait(1).to({skewX:29.6,skewY:34.2,x:49,y:115.4},0).wait(1).to({skewX:29.3,skewY:33.9,x:48.6,y:115.3},0).wait(1).to({regX:-6.4,regY:-73.4,skewX:29.2,skewY:33.7,x:90.8,y:30.2},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31.2,-250.8,181.1,492.1);


(lib.sitMouth = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// bouche03
	this.instance = new lib.sitMouth3("synched",0,false);
	this.instance.parent = this;
	this.instance.setTransform(0,-1.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:-0.5,x:-0.5,startPosition:1},0).wait(1).to({startPosition:2},0).wait(1).to({startPosition:3},0).wait(1).to({startPosition:4},0).wait(1).to({startPosition:5},0).wait(1).to({startPosition:6},0).wait(1).to({startPosition:7},0).wait(1).to({startPosition:8},0).wait(1).to({startPosition:9},0).wait(1).to({startPosition:10},0).wait(1).to({startPosition:11},0).wait(1).to({startPosition:12},0).wait(1).to({startPosition:13},0).wait(1).to({regX:0,x:0,mode:"single",startPosition:14},0).wait(1));

	// bouche01
	this.instance_1 = new lib.sitMouth1("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(1.1,2.2,1,1,0,0,0,0,0.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regY:0,y:1.5},0).wait(1).to({y:1.4},0).wait(1).to({y:1.3},0).wait(1).to({y:1.2},0).wait(1).to({y:1.1},0).wait(1).to({y:1},0).wait(1).to({y:0.9},0).wait(1).to({y:0.8},0).wait(1).to({startPosition:0},0).wait(1).to({y:0.7},0).wait(1).to({startPosition:0},0).wait(1).to({y:0.6},0).wait(1).to({startPosition:0},0).wait(1).to({regY:0.6,y:1.2},0).wait(1));

	// bouche02
	this.instance_2 = new lib.sitMouth2("synched",0,false);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-0.7,1.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({regX:0.5,regY:-0.5,scaleX:1.01,x:-0.1,y:0.7,startPosition:1},0).wait(1).to({scaleX:1.02,skewY:-0.1,x:0,y:0.6,startPosition:2},0).wait(1).to({scaleX:1.03,x:0.1,y:0.4,startPosition:3},0).wait(1).to({scaleX:1.04,y:0.2,startPosition:4},0).wait(1).to({scaleX:1.05,skewY:-0.2,x:0.2,y:0.1,startPosition:5},0).wait(1).to({scaleX:1.05,x:0.3,y:-0.1,startPosition:6},0).wait(1).to({scaleX:1.06,x:0.4,y:-0.2,startPosition:7},0).wait(1).to({scaleX:1.07,skewY:-0.3,y:-0.3,startPosition:8},0).wait(1).to({scaleX:1.07,x:0.5,y:-0.4,startPosition:9},0).wait(1).to({scaleX:1.08,y:-0.5,startPosition:10},0).wait(1).to({scaleX:1.08,y:-0.6,startPosition:11},0).wait(1).to({scaleX:1.09,x:0.6,startPosition:12},0).wait(1).to({scaleX:1.09,y:-0.7,startPosition:13},0).wait(1).to({regX:0,regY:0,scaleX:1.09,x:0,y:-0.3,mode:"single",startPosition:14},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8,-3.7,15.3,7.3);


(lib.sitHead = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// sitMouth
	this.instance = new lib.sitMouth("single",0);
	this.instance.parent = this;
	this.instance.setTransform(-6.3,36.3,0.836,1,0,0,2.7,0,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({scaleX:0.87,skewY:2,x:-4.6,y:37.1},0).wait(2).to({scaleX:0.91,skewY:1.5,x:-2.9,y:37.8},0).wait(2).to({scaleX:0.95,skewY:0.8,x:-1.2,y:38.6},0).wait(2).to({scaleX:0.98,skewY:0.3,x:0.6,y:39.3},0).wait(2).to({scaleX:1,skewY:0,x:1.4,y:39.2},0).wait(2).to({y:38.7},0).wait(2).to({y:38.2},0).wait(2).to({y:37.8},0).wait(2).to({y:37.6},0).wait(2).to({y:37.3},0).wait(2).to({y:37.2},0).wait(2).to({startPosition:0},0).wait(7).to({startPosition:0},0).wait(2).to({y:37.6,startPosition:2},0).wait(2).to({y:38,startPosition:4},0).wait(2).to({scaleY:1.01,y:37.7,startPosition:6},0).wait(2).to({scaleY:1.03,y:37.1,startPosition:8},0).wait(2).to({scaleY:1.06,y:35.9,startPosition:10},0).wait(2).to({regY:0.4,scaleY:1.09,y:34.7,startPosition:12},0).wait(2).to({regY:0.5,scaleY:1.1,y:34.2,startPosition:14},0).wait(2).to({scaleY:1.11,y:34.1},0).wait(13));

	// sitHeadband
	this.instance_1 = new lib.sitHeadband("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-4.8,-24.6,0.886,0.999,0,-0.8,-2.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(2).to({scaleX:0.91,skewX:-0.5,skewY:-2,x:-3.1,y:-21.3},0).wait(2).to({scaleX:0.94,skewX:-0.3,skewY:-1.3,x:-1.5,y:-18.1},0).wait(2).to({scaleX:0.96,skewY:-0.8,x:0.3,y:-14.8},0).wait(2).to({scaleX:0.99,skewX:0,skewY:-0.3,x:1.9,y:-11.5},0).wait(2).to({scaleX:1,skewY:0,x:2.6,y:-11.7},0).wait(2).to({y:-14.4},0).wait(2).to({y:-16.6},0).wait(2).to({y:-18.4},0).wait(2).to({y:-19.8},0).wait(2).to({y:-20.9},0).wait(2).to({y:-21.5},0).wait(2).to({y:-21.7},0).wait(7).to({startPosition:0},0).wait(2).to({y:-19.6},0).wait(2).to({y:-17.9},0).wait(2).to({y:-18.3},0).wait(2).to({y:-19.7},0).wait(2).to({y:-22.1},0).wait(2).to({y:-24.3},0).wait(2).to({y:-25.4},0).wait(2).to({y:-25.7},0).wait(13));

	// sitHairWick3
	this.instance_2 = new lib.sitHairWick3("single",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(5.9,-16.5,2.114,1.028,0,2.1,1.7,-5.3,-17.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2).to({scaleX:1.87,scaleY:0.99,skewX:1.5,skewY:1.3,x:8.4,y:-14.8},0).wait(2).to({scaleX:1.62,scaleY:0.96,skewX:1,skewY:0.8,x:10.9,y:-13.2},0).wait(2).to({regX:-5.4,scaleX:1.37,scaleY:0.93,rotation:0.6,skewX:0,skewY:0,x:13.4,y:-11.5},0).wait(2).to({regX:-5.3,scaleX:1.12,scaleY:0.89,rotation:0.1,x:16,y:-9.8},0).wait(2).to({regX:-5.4,regY:-17.4,scaleX:1,scaleY:0.9,rotation:0,x:17.2},0).wait(2).to({scaleY:0.93,y:-11.1},0).wait(2).to({regY:-17.3,scaleY:0.95,y:-12},0).wait(2).to({regY:-17.4,scaleY:0.97,y:-12.8},0).wait(2).to({regY:-17.3,scaleY:0.98,y:-13.4},0).wait(2).to({regY:-17.4,scaleY:0.99,y:-13.9},0).wait(2).to({scaleY:1,y:-14.2},0).wait(2).to({scaleY:1,y:-14.3},0).wait(7).to({startPosition:0},0).wait(2).to({scaleY:0.98,y:-13.3},0).wait(2).to({regY:-17.3,scaleY:0.96,y:-12.5},0).wait(2).to({y:-12.8},0).wait(2).to({y:-13.5},0).wait(2).to({regY:-17.4,scaleY:0.96,y:-14.9},0).wait(2).to({regY:-17.3,scaleY:0.96,y:-16},0).wait(2).to({y:-16.5},0).wait(2).to({regY:-17.4,y:-16.8},0).wait(13));

	// sitHairWick1
	this.instance_3 = new lib.sitHairWick1("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-18,-22.3,0.698,1,0,-1.4,-4.9,0.1,-21.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(2).to({scaleX:0.77,scaleY:0.97,skewX:-1,skewY:-3.8,x:-16.3,y:-20.6},0).wait(2).to({scaleX:0.83,scaleY:0.95,skewX:-0.8,skewY:-2.6,x:-14.6,y:-19},0).wait(2).to({scaleX:0.9,scaleY:0.92,skewX:-0.3,skewY:-1.5,x:-13,y:-17.4},0).wait(2).to({scaleX:0.97,scaleY:0.89,skewX:0,skewY:-0.5,x:-11.3,y:-15.7},0).wait(2).to({regX:0,regY:-21.4,scaleX:1,scaleY:0.9,skewY:0,x:-10.5,y:-15.8},0).wait(2).to({scaleY:0.93,y:-17.1},0).wait(2).to({scaleY:0.95,y:-18.3},0).wait(2).to({scaleY:0.97,y:-19.2},0).wait(2).to({scaleY:0.98,y:-20},0).wait(2).to({scaleY:0.99,y:-20.6},0).wait(2).to({scaleY:1,y:-20.9},0).wait(2).to({scaleY:1},0).wait(7).to({startPosition:0},0).wait(2).to({scaleY:0.98,y:-19.9},0).wait(2).to({scaleY:0.96,y:-19},0).wait(2).to({y:-19.2},0).wait(2).to({y:-19.9},0).wait(2).to({scaleY:0.96,y:-21.3},0).wait(2).to({scaleY:0.96,y:-22.4},0).wait(2).to({y:-22.9},0).wait(2).to({y:-23.2},0).wait(13));

	// sitGlasses
	this.instance_4 = new lib.sitGlasses("single",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(-7.1,10.7,0.838,1);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(2).to({scaleX:0.87,x:-5.7,y:11.3},0).wait(2).to({scaleX:0.91,x:-4.1,y:11.8},0).wait(2).to({scaleX:0.95,x:-2.7,y:12.4},0).wait(2).to({scaleX:0.98,x:-1.3,y:12.9},0).wait(2).to({scaleX:1,x:-0.5,y:12.8},0).wait(2).to({y:12.2},0).wait(2).to({y:11.8},0).wait(2).to({y:11.4},0).wait(2).to({y:11.1},0).wait(2).to({y:10.9},0).wait(2).to({y:10.8},0).wait(2).to({y:10.7},0).wait(7).to({startPosition:0},0).wait(2).to({y:11.2},0).wait(2).to({y:11.5},0).wait(2).to({y:11.3},0).wait(2).to({y:10.7},0).wait(2).to({y:9.7},0).wait(2).to({y:8.8},0).wait(2).to({y:8.4},0).wait(2).to({y:8.2},0).wait(13));

	// sitNose
	this.instance_5 = new lib.sitNose("single",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(-6,25,0.88,1,0,0,-1.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(2).to({scaleX:0.91,skewY:-1.1,x:-4.5,y:25.5},0).wait(2).to({scaleX:0.93,skewY:-0.8,x:-2.2,y:26.6},0).wait(2).to({scaleX:0.96,skewY:-0.5,x:-0.4,y:27.1},0).wait(2).to({scaleX:0.99,skewY:0,x:1.4,y:28.1},0).wait(2).to({scaleX:1,x:2.3,y:28},0).wait(2).to({y:27.4},0).wait(2).to({y:26.9},0).wait(2).to({y:26.6},0).wait(2).to({y:26.3},0).wait(2).to({y:26},0).wait(2).to({y:25.9},0).wait(2).to({startPosition:0},0).wait(7).to({startPosition:0},0).wait(2).to({y:26.4},0).wait(2).to({y:26.7},0).wait(2).to({y:26.4},0).wait(2).to({y:25.6},0).wait(2).to({y:24.2},0).wait(2).to({y:22.9},0).wait(2).to({y:22.4},0).wait(2).to({y:22.3},0).wait(13));

	// sitHairWick3
	this.instance_6 = new lib.sitHairWick3("single",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(-4.3,-23.1,1.56,0.758,0,-57.9,-58.3,-5.3,-17.5);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(4).to({_off:false},0).wait(2).to({startPosition:0},0).wait(2).to({x:-4.9,y:-20.1},0).wait(2).to({startPosition:0},0).wait(2).to({startPosition:0},0).wait(2).to({startPosition:0},0).wait(2).to({startPosition:0},0).wait(2).to({startPosition:0},0).wait(2).to({startPosition:0},0).wait(2).to({startPosition:0},0).to({_off:true},2).wait(9).to({_off:false,x:-3.7,y:-26},0).wait(2).to({x:-4,y:-24.2},0).wait(2).to({startPosition:0},0).wait(2).to({startPosition:0},0).to({_off:true},2).wait(19));

	// sitFace
	this.instance_7 = new lib.sitFace("synched",1,false);
	this.instance_7.parent = this;
	this.instance_7.setTransform(-1.7,16.7,1.024,1);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(2).to({scaleX:1.02,scaleY:0.99,x:-1.5,y:16.5,startPosition:3},0).wait(2).to({scaleX:1.01,scaleY:0.98,x:-1.4,y:16.3,startPosition:5},0).wait(2).to({scaleX:1.01,scaleY:0.97,x:-1.2,y:16,startPosition:7},0).wait(2).to({scaleX:1,scaleY:0.97,x:-1,y:15.8,startPosition:9},0).wait(2).to({scaleX:1,x:-0.9,mode:"single",startPosition:0},0).wait(2).to({scaleY:0.97,y:16.1},0).wait(2).to({scaleY:0.98,y:16.5},0).wait(2).to({scaleY:0.99,y:16.8},0).wait(2).to({scaleY:0.99,y:16.9},0).wait(2).to({scaleY:1,y:17.1},0).wait(2).to({scaleY:1},0).wait(2).to({scaleY:1,y:17.2},0).wait(7).to({startPosition:0},0).wait(2).to({scaleY:0.99,y:16.8},0).wait(2).to({scaleY:0.98,y:16.6},0).wait(2).to({scaleY:0.98},0).wait(2).to({scaleY:0.98,y:16.4},0).wait(2).to({scaleY:0.97,y:16.1},0).wait(2).to({scaleY:0.97,y:15.9},0).wait(2).to({scaleY:0.96,y:15.8},0).wait(2).to({scaleY:0.96,y:15.7},0).wait(13));

	// sitEar
	this.instance_8 = new lib.sitEar("single",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(-25.3,20.2,1,1,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(2).to({x:-25.9,y:19.9},0).wait(2).to({x:-26.5,y:19.7},0).wait(2).to({x:-27.1,y:19.4},0).wait(2).to({x:-27.7,y:19.1},0).wait(2).to({x:-28,y:19.3},0).wait(2).to({y:19.5},0).wait(2).to({y:19.7},0).wait(2).to({y:19.9},0).wait(2).to({y:20.1},0).wait(2).to({startPosition:0},0).wait(2).to({y:20.2},0).wait(2).to({startPosition:0},0).wait(7).to({startPosition:0},0).wait(2).to({y:19.7},0).wait(2).to({y:19.2},0).wait(2).to({y:19.1},0).wait(2).to({y:18.7},0).wait(2).to({y:18},0).wait(2).to({y:17.4},0).wait(2).to({y:17.1},0).wait(2).to({y:17},0).wait(13));

	// sitHair
	this.instance_9 = new lib.sitHair("single",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(5.3,-17.3,1.167,1);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(2).to({scaleX:1.13,scaleY:1.01,x:4,y:-17.9},0).wait(2).to({scaleX:1.09,scaleY:1.02,x:2.7,y:-18.4},0).wait(2).to({scaleX:1.06,scaleY:1.03,x:1.4,y:-19},0).wait(2).to({scaleX:1.02,scaleY:1.04,x:0.1,y:-19.5},0).wait(2).to({scaleX:1,scaleY:1.04,x:-0.6,y:-18.6},0).wait(2).to({scaleY:1.03,y:-18.2},0).wait(2).to({scaleY:1.02,y:-18},0).wait(2).to({scaleY:1.01,y:-17.7},0).wait(2).to({scaleY:1.01,y:-17.5},0).wait(2).to({scaleY:1,y:-17.4},0).wait(2).to({scaleY:1},0).wait(2).to({scaleY:1,y:-17.3},0).wait(7).to({startPosition:0},0).wait(2).to({y:-18.1},0).wait(2).to({y:-18.7},0).wait(2).to({y:-18.4},0).wait(2).to({y:-17.4},0).wait(2).to({y:-15.7},0).wait(2).to({y:-14.1},0).wait(2).to({y:-13.3},0).wait(2).to({y:-13.1},0).wait(13));

	// sitear
	this.instance_10 = new lib.sitEar("single",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(27.2,18.7,1.121,1);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(2).to({scaleX:1.09,x:27.1},0).wait(2).to({scaleX:1.07,x:27,y:18.8},0).wait(2).to({scaleX:1.04,y:18.9},0).wait(2).to({scaleX:1.01,x:26.9},0).wait(2).to({scaleX:1,x:26.8,y:19.3},0).wait(2).to({y:19.5},0).wait(2).to({y:19.7},0).wait(2).to({y:19.9},0).wait(2).to({y:20.1},0).wait(2).to({startPosition:0},0).wait(2).to({y:20.2},0).wait(2).to({startPosition:0},0).wait(7).to({startPosition:0},0).wait(2).to({y:19.7},0).wait(2).to({y:19.2},0).wait(2).to({y:19.1},0).wait(2).to({y:18.7},0).wait(2).to({y:18},0).wait(2).to({y:17.4},0).wait(2).to({y:17.1},0).wait(2).to({y:17},0).wait(13));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-38.5,-54.3,83.4,108.1);


(lib.sit = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// sitHead
	this.instance = new lib.sitHead("synched",0,false);
	this.instance.parent = this;
	this.instance.setTransform(-10,-115.7,1.155,1.155,-11.6,0,0,0.5,50);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({regX:0.6,scaleX:1.1,scaleY:1.1,rotation:-9.3,x:-10.3,y:-103.4,startPosition:2},0).wait(2).to({scaleX:1.06,scaleY:1.06,rotation:-7.6,x:-10.5,y:-93.7,startPosition:4},0).wait(2).to({regX:0.5,scaleX:1.02,scaleY:1.02,rotation:-6.5,x:-10.8,y:-86.7,startPosition:6},0).wait(2).to({regX:0.6,scaleX:1.01,scaleY:1.01,rotation:-5.8,y:-82.7,startPosition:8},0).wait(2).to({regX:0.5,scaleX:1,scaleY:1,rotation:-5.6,x:-10.9,y:-81.3,startPosition:10},0).wait(2).to({regY:50.1,scaleX:1,scaleY:1,rotation:-5.3,y:-81.4,startPosition:12},0).wait(2).to({regY:50,rotation:-4.8,y:-81.9,startPosition:14},0).wait(2).to({scaleX:1,scaleY:1,rotation:-3.8,y:-82.9,startPosition:16},0).wait(2).to({regX:0.4,rotation:-2.8,y:-84,startPosition:18},0).wait(2).to({rotation:-2,y:-83.9,startPosition:20},0).wait(2).to({rotation:-0.3,x:-11.1,y:-83.4,startPosition:22},0).wait(2).to({regX:0.3,rotation:0,x:-11,y:-83.3,startPosition:24},0).wait(9).to({rotation:1.3,y:-81.6,startPosition:33},0).wait(2).to({regX:0.2,regY:50.1,rotation:2.3,y:-80.2,startPosition:35},0).wait(2).to({regX:0.3,regY:50,rotation:2.9,x:-10.9,y:-79.4,startPosition:37},0).wait(2).to({rotation:1.8,y:-81.1,startPosition:39},0).wait(2).to({rotation:0.8,x:-11,y:-82.5,startPosition:41},0).wait(2).to({rotation:0,x:-10.9,y:-83.7,startPosition:43},0).wait(2).to({rotation:-0.5,x:-11,y:-84.6,startPosition:45},0).wait(2).to({rotation:-1,y:-85.3,startPosition:47},0).wait(2).to({rotation:-1.3,y:-85.8,startPosition:49},0).wait(2).to({regX:0.2,rotation:-1.5,x:-11.1,y:-86,startPosition:51},0).wait(2));

	// sitLeg
	this.instance_1 = new lib.sitLeg();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-20,53.3,1,1,0,0,0,-43.8,-58);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(2).to({y:53.7},0).wait(2).to({y:54},0).wait(2).to({y:54.2},0).wait(4).to({y:54.4},0).wait(2).to({y:54.3},0).wait(2).to({y:53.9},0).wait(2).to({y:53.3},0).wait(2).to({y:52.4},0).wait(2).to({y:52.8},0).wait(2).to({y:53.7},0).wait(2).to({y:54},0).wait(29));

	// sitHand
	this.instance_2 = new lib.sitHand();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-7.7,-31.7,0.532,0.653,-5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2).to({scaleX:0.51,scaleY:0.62,x:-8.3,y:-19.6},0).wait(2).to({scaleX:0.49,scaleY:0.6,x:-8.9,y:-10.1},0).wait(2).to({regY:-0.1,scaleX:0.47,scaleY:0.58,x:-9.1,y:-3.4},0).wait(2).to({regY:0,scaleX:0.46,scaleY:0.57,x:-9.4,y:0.7},0).wait(2).to({regY:0.1,scaleX:0.46,scaleY:0.56,y:2.1},0).wait(2).to({regY:0},0).wait(2).to({regY:0.1,y:2.4},0).wait(2).to({regY:0,y:2.9},0).wait(2).to({regY:0.1,y:3.7},0).wait(2).to({y:4},0).wait(2).to({y:4.6},0).wait(2).to({scaleX:0.46,scaleY:0.56,y:4.7},0).wait(9).to({regY:0,scaleX:0.46,scaleY:0.56,y:4.9},0).wait(2).to({regY:0.1,y:5.1},0).wait(2).to({scaleX:0.46,scaleY:0.56,y:5.2},0).wait(2).to({scaleX:0.46,scaleY:0.56,y:5.4},0).wait(2).to({y:5.6},0).wait(2).to({regY:0,y:5.7},0).wait(2).to({regY:0.1,y:5.9},0).wait(2).to({regY:0},0).wait(2).to({regY:0.1,y:6},0).wait(2).to({scaleX:0.46,scaleY:0.56,y:6.1},0).wait(2));

	// sitSkirt
	this.instance_3 = new lib.sitSkirt();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-8.8,41.6,1,0.627,0,0,0,-0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(2).to({regX:0,regY:0,scaleY:0.65,x:-9.4,y:50.2},0).wait(2).to({scaleY:0.8,x:-10,y:64.6},0).wait(2).to({scaleY:0.91,x:-10.4,y:75},0).wait(2).to({scaleY:0.98,x:-10.7,y:81.2},0).wait(2).to({scaleY:1,x:-10.8,y:83.2},0).wait(2).to({y:83.1},0).wait(2).to({y:82.7},0).wait(2).to({y:82.1},0).wait(2).to({y:81.2},0).wait(2).to({y:81.6},0).wait(2).to({y:82.5},0).wait(2).to({y:82.8},0).wait(29));

	// sitBag
	this.instance_4 = new lib.sitBag("single",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(-6.8,-27.5,0.409,0.409,-2);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(2).to({scaleX:0.39,scaleY:0.39,x:-7.5,y:-15.5},0).wait(2).to({scaleX:0.37,scaleY:0.37,x:-7.9,y:-6.2},0).wait(2).to({scaleX:0.36,scaleY:0.36,x:-8.3,y:0.4},0).wait(2).to({scaleX:0.36,scaleY:0.36,x:-8.6,y:4.4},0).wait(2).to({scaleX:0.35,scaleY:0.35,y:5.7},0).wait(2).to({y:5.8},0).wait(2).to({y:6.1},0).wait(2).to({y:6.7},0).wait(2).to({y:7.4},0).wait(2).to({y:7.6},0).wait(2).to({y:8.2},0).wait(2).to({y:8.4},0).wait(9).to({y:8.6},0).wait(2).to({y:8.7},0).wait(2).to({y:8.8},0).wait(2).to({y:9.1},0).wait(2).to({y:9.2},0).wait(2).to({y:9.4},0).wait(2).to({y:9.5},0).wait(2).to({y:9.6},0).wait(2).to({y:9.7},0).wait(4));

	// sitForeArm
	this.instance_5 = new lib.sitForeArm("single",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(55.9,-9.3,0.585,0.547,0,19.3,16.3,51.4,7.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(2).to({regX:51.3,scaleX:0.56,scaleY:0.52,skewX:26.3,skewY:24.3,x:50,y:11.8},0).wait(2).to({regX:51.5,scaleX:0.55,scaleY:0.5,skewX:31.6,skewY:30.6,x:45.4,y:28.2},0).wait(2).to({regX:51.3,regY:7.5,scaleX:0.53,scaleY:0.48,skewX:35.6,skewY:35.1,x:42.1,y:39.7},0).wait(2).to({regY:7.4,scaleX:0.53,scaleY:0.48,skewX:37.8,skewY:37.6,x:40.1,y:46.8},0).wait(2).to({regX:51.2,regY:7.3,scaleX:0.53,scaleY:0.47,rotation:38.6,skewX:0,skewY:0,x:39.5,y:49.1},0).wait(2).to({scaleX:0.52,scaleY:0.47,x:39.2},0).wait(2).to({regX:51.1,regY:7.4,scaleX:0.51,rotation:0,skewX:38.6,skewY:38.9,x:38.6},0).wait(2).to({regX:51.3,regY:7.2,scaleX:0.5,skewY:39.3,x:37.6,y:49},0).wait(2).to({scaleX:0.49,scaleY:0.47,skewY:39.9,x:36.1,y:48.9},0).wait(2).to({regY:7,scaleX:0.48,scaleY:0.47,skewY:39.6,x:35.8,y:49.1},0).wait(2).to({regX:51.4,regY:7.1,scaleX:0.47,skewY:38.8,x:35.1,y:49.6},0).wait(2).to({regY:7.3,scaleX:0.47,scaleY:0.47,rotation:38.6,skewX:0,skewY:0,x:34.8,y:49.7},0).wait(9).to({regY:7.4,rotation:0,skewX:38.6,skewY:37.4,x:35.5,y:48.8},0).wait(2).to({regY:7.3,skewY:36.4,x:36.2,y:48.1},0).wait(2).to({scaleX:0.47,skewY:35.8,x:36.5,y:47.6},0).wait(2).to({regY:7.4,scaleX:0.47,skewY:36.6,x:36,y:48.5},0).wait(2).to({regY:7.3,skewY:37.1,x:35.7,y:49.2},0).wait(2).to({regX:51.5,regY:7.4,skewY:37.6,x:35.5,y:49.9},0).wait(2).to({regY:7.3,skewY:38.1,x:35.2,y:50.3},0).wait(2).to({regY:7.4,skewY:38.3,x:35,y:50.7},0).wait(2).to({regX:51.4,rotation:38.6,skewX:0,skewY:0,x:34.9,y:50.9},0).wait(4));

	// sitForeArm
	this.instance_6 = new lib.sitForeArm("single",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(-71.1,-14.1,0.535,0.547,0,-18.6,162.7,51.2,7.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(2).to({regX:51.1,regY:7.6,scaleX:0.53,scaleY:0.52,skewX:-31.1,skewY:150.2,x:-66.7,y:9.7},0).wait(2).to({regY:7.5,scaleY:0.5,skewX:-40.9,skewY:140.4,x:-63.3,y:28.1},0).wait(2).to({regX:51.2,regY:7.6,scaleX:0.55,scaleY:0.48,skewX:-47.9,skewY:133.4,x:-61.9,y:42.4},0).wait(2).to({regX:51.1,regY:7.5,scaleX:0.55,scaleY:0.48,skewX:-51.9,skewY:129.3,x:-60.6,y:50.5},0).wait(2).to({regX:51.3,regY:7.6,scaleX:0.55,scaleY:0.47,skewX:-53.4,skewY:127.9,x:-60.2,y:53.4},0).wait(2).to({regX:51.2,regY:7.5,scaleX:0.55,scaleY:0.47,skewY:128.1,x:-60,y:52.9},0).wait(2).to({regX:51.5,regY:7.7,scaleX:0.54,skewY:127.4,x:-59.2,y:53.4},0).wait(2).to({regX:51.3,regY:7.5,scaleX:0.53,skewY:127.1,x:-58,y:53},0).wait(2).to({regY:7.6,scaleX:0.52,scaleY:0.47,skewY:127.5,x:-57.6,y:52.4},0).wait(2).to({regX:51.2,regY:7.7,scaleX:0.52,scaleY:0.47,skewY:126.8,x:-56.7,y:52.8},0).wait(2).to({regX:51.1,scaleX:0.53,skewY:125.9,x:-55.7,y:53.3},0).wait(11).to({regX:51.7,regY:7.5,scaleX:0.54,scaleY:0.47,skewY:126.2,x:-56.1,y:54.1},0).wait(2).to({regX:51.5,scaleX:0.55,skewY:126.7,x:-56.6,y:54.4},0).wait(2).to({regX:51.4,regY:7.2,scaleX:0.55,skewX:-53.3,skewY:126.5,x:-56.5,y:54.8},0).wait(2).to({regX:51.3,regY:7.5,scaleX:0.54,skewX:-53.4,skewY:127,x:-56.6,y:54},0).wait(2).to({regY:7.3,scaleX:0.53,skewY:127.2,x:-56.2,y:52.9},0).wait(2).to({regY:7.5,scaleX:0.53,skewY:127.6,y:52.5},0).wait(2).to({regX:51.4,regY:7.3,scaleX:0.52,skewY:127.4,x:-55.8,y:52.1},0).wait(2).to({regX:51.1,regY:7.2,scaleX:0.52,skewY:127.3,x:-55.6,y:51.8},0).wait(2).to({regY:7.5,scaleX:0.51,skewY:128.1,y:50.5},0).wait(4));

	// sitNeckShadow
	this.instance_7 = new lib.sitNeckShadow("single",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(-8,-117.3,1.156,1.355,0,-2,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(2).to({scaleX:1.1,scaleY:1.23,skewX:-1.3,x:-8.8,y:-103.4},0).wait(2).to({scaleX:1.06,scaleY:1.13,skewX:-0.6,x:-9.5,y:-92.7},0).wait(2).to({scaleX:1.02,scaleY:1.06,skewX:-0.3,x:-9.9,y:-84.9},0).wait(2).to({scaleX:1.01,scaleY:1.01,skewX:0,x:-10.2,y:-80.3},0).wait(2).to({scaleX:1,scaleY:1,x:-10.3,y:-78.8},0).wait(2).to({y:-78.9},0).wait(2).to({y:-79.3},0).wait(2).to({y:-79.9},0).wait(2).to({y:-80.8},0).wait(2).to({y:-80.4},0).wait(2).to({y:-79.5},0).wait(2).to({y:-79.2},0).wait(9).to({y:-78.6},0).wait(2).to({y:-78.2},0).wait(2).to({y:-77.9},0).wait(2).to({scaleX:0.99,scaleY:1.06,skewY:-0.5,x:-10.4,y:-78.8},0).wait(2).to({scaleX:0.99,scaleY:1.12,skewY:-1.1,x:-10.5,y:-79.6},0).wait(2).to({scaleX:0.98,scaleY:1.16,skewY:-1.5,x:-10.6,y:-80.2},0).wait(2).to({scaleX:0.97,scaleY:1.2,skewY:-2,y:-80.8},0).wait(2).to({scaleX:0.97,scaleY:1.23,skewY:-2.3,x:-10.7,y:-81.2},0).wait(2).to({scaleX:0.97,scaleY:1.24,skewY:-2.5,y:-81.4},0).wait(2).to({scaleX:0.97,scaleY:1.25,skewY:-2.6,y:-81.5},0).wait(2));

	// sitBust
	this.instance_8 = new lib.sitBust("synched",1,false);
	this.instance_8.parent = this;
	this.instance_8.setTransform(-8.7,-28.7,0.547,0.473);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(2).to({scaleX:0.52,x:-9.2,y:-12.6,startPosition:3},0).wait(2).to({scaleX:0.5,x:-9.7,y:-0.2,startPosition:5},0).wait(2).to({scaleX:0.49,x:-10,y:8.7,startPosition:7},0).wait(2).to({scaleX:0.48,x:-10.2,y:14.1,startPosition:9},0).wait(2).to({scaleX:0.47,x:-10.3,y:15.9,mode:"single",startPosition:0},0).wait(2).to({y:15.7},0).wait(2).to({y:15.4},0).wait(2).to({y:14.7},0).wait(2).to({y:13.9},0).wait(2).to({y:14.3},0).wait(2).to({y:15.2},0).wait(2).to({y:15.4},0).wait(9).to({y:16},0).wait(2).to({y:16.5},0).wait(2).to({y:16.8},0).wait(2).to({y:16},0).wait(2).to({y:15.3},0).wait(2).to({y:14.7},0).wait(2).to({y:14.3},0).wait(2).to({y:13.9},0).wait(2).to({y:13.7},0).wait(2).to({y:13.6},0).wait(2));

	// sitArm
	this.instance_9 = new lib.sitArm("single",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(-60.7,-86.4,0.547,0.37,0,10,-170,4.6,-101.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(2).to({regY:-101.5,scaleX:0.52,scaleY:0.41,skewX:7.5,skewY:-172.5,x:-58.9,y:-69.7},0).wait(2).to({regY:-101.4,scaleX:0.5,scaleY:0.44,skewX:5.6,skewY:-174.4,x:-57.5,y:-56.6},0).wait(2).to({regX:4.5,scaleX:0.49,scaleY:0.46,skewX:4.3,skewY:-175.7,x:-56.5,y:-47.2},0).wait(2).to({regX:4.7,regY:-101.3,scaleX:0.48,scaleY:0.47,skewX:3.5,skewY:-176.5,x:-55.9,y:-41.5},0).wait(2).to({regX:4.6,regY:-101.5,scaleX:0.47,scaleY:0.47,skewX:3.3,skewY:-176.7,x:-55.7,y:-39.8},0).wait(2).to({regX:4.7,skewX:3,skewY:-177,y:-39.9},0).wait(2).to({regX:4.6,skewX:2.5,skewY:-177.5,y:-40.3},0).wait(2).to({regX:4.5,skewX:1.6,skewY:-178.4,y:-40.9},0).wait(2).to({skewX:0.5,skewY:-179.5,y:-41.7},0).wait(2).to({regY:-101.6,skewX:0,skewY:-180,y:-41.4},0).wait(2).to({skewX:-1.3,skewY:-181.3,x:-55.6,y:-40.4},0).wait(2).to({regY:-101.4,skewX:-1.8,skewY:-181.8,x:-55.7,y:-40.2},0).wait(9).to({regX:4.6,skewX:-1.3,y:-39.6},0).wait(2).to({regX:4.5,skewX:-1,y:-39.1},0).wait(2).to({regX:4.7,regY:-101.5,skewX:-0.8,x:-55.8,y:-38.9},0).wait(2).to({regX:4.8,skewX:-1,y:-39.7},0).wait(2).to({regX:4.7,skewX:-1.3,y:-40.4},0).wait(2).to({x:-55.7,y:-40.9},0).wait(2).to({regX:4.6,skewX:-1.5,y:-41.3},0).wait(2).to({regX:4.7,y:-41.7},0).wait(2).to({skewX:-1.8,x:-55.6,y:-41.9},0).wait(2).to({regX:4.5,regY:-101.4,x:-55.7,y:-42},0).wait(2));

	// sitArm
	this.instance_10 = new lib.sitArm("single",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(42.3,-86.8,0.547,0.402,-11.3,0,0,4.3,-101.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(2).to({regY:-101.5,scaleX:0.52,scaleY:0.43,rotation:-8.3,x:39.7,y:-69.9},0).wait(2).to({regX:4.4,regY:-101.4,scaleX:0.5,scaleY:0.45,rotation:-6,x:37.8,y:-56.6},0).wait(2).to({regX:4.3,regY:-101.6,scaleX:0.49,scaleY:0.46,rotation:-4.5,x:36.3,y:-47.3},0).wait(2).to({regY:-101.5,scaleX:0.48,scaleY:0.47,rotation:-3.5,x:35.5,y:-41.7},0).wait(2).to({regX:4.5,regY:-101.4,scaleX:0.47,scaleY:0.47,rotation:-3.3,x:35.2,y:-39.7},0).wait(2).to({rotation:-3,y:-39.8},0).wait(2).to({rotation:-2.5,y:-40.2},0).wait(2).to({rotation:-1.8,y:-40.8},0).wait(2).to({regY:-101.5,rotation:-1,y:-41.8},0).wait(2).to({regX:4.6,rotation:-0.3,y:-41.3},0).wait(2).to({regX:4.5,rotation:1.3,y:-40.4},0).wait(2).to({regY:-101.4,rotation:1.8,x:35.3,y:-40.2},0).wait(9).to({regX:4.4,rotation:0,skewX:1.5,skewY:1.8,x:35.2,y:-39.6},0).wait(2).to({regX:4.5,skewX:1.3,x:35.4,y:-39.2},0).wait(2).to({regY:-101.5,skewX:1.1,x:35.3,y:-38.9},0).wait(2).to({skewX:1.3,x:35.2,y:-39.7},0).wait(2).to({y:-40.4},0).wait(2).to({skewX:1.5,y:-40.9},0).wait(2).to({y:-41.3},0).wait(2).to({regX:4.6,rotation:1.8,skewX:0,skewY:0,y:-41.7},0).wait(2).to({y:-41.9},0).wait(2).to({regX:4.5,regY:-101.4,x:35.3,y:-42},0).wait(2));

	// sitNeck
	this.instance_11 = new lib.sitNeck("single",0);
	this.instance_11.parent = this;
	this.instance_11.setTransform(-7.6,-112.3,1.156,0.933,0,0,0,-0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(2).to({scaleX:1.1,scaleY:0.96,x:-8.2,y:-96.4},0).wait(2).to({scaleX:1.06,scaleY:0.98,x:-8.7,y:-84.1},0).wait(2).to({scaleX:1.02,scaleY:0.99,x:-9.1,y:-75.3},0).wait(2).to({regX:0,scaleX:1.01,scaleY:1,x:-9.2,y:-69.9},0).wait(2).to({scaleX:1,scaleY:1,y:-68.2},0).wait(2).to({y:-68.3},0).wait(2).to({y:-68.7},0).wait(2).to({y:-69.3},0).wait(2).to({y:-70.2},0).wait(2).to({y:-69.8},0).wait(2).to({y:-68.9},0).wait(2).to({y:-68.6},0).wait(9).to({y:-68},0).wait(2).to({y:-67.6},0).wait(2).to({y:-67.3},0).wait(2).to({y:-68.1},0).wait(2).to({y:-68.8},0).wait(2).to({y:-69.3},0).wait(2).to({y:-69.8},0).wait(2).to({y:-70.1},0).wait(2).to({y:-70.3},0).wait(2).to({y:-70.4},0).wait(2));

	// sitHairWick
	this.instance_12 = new lib.sitHairWick2("single",0);
	this.instance_12.parent = this;
	this.instance_12.setTransform(-9.9,-115.9,1.155,1.155,-11.6,0,0,-0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(2).to({scaleX:1.1,scaleY:1.1,rotation:-9.5,x:-10.2,y:-104},0).wait(2).to({regX:0,regY:0,scaleX:1.06,scaleY:1.06,rotation:-8,x:-10.4,y:-94.8},0).wait(2).to({regX:-0.1,regY:-0.1,scaleX:1.02,scaleY:1.02,rotation:-6.8,x:-10.7,y:-88.2},0).wait(2).to({scaleX:1.01,scaleY:1.01,rotation:-6.1,x:-10.9,y:-84.2},0).wait(2).to({scaleX:1,scaleY:1,rotation:-6,y:-82.9},0).wait(2).to({scaleX:1,scaleY:1,rotation:-5.5,y:-83.1},0).wait(2).to({rotation:-4.5,y:-83.4},0).wait(2).to({scaleX:1,scaleY:1,rotation:-2.8,y:-84},0).wait(2).to({regX:0,regY:0,rotation:-0.6,y:-84.9},0).wait(2).to({rotation:0.3,y:-84.5},0).wait(2).to({rotation:2.1,y:-83.6},0).wait(15).to({rotation:2.7,y:-83.3},0).wait(2).to({scaleY:1.03,rotation:2.6,y:-83.8},0).wait(2).to({scaleY:1.05,y:-84.3},0).wait(2).to({scaleY:1.07,x:-10.8,y:-84.7},0).wait(2).to({regX:-0.1,regY:-0.1,scaleY:1.09,x:-10.9,y:-85.1},0).wait(2).to({regX:0,regY:0,scaleY:1.1,x:-10.8,y:-85.2},0).wait(2).to({scaleY:1.11,y:-85.4},0).wait(2).to({scaleY:1.11,rotation:2.7,y:-85.5},0).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-85.6,-244.1,165.4,432.5);


(lib.legFront = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// knee
	this.instance = new lib.kneeFront("single",0);
	this.instance.parent = this;
	this.instance.setTransform(96.5,39.3,1.234,0.995,0,3.7,0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({skewX:10.8,skewY:7.4,x:80.5,y:43.1},2).to({skewX:16,skewY:12.6,x:68.4,y:44.3},2).to({scaleX:1.22,scaleY:1,skewX:22.7,skewY:18,x:52.8,y:43.5},2).to({scaleX:1.22,scaleY:1,skewX:21.3,skewY:18.3,x:44.1,y:41.9},2).to({scaleX:1.22,scaleY:1,skewX:24.5,skewY:23,x:25.6,y:35.8},2).to({scaleX:1.21,scaleY:1.01,skewX:21.9,skewY:20.1,x:19.3,y:32.9},2).to({_off:true},1).wait(1).to({_off:false},0).to({scaleX:1.07,scaleY:1.01,skewX:40.4,skewY:45.2,x:26,y:37.3},2).to({scaleX:1.07,scaleY:1.01,skewX:39.9,x:30.7,y:37},2).to({scaleX:1.07,scaleY:1.01,skewX:35.5,skewY:39.4,x:51.7,y:37.9},2).to({scaleX:1.07,scaleY:1.01,skewX:29.3,skewY:33.8,x:72.8,y:38.6},2).to({skewX:7.9,skewY:12.3,x:90,y:28.7},2).to({scaleX:1.23,scaleY:1,skewX:3.7,skewY:0.2,x:96.5,y:39.3},4).wait(1));

	// thigh
	this.instance_1 = new lib.thighFront("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(48.1,-87,1.001,1.071,0,1.7,-0.3,-21.8,-53.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regY:-53.4,skewX:8.9,skewY:6.9,x:48.4,y:-86.8},2).to({regX:-21.9,regY:-53.5,skewX:14.1,skewY:12.1,x:48.2,y:-87},2).to({regY:-53.4,scaleX:0.99,scaleY:1.08,skewX:20.8,skewY:17.4,x:48,y:-87.3},2).to({scaleX:0.99,scaleY:1.05,skewX:25.5,skewY:19.8,x:48.1,y:-87.1},2).to({scaleX:0.99,scaleY:1.02,skewX:34.8,skewY:26.6,x:47.8,y:-86.9},2).to({scaleX:0.97,scaleY:1.04,skewX:38.2,skewY:28.8,x:47.7,y:-87.1},2).to({_off:true},1).wait(1).to({_off:false,scaleX:0.99,scaleY:1.02,skewX:36.4,skewY:28.3,x:47.9},0).to({regY:-53.6,scaleX:1,scaleY:1,skewX:34.7,skewY:27.8,x:48.1,y:-86.9},2).to({scaleX:1,scaleY:1,skewX:32.4,skewY:25.6,x:47.9,y:-87.1},2).to({regY:-53.7,scaleX:1,skewX:22.3,skewY:15.3,x:47.5,y:-87.3},2).to({regX:-22,regY:-53.6,scaleX:1,scaleY:1,skewX:12.3,skewY:5.4,y:-87.2},2).to({skewX:5,skewY:-1.8,x:47.6,y:-86.9},2).to({regX:-21.8,regY:-53.5,scaleX:1,scaleY:1.07,skewX:1.7,skewY:-0.3,x:48.1,y:-87},4).wait(1));

	// tibia
	this.instance_2 = new lib.tibiaFront("single",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(86.7,38.2,1.001,1,0,-3.8,-4.6,-6.4,-73.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({regX:-6.5,skewX:0.4,skewY:-0.4,x:71,y:42.2},2).to({regX:-6.4,scaleX:1,skewX:2.7,skewY:1.8,x:58.8,y:43.4},2).to({scaleX:1,scaleY:1,skewX:6.8,skewY:4.8,x:42.6,y:43},2).to({scaleX:1,scaleY:1,skewX:10.3,skewY:8.5,x:34.2,y:37.7},2).to({regX:-6.6,regY:-73.6,scaleX:1,scaleY:1,skewX:18.5,skewY:16.8,x:16.3,y:30.1},2).to({regX:-6.5,scaleX:0.99,scaleY:1.01,skewX:17,skewY:13.6,x:8.3,y:30.9},2).to({_off:true},1).wait(1).to({_off:false,regY:-73.5,scaleX:0.99,scaleY:1.01,skewX:25.8,skewY:26.3,x:11.8,y:32.7},0).to({regX:-6.4,scaleX:1,skewX:34.9,skewY:38.9,x:15.3,y:34.1},2).to({scaleX:1,scaleY:1.01,skewX:36.3,skewY:40.3,x:20,y:33.9},2).to({regX:-6.5,scaleX:1,scaleY:1.01,skewX:31.3,skewY:35.3,x:40.5,y:35.6},2).to({regX:-6.4,scaleX:1,scaleY:1.01,skewX:26.2,skewY:30.2,x:61.6,y:37.5},2).to({regX:-6.5,skewX:10,skewY:14,x:79.8,y:31.5},2).to({regX:-6.4,scaleX:1,scaleY:1,skewX:-3.8,skewY:-4.6,x:86.7,y:38.2},4).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(14.6,-130.6,117.8,374.7);


(lib.legBack = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// knee
	this.instance = new lib.kneeBack("single",0);
	this.instance.parent = this;
	this.instance.setTransform(96.5,39.3,1.234,0.995,0,3.7,0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({skewX:10.8,skewY:7.4,x:80.5,y:43.1},2).to({skewX:16,skewY:12.6,x:68.4,y:44.3},2).to({scaleX:1.22,scaleY:1,skewX:22.7,skewY:18,x:52.8,y:43.5},2).to({scaleX:1.22,scaleY:1,skewX:21.3,skewY:18.3,x:44.1,y:41.9},2).to({scaleX:1.22,scaleY:1,skewX:24.5,skewY:23,x:25.6,y:35.8},2).to({scaleX:1.21,scaleY:1.01,skewX:21.9,skewY:20.1,x:19.3,y:32.9},2).to({scaleX:1.07,scaleY:1.01,skewX:40.4,skewY:45.2,x:26,y:37.3},4).to({scaleX:1.07,scaleY:1.01,skewX:39.9,x:30.7,y:37},2).to({scaleX:1.07,scaleY:1.01,skewX:35.5,skewY:39.4,x:51.7,y:37.9},2).to({scaleX:1.07,scaleY:1.01,skewX:29.3,skewY:33.8,x:72.8,y:38.6},2).to({skewX:7.9,skewY:12.3,x:90,y:28.7},2).to({scaleX:1.23,scaleY:1,skewX:3.7,skewY:0.2,x:96.5,y:39.3},4).wait(1));

	// thigh
	this.instance_1 = new lib.thighBack("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(48.1,-87,1.001,1.071,0,1.7,-0.3,-21.8,-53.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regY:-53.4,skewX:8.9,skewY:6.9,x:48.4,y:-86.8},2).to({regX:-21.9,regY:-53.5,skewX:14.1,skewY:12.1,x:48.2,y:-87},2).to({regY:-53.4,scaleX:0.99,scaleY:1.08,skewX:20.8,skewY:17.4,x:48,y:-87.3},2).to({scaleX:0.99,scaleY:1.05,skewX:25.5,skewY:19.8,x:48.1,y:-87.1},2).to({scaleX:0.99,scaleY:1.02,skewX:34.8,skewY:26.6,x:47.8,y:-86.9},2).to({scaleX:0.97,scaleY:1.04,skewX:38.2,skewY:28.8,x:47.7,y:-87.1},2).to({regY:-53.6,scaleX:1,scaleY:1,skewX:34.7,skewY:27.8,x:48.1,y:-86.9},4).to({scaleX:1,scaleY:1,skewX:32.4,skewY:25.6,x:47.9,y:-87.1},2).to({regY:-53.7,scaleX:1,skewX:22.3,skewY:15.3,x:47.5,y:-87.3},2).to({regX:-22,regY:-53.6,scaleX:1,scaleY:1,skewX:12.3,skewY:5.4,y:-87.2},2).to({skewX:5,skewY:-1.8,x:47.6,y:-86.9},2).to({regX:-21.8,regY:-53.5,scaleX:1,scaleY:1.07,skewX:1.7,skewY:-0.3,x:48.1,y:-87},4).wait(1));

	// tibia
	this.instance_2 = new lib.tibiaBack("single",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(86.7,38.2,1.001,1,0,-3.8,-4.6,-6.4,-73.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({regX:-6.5,skewX:0.4,skewY:-0.4,x:71,y:42.2},2).to({regX:-6.4,scaleX:1,skewX:2.7,skewY:1.8,x:58.8,y:43.4},2).to({scaleX:1,scaleY:1,skewX:6.8,skewY:4.8,x:42.6,y:43},2).to({scaleX:1,scaleY:1,skewX:10.3,skewY:8.5,x:34.2,y:37.7},2).to({regX:-6.6,regY:-73.6,scaleX:1,scaleY:1,skewX:18.5,skewY:16.8,x:16.3,y:30.1},2).to({regX:-6.5,scaleX:0.99,scaleY:1.01,skewX:17,skewY:13.6,x:8.3,y:30.9},2).to({regX:-6.4,regY:-73.5,scaleX:1,scaleY:1.01,skewX:34.9,skewY:38.9,x:15.3,y:34.1},4).to({scaleX:1,scaleY:1.01,skewX:36.3,skewY:40.3,x:20,y:33.9},2).to({regX:-6.5,scaleX:1,scaleY:1.01,skewX:31.3,skewY:35.3,x:40.5,y:35.6},2).to({regX:-6.4,scaleX:1,scaleY:1.01,skewX:26.2,skewY:30.2,x:61.6,y:37.5},2).to({regX:-6.5,skewX:10,skewY:14,x:79.8,y:31.5},2).to({regX:-6.4,scaleX:1,scaleY:1,skewX:-3.8,skewY:-4.6,x:86.7,y:38.2},4).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(15.6,-130.6,116.3,367.7);


(lib.chair = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// textReserved
	this.textReserved = new lib.textReserved();
	this.textReserved.parent = this;
	this.textReserved.setTransform(-30,91.5,1,1,0,0,0,269,12.5);

	this.timeline.addTween(cjs.Tween.get(this.textReserved).wait(1));

	// Layer 3
	this.instance = new lib._300x600_chairText();
	this.instance.parent = this;
	this.instance.setTransform(-119,67);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer 2
	this.instance_1 = new lib._300x600_chair();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-233,-304);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.chair, new cjs.Rectangle(-299,-304,538.1,612), null);


(lib.ModulePrice = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"idle":0,"show":4,"shown":79});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_79 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(79).call(this.frame_79).wait(7));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AoknzIPnAAIAAPnIvnAAg");
	var mask_graphics_27 = new cjs.Graphics().p("EAnnghcIALALMhPYBPXIgLgLg");
	var mask_graphics_28 = new cjs.Graphics().p("EAgfgsrIOaOaMhPXBPXIuauag");
	var mask_graphics_29 = new cjs.Graphics().p("EAaHg1QIbKbKMhPXBPXI7K7Kg");
	var mask_graphics_30 = new cjs.Graphics().p("EAUgg63MAmYAmYMhPXBPXMgmYgmYg");
	var mask_graphics_31 = new cjs.Graphics().p("EAPog/vMAwIAwIMhPXBPXMgwIgwIg");
	var mask_graphics_32 = new cjs.Graphics().p("EALghD3MA4YA4YMhPXBPXMg4Yg4Yg");
	var mask_graphics_33 = new cjs.Graphics().p("EAIIhHPMA/IA/HMhPXBPYMg/Ig/Hg");
	var mask_graphics_34 = new cjs.Graphics().p("EAFhhJ2MBEWBEWMhPXBPXMhEWhEWg");
	var mask_graphics_35 = new cjs.Graphics().p("EADphLuMBIGBIGMhPXBPXMhIGhIGg");
	var mask_graphics_36 = new cjs.Graphics().p("EAChhM2MBKWBKWMhPXBPXMhKWhKWg");
	var mask_graphics_37 = new cjs.Graphics().p("EACJhNOMBLGBLGMhPXBPXMhLGhLGg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-54.9,y:50}).wait(27).to({graphics:mask_graphics_27,x:166.8,y:295}).wait(1).to({graphics:mask_graphics_28,x:159.4,y:314.2}).wait(1).to({graphics:mask_graphics_29,x:152.8,y:322}).wait(1).to({graphics:mask_graphics_30,x:146.9,y:316.4}).wait(1).to({graphics:mask_graphics_31,x:141.9,y:311.5}).wait(1).to({graphics:mask_graphics_32,x:137.6,y:307.4}).wait(1).to({graphics:mask_graphics_33,x:134.1,y:304}).wait(1).to({graphics:mask_graphics_34,x:131.4,y:301.4}).wait(1).to({graphics:mask_graphics_35,x:129.4,y:299.5}).wait(1).to({graphics:mask_graphics_36,x:128.2,y:298.4}).wait(1).to({graphics:mask_graphics_37,x:138.5,y:307.1}).wait(49));

	// textPrice
	this.textPrice = new lib.text_price();
	this.textPrice.parent = this;

	var maskedShapeInstanceList = [this.textPrice];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.textPrice).wait(86));

	// sides
	this.sides = new lib.sides();
	this.sides.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.sides).wait(86));

	// logo
	this.logo = new lib.logo_airfrance();
	this.logo.parent = this;
	this.logo.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(9).to({alpha:1},12).wait(65));

	// strokes
	this.strokes = new lib.strokes();
	this.strokes.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.strokes).wait(86));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("A0xZyMAAAgzjMApjAAAMAAAAzjg");
	var mask_1_graphics_26 = new cjs.Graphics().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:150,y:212}).wait(26).to({graphics:mask_1_graphics_26,x:150,y:300}).wait(60));

	// background
	this.background = new lib.square();
	this.background.parent = this;
	this.background.setTransform(-59.7,48.9,1,1,0,0,0,50.3,49.9);

	var maskedShapeInstanceList = [this.background];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.background).wait(4).to({regX:58.3,regY:49.8,scaleX:0.01,scaleY:7,rotation:45,x:171.5,y:305.6},0).to({regX:56,regY:49.6,scaleX:7.12,x:171.9,y:304.1},15,cjs.Ease.get(1)).wait(67));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-110,-111,519.1,842.1);


(lib.ModuleOhlalaPrice = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"idle":0,"show":4,"shown":79});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_79 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(79).call(this.frame_79).wait(7));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AoknzIPnAAIAAPnIvnAAg");
	var mask_graphics_27 = new cjs.Graphics().p("EAnnghcIALALMhPYBPXIgLgLg");
	var mask_graphics_28 = new cjs.Graphics().p("EAgfgsrIOaOaMhPXBPXIuauag");
	var mask_graphics_29 = new cjs.Graphics().p("EAaHg1QIbKbKMhPXBPXI7K7Kg");
	var mask_graphics_30 = new cjs.Graphics().p("EAUgg63MAmYAmYMhPXBPXMgmYgmYg");
	var mask_graphics_31 = new cjs.Graphics().p("EAPog/vMAwIAwIMhPXBPXMgwIgwIg");
	var mask_graphics_32 = new cjs.Graphics().p("EALghD3MA4YA4YMhPXBPXMg4Yg4Yg");
	var mask_graphics_33 = new cjs.Graphics().p("EAIIhHPMA/IA/HMhPXBPYMg/Ig/Hg");
	var mask_graphics_34 = new cjs.Graphics().p("EAFhhJ2MBEWBEWMhPXBPXMhEWhEWg");
	var mask_graphics_35 = new cjs.Graphics().p("EADphLuMBIGBIGMhPXBPXMhIGhIGg");
	var mask_graphics_36 = new cjs.Graphics().p("EAChhM2MBKWBKWMhPXBPXMhKWhKWg");
	var mask_graphics_37 = new cjs.Graphics().p("EACJhNOMBLGBLGMhPXBPXMhLGhLGg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-54.9,y:50}).wait(27).to({graphics:mask_graphics_27,x:166.8,y:295}).wait(1).to({graphics:mask_graphics_28,x:159.4,y:314.2}).wait(1).to({graphics:mask_graphics_29,x:152.8,y:322}).wait(1).to({graphics:mask_graphics_30,x:146.9,y:316.4}).wait(1).to({graphics:mask_graphics_31,x:141.9,y:311.5}).wait(1).to({graphics:mask_graphics_32,x:137.6,y:307.4}).wait(1).to({graphics:mask_graphics_33,x:134.1,y:304}).wait(1).to({graphics:mask_graphics_34,x:131.4,y:301.4}).wait(1).to({graphics:mask_graphics_35,x:129.4,y:299.5}).wait(1).to({graphics:mask_graphics_36,x:128.2,y:298.4}).wait(1).to({graphics:mask_graphics_37,x:138.5,y:307.1}).wait(49));

	// title
	this.title = new lib.ohlalaTitle();
	this.title.parent = this;
	this.title.setTransform(69.8,84.5,0.75,0.75);

	var maskedShapeInstanceList = [this.title];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.title).wait(86));

	// textPrice
	this.textPrice = new lib.text_ohlalaPrice();
	this.textPrice.parent = this;

	var maskedShapeInstanceList = [this.textPrice];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.textPrice).wait(86));

	// sides
	this.sides = new lib.sides();
	this.sides.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.sides).wait(86));

	// logo
	this.logo = new lib.logo_airfrance();
	this.logo.parent = this;
	this.logo.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(9).to({alpha:1},12).wait(65));

	// strokes
	this.strokes = new lib.strokes();
	this.strokes.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.strokes).wait(86));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("A0xZyMAAAgzjMApjAAAMAAAAzjg");
	var mask_1_graphics_26 = new cjs.Graphics().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:150,y:212}).wait(26).to({graphics:mask_1_graphics_26,x:150,y:300}).wait(60));

	// background
	this.background = new lib.square();
	this.background.parent = this;
	this.background.setTransform(-59.7,48.9,1,1,0,0,0,50.3,49.9);

	var maskedShapeInstanceList = [this.background];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.background).wait(4).to({regX:58.3,regY:49.8,scaleX:0.01,scaleY:7,rotation:45,x:171.5,y:305.6},0).to({regX:56,regY:49.6,scaleX:7.12,x:171.9,y:304.1},15,cjs.Ease.get(1)).wait(67));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-110,-111,519.1,842.1);


(lib.ModuleOhlalaImage = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"idle":0,"show":4,"shown":54});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_54 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(54).call(this.frame_54).wait(7));

	// title
	this.title = new lib.ohlalaTitleBig();
	this.title.parent = this;
	this.title.setTransform(28.1,442,1,1,0,0,0,0.1,0);
	this.title.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.title).wait(7).to({alpha:1},12).wait(42));

	// sides
	this.sides = new lib.sides();
	this.sides.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.sides).wait(61));

	// logo
	this.logo = new lib.logo_airfrance();
	this.logo.parent = this;
	this.logo.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(9).to({alpha:1},12).wait(40));

	// strokes
	this.strokes = new lib.strokes();
	this.strokes.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.strokes).wait(61));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A0xZyMAAAgzjMApjAAAMAAAAzjg");
	mask.setTransform(150,212);

	// fade
	this.fade = new lib.square();
	this.fade.parent = this;
	this.fade.setTransform(148.2,213.2,4.573,4.709,45,0,0,50.2,49.4);

	var maskedShapeInstanceList = [this.fade];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.fade).wait(4).to({regX:50.1,regY:49.5,scaleX:0.01,x:147.7,y:213.3},11).to({_off:true},1).wait(45));

	// content
	this.content = new lib.imageContent();
	this.content.parent = this;

	var maskedShapeInstanceList = [this.content];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.content).wait(61));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-110,-111,519.1,842.1);


(lib.ModuleOhlalaEndshot = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"idle":0,"show":4,"shown":79});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_79 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(79).call(this.frame_79).wait(7));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AopnzIPnAAIAAPnIvnAAg");
	var mask_graphics_11 = new cjs.Graphics().p("EAnnghcIALALMhPYBPXIgLgLg");
	var mask_graphics_12 = new cjs.Graphics().p("EAgfgsrIOaOaMhPXBPXIuauag");
	var mask_graphics_13 = new cjs.Graphics().p("EAaHg1QIbKbKMhPXBPXI7K7Kg");
	var mask_graphics_14 = new cjs.Graphics().p("EAUgg63MAmYAmYMhPXBPXMgmYgmYg");
	var mask_graphics_15 = new cjs.Graphics().p("EAPog/vMAwIAwIMhPXBPXMgwIgwIg");
	var mask_graphics_16 = new cjs.Graphics().p("EALghD3MA4YA4YMhPXBPXMg4Yg4Yg");
	var mask_graphics_17 = new cjs.Graphics().p("EAIIhHPMA/IA/HMhPXBPYMg/Ig/Hg");
	var mask_graphics_18 = new cjs.Graphics().p("EAFhhJ2MBEWBEWMhPXBPXMhEWhEWg");
	var mask_graphics_19 = new cjs.Graphics().p("EADphLuMBIGBIGMhPXBPXMhIGhIGg");
	var mask_graphics_20 = new cjs.Graphics().p("EAChhM2MBKWBKWMhPXBPXMhKWhKWg");
	var mask_graphics_21 = new cjs.Graphics().p("EACJhNOMBLGBLGMhPXBPXMhLGhLGg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-55.4,y:50}).wait(11).to({graphics:mask_graphics_11,x:166.8,y:295}).wait(1).to({graphics:mask_graphics_12,x:159.4,y:314.2}).wait(1).to({graphics:mask_graphics_13,x:152.8,y:322}).wait(1).to({graphics:mask_graphics_14,x:146.9,y:316.4}).wait(1).to({graphics:mask_graphics_15,x:141.9,y:311.5}).wait(1).to({graphics:mask_graphics_16,x:137.6,y:307.4}).wait(1).to({graphics:mask_graphics_17,x:134.1,y:304}).wait(1).to({graphics:mask_graphics_18,x:131.4,y:301.4}).wait(1).to({graphics:mask_graphics_19,x:129.4,y:299.5}).wait(1).to({graphics:mask_graphics_20,x:128.2,y:298.4}).wait(1).to({graphics:mask_graphics_21,x:138.5,y:307.1}).wait(65));

	// title
	this.title = new lib.ohlalaTitle();
	this.title.parent = this;
	this.title.setTransform(69.8,54.5,0.75,0.75);

	var maskedShapeInstanceList = [this.title];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.title).wait(86));

	// textPricesEndshotHolder
	this.textPricesEndshotHolder = new lib.empty();
	this.textPricesEndshotHolder.parent = this;

	var maskedShapeInstanceList = [this.textPricesEndshotHolder];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.textPricesEndshotHolder).wait(86));

	// logo
	this.logo = new lib.logo_airfrance();
	this.logo.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(86));

	// sides
	this.sides = new lib.sides();
	this.sides.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.sides).wait(86));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("A0xZyMAAAgzjMApjAAAMAAAAzjg");
	mask_1.setTransform(150,212);

	// background
	this.background = new lib.square();
	this.background.parent = this;
	this.background.setTransform(-59.7,48.9,1,1,0,0,0,50.3,49.9);

	var maskedShapeInstanceList = [this.background];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.background).wait(4).to({regX:58.3,regY:49.8,scaleX:0.01,scaleY:7,rotation:45,x:171.5,y:305.6},0).to({regX:56,regY:49.6,scaleX:7.12,x:171.9,y:304.1},15,cjs.Ease.get(1)).wait(67));

	// header
	this.header = new lib.header();
	this.header.parent = this;
	this.header.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.header).wait(4).to({alpha:1},0).wait(82));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-110,0,519.1,600);


(lib.ModuleImage = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"idle":0,"show":4,"shown":54});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_54 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(54).call(this.frame_54).wait(7));

	// sides
	this.sides = new lib.sides();
	this.sides.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.sides).wait(61));

	// logo
	this.logo = new lib.logo_airfrance();
	this.logo.parent = this;
	this.logo.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(9).to({alpha:1},12).wait(40));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AoknzIPnAAIAAPnIvnAAg");
	var mask_graphics_23 = new cjs.Graphics().p("EAnjgUKIASASMhPXBPXIgSgSg");
	var mask_graphics_24 = new cjs.Graphics().p("EAjegaNIIcIbMhPXBPXIocobg");
	var mask_graphics_25 = new cjs.Graphics().p("Af1/oIPuPvMhPXBPXIvuvvg");
	var mask_graphics_26 = new cjs.Graphics().p("EAcngkaIWLWLMhPYBPXI2L2Lg");
	var mask_graphics_27 = new cjs.Graphics().p("EAZ0gojIbwbwMhPXBPXI7w7wg");
	var mask_graphics_28 = new cjs.Graphics().p("EAXdgsEMAgeAgfMhPXBPXMggeggfg");
	var mask_graphics_29 = new cjs.Graphics().p("EAVhgu7MAkWAkWMhPXBPXMgkWgkWg");
	var mask_graphics_30 = new cjs.Graphics().p("EAUBgxKMAnWAnWMhPXBPXMgnWgnWg");
	var mask_graphics_31 = new cjs.Graphics().p("EAS8gywMApgApgMhPXBPXMgpggpgg");
	var mask_graphics_32 = new cjs.Graphics().p("EASTgztMAqyAqyMhPXBPXMgqygqyg");
	var mask_graphics_33 = new cjs.Graphics().p("EASFg0DMArOArOMhPXBPYMgrOgrOg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-54.9,y:50}).wait(23).to({graphics:mask_graphics_23,x:137.8,y:380.7}).wait(1).to({graphics:mask_graphics_24,x:138.6,y:394.1}).wait(1).to({graphics:mask_graphics_25,x:139.3,y:406.2}).wait(1).to({graphics:mask_graphics_26,x:140,y:416.8}).wait(1).to({graphics:mask_graphics_27,x:140.5,y:426}).wait(1).to({graphics:mask_graphics_28,x:141,y:433.8}).wait(1).to({graphics:mask_graphics_29,x:141.4,y:440.2}).wait(1).to({graphics:mask_graphics_30,x:141.7,y:445.1}).wait(1).to({graphics:mask_graphics_31,x:141.9,y:448.7}).wait(1).to({graphics:mask_graphics_32,x:142,y:450.8}).wait(1).to({graphics:mask_graphics_33,x:141.9,y:451.5}).wait(28));

	// textPrice
	this.textPrice = new lib.text_imagePrice();
	this.textPrice.parent = this;

	var maskedShapeInstanceList = [this.textPrice];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.textPrice).wait(61));

	// strokes
	this.strokes = new lib.strokes();
	this.strokes.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.strokes).wait(61));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("A0xZyMAAAgzjMApjAAAMAAAAzjg");
	mask_1.setTransform(150,212);

	// fade
	this.fade = new lib.square();
	this.fade.parent = this;
	this.fade.setTransform(148.2,213.2,4.573,4.709,45,0,0,50.2,49.4);

	var maskedShapeInstanceList = [this.fade];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.fade).wait(4).to({regX:50.1,regY:49.5,scaleX:0.01,x:147.7,y:213.3},11).to({_off:true},1).wait(45));

	// content
	this.content = new lib.imageContent();
	this.content.parent = this;

	var maskedShapeInstanceList = [this.content];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.content).wait(61));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-110,-111,519.1,842.1);


(lib.ModuleEndshot = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"idle":0,"show":4,"shown":79});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_79 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(79).call(this.frame_79).wait(7));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AopnzIPnAAIAAPnIvnAAg");
	var mask_graphics_11 = new cjs.Graphics().p("EAnnghcIALALMhPYBPXIgLgLg");
	var mask_graphics_12 = new cjs.Graphics().p("EAgfgsrIOaOaMhPXBPXIuauag");
	var mask_graphics_13 = new cjs.Graphics().p("EAaHg1QIbKbKMhPXBPXI7K7Kg");
	var mask_graphics_14 = new cjs.Graphics().p("EAUgg63MAmYAmYMhPXBPXMgmYgmYg");
	var mask_graphics_15 = new cjs.Graphics().p("EAPog/vMAwIAwIMhPXBPXMgwIgwIg");
	var mask_graphics_16 = new cjs.Graphics().p("EALghD3MA4YA4YMhPXBPXMg4Yg4Yg");
	var mask_graphics_17 = new cjs.Graphics().p("EAIIhHPMA/IA/HMhPXBPYMg/Ig/Hg");
	var mask_graphics_18 = new cjs.Graphics().p("EAFhhJ2MBEWBEWMhPXBPXMhEWhEWg");
	var mask_graphics_19 = new cjs.Graphics().p("EADphLuMBIGBIGMhPXBPXMhIGhIGg");
	var mask_graphics_20 = new cjs.Graphics().p("EAChhM2MBKWBKWMhPXBPXMhKWhKWg");
	var mask_graphics_21 = new cjs.Graphics().p("EACJhNOMBLGBLGMhPXBPXMhLGhLGg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-55.4,y:50}).wait(11).to({graphics:mask_graphics_11,x:166.8,y:295}).wait(1).to({graphics:mask_graphics_12,x:159.4,y:314.2}).wait(1).to({graphics:mask_graphics_13,x:152.8,y:322}).wait(1).to({graphics:mask_graphics_14,x:146.9,y:316.4}).wait(1).to({graphics:mask_graphics_15,x:141.9,y:311.5}).wait(1).to({graphics:mask_graphics_16,x:137.6,y:307.4}).wait(1).to({graphics:mask_graphics_17,x:134.1,y:304}).wait(1).to({graphics:mask_graphics_18,x:131.4,y:301.4}).wait(1).to({graphics:mask_graphics_19,x:129.4,y:299.5}).wait(1).to({graphics:mask_graphics_20,x:128.2,y:298.4}).wait(1).to({graphics:mask_graphics_21,x:138.5,y:307.1}).wait(65));

	// textPricesEndshotHolder
	this.textPricesEndshotHolder = new lib.empty();
	this.textPricesEndshotHolder.parent = this;

	var maskedShapeInstanceList = [this.textPricesEndshotHolder];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.textPricesEndshotHolder).wait(86));

	// logo
	this.logo = new lib.logo_airfrance();
	this.logo.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(86));

	// sides
	this.sides = new lib.sides();
	this.sides.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.sides).wait(86));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("A0xZyMAAAgzjMApjAAAMAAAAzjg");
	mask_1.setTransform(150,212);

	// background
	this.background = new lib.square();
	this.background.parent = this;
	this.background.setTransform(-59.7,48.9,1,1,0,0,0,50.3,49.9);

	var maskedShapeInstanceList = [this.background];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.background).wait(4).to({regX:58.3,regY:49.8,scaleX:0.01,scaleY:7,rotation:45,x:171.5,y:305.6},0).to({regX:56,regY:49.6,scaleX:7.12,x:171.9,y:304.1},15,cjs.Ease.get(1)).wait(67));

	// header
	this.header = new lib.header();
	this.header.parent = this;
	this.header.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.header).wait(4).to({alpha:1},0).wait(82));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-110,0,519.1,600);


(lib.TextPricesEndshot3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// textPriceEndshotLine1
	this.textPriceEndshotLine1 = new lib.text_priceEndshot_line();
	this.textPriceEndshotLine1.parent = this;
	this.textPriceEndshotLine1.setTransform(150,99);

	this.timeline.addTween(cjs.Tween.get(this.textPriceEndshotLine1).wait(1));

	// textPriceEndshotLine2
	this.textPriceEndshotLine2 = new lib.text_priceEndshot_line();
	this.textPriceEndshotLine2.parent = this;
	this.textPriceEndshotLine2.setTransform(150,195);

	this.timeline.addTween(cjs.Tween.get(this.textPriceEndshotLine2).wait(1));

	// textPriceEndshotLine3
	this.textPriceEndshotLine3 = new lib.text_priceEndshot_line();
	this.textPriceEndshotLine3.parent = this;
	this.textPriceEndshotLine3.setTransform(150,291);

	this.timeline.addTween(cjs.Tween.get(this.textPriceEndshotLine3).wait(1));

	// textPriceFrom
	this.textPriceFrom = new lib.text_price_from();
	this.textPriceFrom.parent = this;
	this.textPriceFrom.setTransform(150,358);

	this.timeline.addTween(cjs.Tween.get(this.textPriceFrom).wait(1));

	// textPriceCta
	this.textPriceCta = new lib.text_price_cta();
	this.textPriceCta.parent = this;
	this.textPriceCta.setTransform(150,449);

	this.timeline.addTween(cjs.Tween.get(this.textPriceCta).wait(1));

	// textPriceConditions
	this.textPriceConditions = new lib.text_price_conditions();
	this.textPriceConditions.parent = this;
	this.textPriceConditions.setTransform(150,506);

	this.timeline.addTween(cjs.Tween.get(this.textPriceConditions).wait(1));

	// ctaBackground
	this.ctaBackground = new lib.ctaBackground();
	this.ctaBackground.parent = this;
	this.ctaBackground.setTransform(150.5,447,1,1,0,0,0,66.5,13);

	this.timeline.addTween(cjs.Tween.get(this.ctaBackground).wait(1));

}).prototype = getMCSymbolPrototype(lib.TextPricesEndshot3, new cjs.Rectangle(-439,58.7,1178.1,479.4), null);


(lib.TextPricesEndshot2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// textPriceEndshotLine1
	this.textPriceEndshotLine1 = new lib.text_priceEndshot_line();
	this.textPriceEndshotLine1.parent = this;
	this.textPriceEndshotLine1.setTransform(150,142);

	this.timeline.addTween(cjs.Tween.get(this.textPriceEndshotLine1).wait(1));

	// textPriceEndshotLine2
	this.textPriceEndshotLine2 = new lib.text_priceEndshot_line();
	this.textPriceEndshotLine2.parent = this;
	this.textPriceEndshotLine2.setTransform(150,252);

	this.timeline.addTween(cjs.Tween.get(this.textPriceEndshotLine2).wait(1));

	// textPriceFrom
	this.textPriceFrom = new lib.text_price_from();
	this.textPriceFrom.parent = this;
	this.textPriceFrom.setTransform(150,358);

	this.timeline.addTween(cjs.Tween.get(this.textPriceFrom).wait(1));

	// textPriceCta
	this.textPriceCta = new lib.text_price_cta();
	this.textPriceCta.parent = this;
	this.textPriceCta.setTransform(150,449);

	this.timeline.addTween(cjs.Tween.get(this.textPriceCta).wait(1));

	// textPriceConditions
	this.textPriceConditions = new lib.text_price_conditions();
	this.textPriceConditions.parent = this;
	this.textPriceConditions.setTransform(150,506);

	this.timeline.addTween(cjs.Tween.get(this.textPriceConditions).wait(1));

	// ctaBackground
	this.ctaBackground = new lib.ctaBackground();
	this.ctaBackground.parent = this;
	this.ctaBackground.setTransform(150,447,1,1,0,0,0,66,13);

	this.timeline.addTween(cjs.Tween.get(this.ctaBackground).wait(1));

}).prototype = getMCSymbolPrototype(lib.TextPricesEndshot2, new cjs.Rectangle(-439,101.7,1178.1,436.4), null);


(lib.TextPricesEndshot1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// textPriceEndshotLine1
	this.textPriceEndshotLine1 = new lib.text_priceEndshot_line();
	this.textPriceEndshotLine1.parent = this;
	this.textPriceEndshotLine1.setTransform(150,195);

	this.timeline.addTween(cjs.Tween.get(this.textPriceEndshotLine1).wait(1));

	// textPriceFrom
	this.textPriceFrom = new lib.text_price_from();
	this.textPriceFrom.parent = this;
	this.textPriceFrom.setTransform(150,358);

	this.timeline.addTween(cjs.Tween.get(this.textPriceFrom).wait(1));

	// textPriceCta
	this.textPriceCta = new lib.text_price_cta();
	this.textPriceCta.parent = this;
	this.textPriceCta.setTransform(150,449);

	this.timeline.addTween(cjs.Tween.get(this.textPriceCta).wait(1));

	// textPriceConditions
	this.textPriceConditions = new lib.text_price_conditions();
	this.textPriceConditions.parent = this;
	this.textPriceConditions.setTransform(150,506);

	this.timeline.addTween(cjs.Tween.get(this.textPriceConditions).wait(1));

	// ctaBackground
	this.ctaBackground = new lib.ctaBackground();
	this.ctaBackground.parent = this;
	this.ctaBackground.setTransform(150.5,447,1,1,0,0,0,66.5,13);

	this.timeline.addTween(cjs.Tween.get(this.ctaBackground).wait(1));

}).prototype = getMCSymbolPrototype(lib.TextPricesEndshot1, new cjs.Rectangle(-439,154.7,1178.1,383.4), null);


(lib.walk = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// skirt
	this.instance = new lib.skirt("synched",22,false);
	this.instance.parent = this;
	this.instance.setTransform(73.2,-82,0.777,1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:0.9,y:-84.1,startPosition:24},2).to({scaleX:0.93,y:-82.8,startPosition:25},1).to({scaleX:0.94,y:-82.2,startPosition:26},1).to({scaleX:0.99,y:-80.4,startPosition:27},1).to({y:-79.2,startPosition:0},1).to({scaleX:0.92,y:-77.6,startPosition:2},2).to({scaleX:0.88,y:-76.8,startPosition:3},1).to({regX:0.1,regY:-0.1,scaleX:0.72,y:-81.1,startPosition:7},4).to({regX:0,regY:0,scaleX:0.9,y:-84.1,startPosition:10},3).to({scaleX:0.96,skewY:-0.2,x:72.7,y:-79.4,startPosition:14},4).to({scaleX:0.93,skewY:0,x:72.8,y:-78.5,startPosition:15},1).to({scaleX:0.88,x:73.2,y:-76.8,startPosition:17},2).to({scaleX:0.8,y:-78.9,startPosition:19},2).to({scaleX:0.76,y:-80,startPosition:20},1).to({regX:0.1,regY:-0.1,scaleX:0.72,y:-81.1,startPosition:21},1).wait(1));

	// legFront
	this.instance_1 = new lib.legFront("synched",7);
	this.instance_1.parent = this;
	this.instance_1.setTransform(27,-7.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(3).to({startPosition:10},0).wait(3).to({startPosition:14},0).wait(14).to({startPosition:28},0).wait(1).to({startPosition:0},0).wait(4).to({startPosition:4},0).wait(1).to({startPosition:5},0).wait(2));

	// legBack
	this.instance_2 = new lib.legBack("synched",22);
	this.instance_2.parent = this;
	this.instance_2.setTransform(33.6,-7.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(3).to({startPosition:25},0).wait(3).to({startPosition:0},0).wait(14).to({startPosition:14},0).wait(1).to({startPosition:15},0).wait(4).to({startPosition:19},0).wait(1).to({startPosition:20},0).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-13.5,-251.7,160.9,490.9);


(lib.run = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// skirt
	this.instance = new lib.skirt("synched",10,false);
	this.instance.parent = this;
	this.instance.setTransform(69.3,-84.2,0.896,1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({scaleX:0.96,skewY:-0.2,x:68.8,y:-93.3,startPosition:14},0).to({y:-97.8,startPosition:15},2).to({scaleX:0.91,skewY:0,x:69.2,y:-91.2,startPosition:16},2).to({scaleX:0.84,x:69.3,y:-84.7,startPosition:18},1).to({scaleX:0.76,y:-76.5,startPosition:20},1).to({skewX:-1.1,x:71,y:-76.1,startPosition:22},2).to({scaleX:0.78,scaleY:1,skewX:-2.9,skewY:-2.8,x:69.3,y:-82.2},1).to({scaleX:0.9,scaleY:1,skewX:0,skewY:0,y:-84.2,startPosition:10},1).to({scaleX:0.96,skewY:-0.2,x:68.8,y:-93.3,startPosition:14},1).to({y:-97.8,startPosition:15},2).to({scaleX:0.91,skewY:0,x:69.2,y:-91.2,startPosition:16},2).to({scaleX:0.84,x:69.3,y:-84.7,startPosition:18},1).to({scaleX:0.76,y:-76.5,startPosition:20},1).to({skewX:-1.1,x:71,y:-76.1,startPosition:22},2).wait(1).to({scaleX:0.78,scaleY:1,skewX:-2.9,skewY:-2.8,x:69.3,y:-82.2},0).wait(1));

	// legFront
	this.instance_1 = new lib.legFront("synched",24);
	this.instance_1.parent = this;
	this.instance_1.setTransform(24.6,-4.5,1,1,-2.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({rotation:3.7,x:20.8,y:-23.1,startPosition:28},0).to({rotation:1,x:25.5,y:-26.6,startPosition:0},2).to({scaleY:1,rotation:0,skewX:2.3,x:25.4,y:-21,startPosition:1},2).to({scaleY:1,skewX:0,x:28.7,y:-13.3,startPosition:3},1).to({x:26.5,y:-1.4,startPosition:5},1).to({skewX:-0.6,x:32.7,y:-0.9,startPosition:7},2).to({skewX:0,x:19.8,y:-5.6},1).to({x:27.4,startPosition:10},1).to({rotation:2.5,x:23,y:-26.4,startPosition:14},1).to({rotation:4.2,x:20.1,y:-35,startPosition:15},2).to({rotation:4.5,x:22.2,y:-21,startPosition:16},2).to({rotation:2.5,x:23,y:-17.9,startPosition:18},1).to({rotation:2.7,x:16.8,y:-6.5,startPosition:20},1).to({rotation:4.2,x:14.3,y:-8.9,startPosition:22},2).wait(1).to({scaleX:1,scaleY:1,rotation:0,skewX:2.9,skewY:-2.4,x:26,y:-22.8},0).wait(1));

	// legBack
	this.instance_2 = new lib.legBack("synched",10);
	this.instance_2.parent = this;
	this.instance_2.setTransform(27.4,-5.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({rotation:2.5,x:23,y:-26.4,startPosition:14},0).to({rotation:4.2,x:20.1,y:-35,startPosition:15},2).to({rotation:4.5,x:22.2,y:-21,startPosition:16},2).to({rotation:2.5,x:23,y:-17.9,startPosition:18},1).to({rotation:2.7,x:16.8,y:-6.5,startPosition:20},1).to({rotation:4.2,x:14.3,y:-8.9,startPosition:22},2).to({scaleX:1,scaleY:1,rotation:0,skewX:2.9,skewY:-2.4,x:26,y:-22.8},1).to({scaleX:1,scaleY:1,rotation:-2.7,skewX:0,skewY:0,x:24.6,y:-4.5,startPosition:24},1).to({rotation:3.7,x:20.8,y:-23.1,startPosition:28},1).to({rotation:1,x:25.5,y:-26.6,startPosition:0},2).to({scaleY:1,rotation:0,skewX:2.3,x:25.4,y:-21,startPosition:1},2).to({scaleY:1,skewX:0,x:28.7,y:-13.3,startPosition:3},1).to({x:26.5,y:-1.4,startPosition:5},1).to({skewX:-0.6,x:32.7,y:-0.9,startPosition:7},2).wait(1).to({skewX:0,x:19.8,y:-5.6},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-41.7,-253.9,191.6,488.5);


(lib.end = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_74 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(74).call(this.frame_74).wait(1));

	// fade
	this.instance = new lib.square_1();
	this.instance.parent = this;
	this.instance.setTransform(150,92.5,3,4.05,0,0,0,50,50);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({_off:false},0).to({alpha:0.25},40).wait(26));

	// sit
	this.instance_1 = new lib.sit("synched",2,false);
	this.instance_1.parent = this;
	this.instance_1.setTransform(161.7,183.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(75));

	// balcony
	this.instance_2 = new lib._300x600_balcony();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-1,-1);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(75));

	// chairs
	this.instance_3 = new lib.chairFree();
	this.instance_3.parent = this;
	this.instance_3.setTransform(150.1,295.1,0.481,0.481,0,0,0,-37.4,2);

	this.instance_4 = new lib.chair();
	this.instance_4.parent = this;
	this.instance_4.setTransform(4.1,295.1,0.481,0.481,0,0,0,-37.4,2);

	this.instance_5 = new lib.chair();
	this.instance_5.parent = this;
	this.instance_5.setTransform(297.1,295.1,0.481,0.481,0,0,0,-37.4,2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3}]}).wait(75));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-121.9,-41.9,552.1,484.4);


(lib.chairs = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 4
	this.chair6 = new lib.chair();
	this.chair6.parent = this;
	this.chair6.setTransform(-28.9,-45.6,0.601,0.601);

	this.instance = new lib.chairFree();
	this.instance.parent = this;
	this.instance.setTransform(178.6,-45.6,0.601,0.601);

	this.chair7 = new lib.chair();
	this.chair7.parent = this;
	this.chair7.setTransform(386.1,-45.6,0.601,0.601);

	this.chair1 = new lib.chair();
	this.chair1.parent = this;
	this.chair1.setTransform(-1079.4,-45.6,0.601,0.601);

	this.chair2 = new lib.chair();
	this.chair2.parent = this;
	this.chair2.setTransform(-858.9,-45.6,0.601,0.601);

	this.chair3 = new lib.chair();
	this.chair3.parent = this;
	this.chair3.setTransform(-651.4,-45.6,0.601,0.601);

	this.chair4 = new lib.chair();
	this.chair4.parent = this;
	this.chair4.setTransform(-443.9,-45.6,0.601,0.601);

	this.chair5 = new lib.chair();
	this.chair5.parent = this;
	this.chair5.setTransform(-236.4,-45.6,0.601,0.601);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.chair5},{t:this.chair4},{t:this.chair3},{t:this.chair2},{t:this.chair1},{t:this.chair7},{t:this.instance},{t:this.chair6}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.chairs, new cjs.Rectangle(-1259,-228.1,1788.7,367.6), null);


(lib.animationPlaceContent = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"idle":0,"show":5,"shown":305});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		var self = this;
		self.clipShadow = this.walk_shadow;
		self.RemoveTicker = function()
		{
			createjs.Ticker.removeEventListener("tick", handleTick);
		}
		
		createjs.Ticker.addEventListener("tick", handleTick);
		
		function handleTick(event)
		{
			if (!event.paused)
				self.clipShadow.updateCache();
		}
	}
	this.frame_51 = function() {
		this.clipShadow = this.run_shadow;
	}
	this.frame_105 = function() {
		this.clipShadow = this.stop_shadow;
	}
	this.frame_116 = function() {
		this.RemoveTicker();
	}
	this.frame_305 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(5).call(this.frame_5).wait(46).call(this.frame_51).wait(54).call(this.frame_105).wait(11).call(this.frame_116).wait(189).call(this.frame_305).wait(6));

	// mask1TextAnimationPlace2
	this.mask1TextAnimationPlace2 = new lib.square();
	this.mask1TextAnimationPlace2.parent = this;
	this.mask1TextAnimationPlace2.setTransform(634.8,21.8,1,1,0,0,0,50.3,49.9);

	this.timeline.addTween(cjs.Tween.get(this.mask1TextAnimationPlace2).wait(256).to({scaleX:3.41,scaleY:2.56,skewX:25,x:183.5,y:183.7},0).to({regX:50,scaleX:0.64,x:481.2},19,cjs.Ease.get(1)).to({_off:true},1).wait(35));

	// mask2TextAnimationPlace2
	this.mask2TextAnimationPlace2 = new lib.square();
	this.mask2TextAnimationPlace2.parent = this;
	this.mask2TextAnimationPlace2.setTransform(492.3,21.8,1,1,0,0,0,50.3,49.9);

	this.timeline.addTween(cjs.Tween.get(this.mask2TextAnimationPlace2).wait(259).to({scaleX:0.56,scaleY:2.56,skewX:25,x:40.2,y:183.7},0).to({x:360.2},19,cjs.Ease.get(1)).to({_off:true},1).wait(32));

	// textAnimationPlace2
	this.textAnimationPlace2 = new lib.textAnimationPlace2();
	this.textAnimationPlace2.parent = this;
	this.textAnimationPlace2.setTransform(645.1,218.5,1,1,0,0,0,300,17.2);

	this.timeline.addTween(cjs.Tween.get(this.textAnimationPlace2).wait(256).to({x:150,y:198.2},0).wait(55));

	// mask1TextAnimationPlace1
	this.mask1TextAnimationPlace1 = new lib.square();
	this.mask1TextAnimationPlace1.parent = this;
	this.mask1TextAnimationPlace1.setTransform(364.7,-11.2,1,1,0,0,0,50.3,49.9);

	this.timeline.addTween(cjs.Tween.get(this.mask1TextAnimationPlace1).wait(195).to({scaleX:3.41,scaleY:2.56,skewX:25,x:183.5,y:183.7},0).to({regX:50,scaleX:0.64,x:481.2},19,cjs.Ease.get(1)).to({_off:true},1).wait(96));

	// mask2TextAnimationPlace1
	this.mask2TextAnimationPlace1 = new lib.square();
	this.mask2TextAnimationPlace1.parent = this;
	this.mask2TextAnimationPlace1.setTransform(222.3,-11.2,1,1,0,0,0,50.3,49.9);

	this.timeline.addTween(cjs.Tween.get(this.mask2TextAnimationPlace1).wait(198).to({scaleX:0.56,scaleY:2.56,skewX:25,x:40.2,y:183.7},0).to({x:360.2},19,cjs.Ease.get(1)).to({_off:true},1).wait(93));

	// textAnimationPlace1
	this.textAnimationPlace1 = new lib.textAnimationPlace1();
	this.textAnimationPlace1.parent = this;
	this.textAnimationPlace1.setTransform(645.1,151.9,1,1,0,0,0,300,49.5);

	this.timeline.addTween(cjs.Tween.get(this.textAnimationPlace1).wait(195).to({x:150,y:198.5},0).to({_off:true},61).wait(55));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AymlsIPoAAIAAPnIvoAAg");
	var mask_graphics_170 = new cjs.Graphics().p("EgLNAhHMAx7g+aIASAAMgx6A+agEgZlAhHMAx7g+aIASAAMgx6A+agEgm/AdUMAx7g+aIASAAMgx6A+ag");
	var mask_graphics_171 = new cjs.Graphics().p("EgJ5AhTMAwLg+aIDiAAMgwKA+agEgaNAg7MAwKg+aIDjAAMgwKA+agEgpzAdIMAwLg+aIDiAAMgwKA+ag");
	var mask_graphics_172 = new cjs.Graphics().p("EgIpAhfMAufg+aIGrAAMgufA+agEga0AgvMAugg+aIGqAAMgufA+agEgsgAc8MAufg+aIGrAAMgufA+ag");
	var mask_graphics_173 = new cjs.Graphics().p("EgHcAhqMAs5g+aIJpAAMgs5A+agEgbZAgkMAs5g+aIJpAAMgs4A+agEgvFAcxMAs6g+aIJoAAMgs4A+ag");
	var mask_graphics_174 = new cjs.Graphics().p("EgGUAh0MArYg+aIMfAAMgrYA+agEgb9AgaMArYg+aIMfAAMgrXA+agEgxiAcnMArYg+aIMeAAMgrWA+ag");
	var mask_graphics_175 = new cjs.Graphics().p("EgFOAh+MAp6g+aIPNAAMgp7A+agEgceAgQMAp6g+aIPNAAMgp6A+agEgz4AcdMAp7g+aIPMAAMgp6A+ag");
	var mask_graphics_176 = new cjs.Graphics().p("EgEMAiIMAoig+aIRxAAMgoiA+agEgc+AgGMAoig+aIRxAAMgohA+agEg2GAcTMAojg+aIRwAAMgoiA+ag");
	var mask_graphics_177 = new cjs.Graphics().p("EgDOAiRMAnPg+aIUMAAMgnPA+agA9cf9MAnOg+aIUNAAMgnPA+agEg4MAcKMAnPg+aIULAAMgnOA+ag");
	var mask_graphics_178 = new cjs.Graphics().p("EgCSAiZMAmAg+aIWeAAMgmAA+agA95f1MAmBg+aIWeAAMgmAA+agEg6LAcCMAmBg+aIWeAAMgmAA+ag");
	var mask_graphics_179 = new cjs.Graphics().p("EgBbAihMAk2g+aIYoAAMgk3A+agA+TftMAk2g+aIYoAAMgk2A+agEg8CAb6MAk3g+aIYnAAMgk1A+ag");
	var mask_graphics_180 = new cjs.Graphics().p("EgAoAipMAjxg+aIapAAMgjxA+agA+sflMAjwg+aIaqAAMgjxA+agEg9xAbyMAjxg+aIapAAMgjxA+ag");
	var mask_graphics_181 = new cjs.Graphics().p("EAAHAiwMAiyg+aIchAAMgiyA+agA/DfeMAiwg+aIchAAMgiwA+agEg/ZAbrMAiyg+aIchAAMgiyA+ag");
	var mask_graphics_182 = new cjs.Graphics().p("EAA0Ai2MAh2g+aIeQAAMgh2A+agA/ZfYMAh1g+aIeQAAMgh1A+agEhA5AblMAh2g+aIeQAAMgh2A+ag");
	var mask_graphics_183 = new cjs.Graphics().p("EABdAi8MAg/g+aIf2AAMgg/A+agA/tfSMAg+g+aIf2AAMgg/A+agEhCRAbfMAg/g+aIf2AAMgg/A+ag");
	var mask_graphics_184 = new cjs.Graphics().p("EACDAjCMAgNg+aMAhSAAAMggNA+agA//fMMAgMg+ZMAhTAAAMggNA+ZgEhDhAbZMAgMg+ZMAhUAAAMggNA+Zg");
	var mask_graphics_185 = new cjs.Graphics().p("EACkAjHMAfgg+aMAioAAAMgfgA+agEggPAfHMAffg+ZMAinAAAMgfgA+ZgEhErAbUMAfgg+ZMAioAAAMgfgA+Zg");
	var mask_graphics_186 = new cjs.Graphics().p("EADDAjLMAe2g+aMAj0AAAMge4A+agEggeAfDMAe3g+aMAjyAAAMge3A+agEhFsAbQMAe3g+aMAjzAAAMge3A+ag");
	var mask_graphics_187 = new cjs.Graphics().p("EADdAjPMAeUg+aMAk1AAAMgeTA+agEggrAe/MAeUg+aMAk0AAAMgeTA+agEhGlAbMMAeTg+aMAk2AAAMgeUA+ag");
	var mask_graphics_188 = new cjs.Graphics().p("EAD1AjSMAd0g+aMAlvAAAMgd0A+agEgg2Ae8MAd1g+aMAluAAAMgd1A+agEhHXAbJMAd0g+aMAlvAAAMgd0A+ag");
	var mask_graphics_189 = new cjs.Graphics().p("EAEIAjVMAdag+aMAmhAAAMgdbA+agEgg/Ae5MAdag+aMAmfAAAMgdaA+agEhICAbGMAdbg+aMAmgAAAMgdbA+ag");
	var mask_graphics_190 = new cjs.Graphics().p("EAEYAjXMAdFg+aMAnIAAAMgdFA+agEghHAe3MAdEg+aMAnIAAAMgdFA+agEhIkAbEMAdFg+aMAnIAAAMgdFA+ag");
	var mask_graphics_191 = new cjs.Graphics().p("EAEkAjZMAc0g+aMAnoAAAMgc0A+agEghNAe1MAc0g+aMAnmAAAMgc0A+agEhI/AbCMAc0g+aMAnoAAAMgc1A+ag");
	var mask_graphics_192 = new cjs.Graphics().p("EAEuAjaMAcng+aMAn+AAAMgcoA+agEghSAe0MAcpg+aMAn8AAAMgcpA+agEhJSAbBMAcog+aMAn+AAAMgcpA+ag");
	var mask_graphics_193 = new cjs.Graphics().p("EAEzAjbMAchg+aMAoLAAAMgciA+agEghUAezMAchg+aMAoKAAAMgciA+agEhJeAbAMAchg+aMAoLAAAMgchA+ag");
	var mask_graphics_194 = new cjs.Graphics().p("EAE1AjbMAceg+aMAoPAAAMgceA+agEghVAezMAcfg+aMAoOAAAMgcfA+agEhJiAbAMAcfg+aMAoPAAAMgceA+ag");
	var mask_graphics_195 = new cjs.Graphics().p("EgXbgu4MAu3AAAMAAABdxMgu3AAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-119,y:63.5}).wait(170).to({graphics:mask_graphics_170,x:261.8,y:179.1}).wait(1).to({graphics:mask_graphics_171,x:244.2,y:180.3}).wait(1).to({graphics:mask_graphics_172,x:227.3,y:181.5}).wait(1).to({graphics:mask_graphics_173,x:211.2,y:182.6}).wait(1).to({graphics:mask_graphics_174,x:195.8,y:183.6}).wait(1).to({graphics:mask_graphics_175,x:181.2,y:184.6}).wait(1).to({graphics:mask_graphics_176,x:167.3,y:185.6}).wait(1).to({graphics:mask_graphics_177,x:154.2,y:186.5}).wait(1).to({graphics:mask_graphics_178,x:141.8,y:187.3}).wait(1).to({graphics:mask_graphics_179,x:130.2,y:188.1}).wait(1).to({graphics:mask_graphics_180,x:119.3,y:188.9}).wait(1).to({graphics:mask_graphics_181,x:109.2,y:189.6}).wait(1).to({graphics:mask_graphics_182,x:99.8,y:190.2}).wait(1).to({graphics:mask_graphics_183,x:91.2,y:190.8}).wait(1).to({graphics:mask_graphics_184,x:83.3,y:191.4}).wait(1).to({graphics:mask_graphics_185,x:76.2,y:191.9}).wait(1).to({graphics:mask_graphics_186,x:69.8,y:192.3}).wait(1).to({graphics:mask_graphics_187,x:64.2,y:192.7}).wait(1).to({graphics:mask_graphics_188,x:59.3,y:193}).wait(1).to({graphics:mask_graphics_189,x:55.2,y:193.3}).wait(1).to({graphics:mask_graphics_190,x:51.8,y:193.5}).wait(1).to({graphics:mask_graphics_191,x:49.2,y:193.7}).wait(1).to({graphics:mask_graphics_192,x:47.3,y:193.8}).wait(1).to({graphics:mask_graphics_193,x:46.2,y:193.9}).wait(1).to({graphics:mask_graphics_194,x:45.8,y:193.9}).wait(1).to({graphics:mask_graphics_195,x:150,y:300.1}).wait(116));

	// textBackground
	this.textBackground = new lib.square_1();
	this.textBackground.parent = this;
	this.textBackground.setTransform(150,300,3,6,0,0,0,50,50);

	var maskedShapeInstanceList = [this.textBackground];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.textBackground).wait(311));

	// end
	this.instance = new lib.end();
	this.instance.parent = this;
	this.instance.setTransform(150.5,245.5,1,1,0,0,0,150.5,125.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(117).to({_off:false},0).to({_off:true},78).wait(116));

	// stop
	this.instance_1 = new lib.stop("synched",0,false);
	this.instance_1.parent = this;
	this.instance_1.setTransform(70.3,228.4);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(104).to({_off:false},0).to({_off:true},13).wait(194));

	// stop_shadow
	this.stop_shadow = new lib.stop();
	this.stop_shadow.parent = this;
	this.stop_shadow.setTransform(-32.3,224.6,1.063,0.895,0,-12,0);
	this.stop_shadow.alpha = 0.32;
	this.stop_shadow._off = true;
	this.stop_shadow.filters = [new cjs.ColorFilter(0, 0, 0, 1, 80, 11, 8, 0)];
	this.stop_shadow.cache(-33,-253,185,496);

	this.timeline.addTween(cjs.Tween.get(this.stop_shadow).wait(104).to({_off:false},0).to({_off:true},13).wait(194));

	// run
	this.instance_2 = new lib.run("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(68.5,225.7);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50).to({_off:false},0).to({_off:true},54).wait(207));

	// run_shadow
	this.run_shadow = new lib.run();
	this.run_shadow.parent = this;
	this.run_shadow.setTransform(-21.6,226.9,1.063,0.895,0,-12.1,0);
	this.run_shadow.alpha = 0.32;
	this.run_shadow._off = true;
	this.run_shadow.filters = [new cjs.ColorFilter(0, 0, 0, 1, 80, 11, 8, 0)];
	this.run_shadow.cache(-44,-256,196,493);

	this.timeline.addTween(cjs.Tween.get(this.run_shadow).wait(50).to({_off:false},0).to({_off:true},54).wait(207));

	// walk
	this.instance_3 = new lib.walk("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(64.6,225.8,1,1,0,0,0,0.1,0.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(5).to({_off:false},0).to({_off:true},45).wait(261));

	// walk_shadow
	this.walk_shadow = new lib.walk();
	this.walk_shadow.parent = this;
	this.walk_shadow.setTransform(-21.6,226.9,1.063,0.895,0,-12.1,0);
	this.walk_shadow.alpha = 0.32;
	this.walk_shadow._off = true;
	this.walk_shadow.filters = [new cjs.ColorFilter(0, 0, 0, 1, 80, 11, 8, 0)];
	this.walk_shadow.cache(-15,-254,165,495);

	this.timeline.addTween(cjs.Tween.get(this.walk_shadow).wait(5).to({_off:false},0).to({_off:true},45).wait(261));

	// chairs
	this.chairs = new lib.chairs();
	this.chairs.parent = this;
	this.chairs.setTransform(1147.1,246);

	this.timeline.addTween(cjs.Tween.get(this.chairs).wait(5).to({x:731.2},45).to({x:14.1},54,cjs.Ease.get(0.35)).to({_off:true},13).wait(194));

	// background
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3A1802").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},195).wait(116));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-111.9,-61.1,1788.7,661.1);


(lib.ModuleAnimationPlace = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"idle":0,"show":4,"shown":318});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_318 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(318).call(this.frame_318).wait(7));

	// sides
	this.sides = new lib.sides();
	this.sides.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.sides).wait(325));

	// logo
	this.logo = new lib.logo_airfrance();
	this.logo.parent = this;
	this.logo.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(9).to({alpha:1},12).wait(304));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AoknzIPnAAIAAPnIvnAAg");
	var mask_graphics_23 = new cjs.Graphics().p("EAnjgUKIASASMhPXBPXIgSgSg");
	var mask_graphics_24 = new cjs.Graphics().p("EAjegaNIIcIbMhPXBPXIocobg");
	var mask_graphics_25 = new cjs.Graphics().p("Af1/oIPuPvMhPXBPXIvuvvg");
	var mask_graphics_26 = new cjs.Graphics().p("EAcngkaIWLWLMhPYBPXI2L2Lg");
	var mask_graphics_27 = new cjs.Graphics().p("EAZ0gojIbwbwMhPXBPXI7w7wg");
	var mask_graphics_28 = new cjs.Graphics().p("EAXdgsEMAgeAgfMhPXBPXMggeggfg");
	var mask_graphics_29 = new cjs.Graphics().p("EAVhgu7MAkWAkWMhPXBPXMgkWgkWg");
	var mask_graphics_30 = new cjs.Graphics().p("EAUBgxKMAnWAnWMhPXBPXMgnWgnWg");
	var mask_graphics_31 = new cjs.Graphics().p("EAS8gywMApgApgMhPXBPXMgpggpgg");
	var mask_graphics_32 = new cjs.Graphics().p("EASTgztMAqyAqyMhPXBPXMgqygqyg");
	var mask_graphics_33 = new cjs.Graphics().p("EASFg0DMArOArOMhPXBPYMgrOgrOg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-54.9,y:50}).wait(23).to({graphics:mask_graphics_23,x:137.8,y:380.7}).wait(1).to({graphics:mask_graphics_24,x:138.6,y:394.1}).wait(1).to({graphics:mask_graphics_25,x:139.3,y:406.2}).wait(1).to({graphics:mask_graphics_26,x:140,y:416.8}).wait(1).to({graphics:mask_graphics_27,x:140.5,y:426}).wait(1).to({graphics:mask_graphics_28,x:141,y:433.8}).wait(1).to({graphics:mask_graphics_29,x:141.4,y:440.2}).wait(1).to({graphics:mask_graphics_30,x:141.7,y:445.1}).wait(1).to({graphics:mask_graphics_31,x:141.9,y:448.7}).wait(1).to({graphics:mask_graphics_32,x:142,y:450.8}).wait(1).to({graphics:mask_graphics_33,x:141.9,y:451.5}).wait(292));

	// textPrice
	this.textPrice = new lib.text_imagePrice();
	this.textPrice.parent = this;

	var maskedShapeInstanceList = [this.textPrice];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.textPrice).wait(325));

	// strokes
	this.strokes = new lib.strokes();
	this.strokes.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.strokes).wait(325));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("A0xZyMAAAgzjMApjAAAMAAAAzjg");
	mask_1.setTransform(150,212);

	// fade
	this.fade = new lib.square();
	this.fade.parent = this;
	this.fade.setTransform(148.2,213.2,4.573,4.709,45,0,0,50.2,49.4);

	var maskedShapeInstanceList = [this.fade];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.fade).wait(4).to({regX:50.1,regY:49.5,scaleX:0.01,x:147.7,y:213.3},11).to({_off:true},1).wait(309));

	// content
	this.content = new lib.animationPlaceContent();
	this.content.parent = this;
	this.content.setTransform(772.4,99.7,1,1,0,0,0,772.4,99.7);

	var maskedShapeInstanceList = [this.content];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.content).wait(325));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-110,-111,519.1,842.1);


// stage content:
(lib.template_300x600 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var main = new Main(this);
			main.Init();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;
// library properties:
lib.properties = {
	width: 300,
	height: 600,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/_300x600_balcony.png?1490111063479", id:"_300x600_balcony"},
		{src:"images/_300x600_chair.png?1490111063479", id:"_300x600_chair"},
		{src:"images/_300x600_chairText.png?1490111063479", id:"_300x600_chairText"},
		{src:"images/_300x600_sitArm.png?1490111063479", id:"_300x600_sitArm"},
		{src:"images/_300x600_sitBag.png?1490111063479", id:"_300x600_sitBag"},
		{src:"images/_300x600_sitChest2.png?1490111063479", id:"_300x600_sitChest2"},
		{src:"images/_300x600_sitChest3.png?1490111063479", id:"_300x600_sitChest3"},
		{src:"images/_300x600_sitChest4.png?1490111063479", id:"_300x600_sitChest4"},
		{src:"images/_300x600_sitEar.png?1490111063479", id:"_300x600_sitEar"},
		{src:"images/_300x600_sitFace.png?1490111063479", id:"_300x600_sitFace"},
		{src:"images/_300x600_sitForearm.png?1490111063479", id:"_300x600_sitForearm"},
		{src:"images/_300x600_sitGlasses.png?1490111063479", id:"_300x600_sitGlasses"},
		{src:"images/_300x600_sitHair.png?1490111063479", id:"_300x600_sitHair"},
		{src:"images/_300x600_sitHairWick1.png?1490111063479", id:"_300x600_sitHairWick1"},
		{src:"images/_300x600_sitHairWick2.png?1490111063479", id:"_300x600_sitHairWick2"},
		{src:"images/_300x600_sitHairWick3.png?1490111063479", id:"_300x600_sitHairWick3"},
		{src:"images/_300x600_sitHand.png?1490111063479", id:"_300x600_sitHand"},
		{src:"images/_300x600_sitHeadband.png?1490111063479", id:"_300x600_sitHeadband"},
		{src:"images/_300x600_sitLeg.png?1490111063479", id:"_300x600_sitLeg"},
		{src:"images/_300x600_sitMouth1.png?1490111063479", id:"_300x600_sitMouth1"},
		{src:"images/_300x600_sitMouth2.png?1490111063479", id:"_300x600_sitMouth2"},
		{src:"images/_300x600_sitMouth3a.png?1490111063479", id:"_300x600_sitMouth3a"},
		{src:"images/_300x600_sitMouth3b.png?1490111063479", id:"_300x600_sitMouth3b"},
		{src:"images/_300x600_sitNeck.png?1490111063479", id:"_300x600_sitNeck"},
		{src:"images/_300x600_sitNeckShadow.png?1490111063479", id:"_300x600_sitNeckShadow"},
		{src:"images/_300x600_sitNose.png?1490111063479", id:"_300x600_sitNose"},
		{src:"images/_300x600_sitSkirt.png?1490111063479", id:"_300x600_sitSkirt"},
		{src:"images/_300x600_walkKneeBack.png?1490111063479", id:"_300x600_walkKneeBack"},
		{src:"images/_300x600_walkKneeFront.png?1490111063479", id:"_300x600_walkKneeFront"},
		{src:"images/_300x600_walkThighBack.png?1490111063479", id:"_300x600_walkThighBack"},
		{src:"images/_300x600_walkThighFront.png?1490111063479", id:"_300x600_walkThighFront"},
		{src:"images/_300x600_walkTibiaBack.png?1490111063479", id:"_300x600_walkTibiaBack"},
		{src:"images/_300x600_walkTibiaFront.png?1490111063479", id:"_300x600_walkTibiaFront"},
		{src:"images/_pixel_hack_dont_remove_.png?1490111063479", id:"_pixel_hack_dont_remove_"}
	],
	preloads: []
};




})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{}, AdobeAn = AdobeAn||{});
var lib, images, createjs, ss, AdobeAn;