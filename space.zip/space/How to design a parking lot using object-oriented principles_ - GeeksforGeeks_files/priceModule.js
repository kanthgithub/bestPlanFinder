function PriceModule(headerColor, backgroundColor, priceLine, textFromPriceContent, textFromContent, textCtaContent, textConditionsContent, contentMarge, isOhlala)
{
	var contentMarge = contentMarge;
	var isOhlala = isOhlala;
	
	this.asset = isOhlala ? new lib.ModuleOhlalaPrice() : new lib.ModulePrice();

	var sides = this.asset.sides;
	var strokes = this.asset.strokes;
	var logo = this.asset.logo;
	var background = this.asset.background;
	var textContainer = this.asset.textPrice;
	var textGroupContainer = this.asset.textPrice.textPriceGroup;
	var textFromPrice = textGroupContainer.textPriceFrom;
	var textFrom = textContainer.textPriceFrom;
	var textCta = textContainer.textPriceCta;
	var textConditions = textContainer.textPriceConditions;
	var ctaBackground = textContainer.ctaBackground;
	
	function redraw()
	{
		FormatTextPrice(textGroupContainer, priceLine);
		
		Utils.SetText(textFrom.text, textFromContent);
		Utils.SetText(textCta.text, textCtaContent);
		Utils.SetText(textConditions.text, textConditionsContent);
		
		var textFromSize = textFrom.text.getBounds().width;
		var textCtaSize = textCta.text.getBounds().width;
		var textConditionsSize = textConditions.text.getBounds().width;
		
		if(textFromSize >= stage.canvas.clientWidth - contentMarge)
			textFrom.scaleX = textFrom.scaleY = Math.min(1, (stage.canvas.clientWidth - contentMarge) / textFromSize);
		
		if(textCtaSize >= stage.canvas.clientWidth - contentMarge * 2)
			textCta.scaleX = textCta.scaleY = Math.min(1, (stage.canvas.clientWidth - contentMarge * 2) / textCtaSize);
		
		if(textConditionsSize >= stage.canvas.clientWidth - contentMarge)
			textConditions.scaleX = textConditions.scaleY = Math.min(1, (stage.canvas.clientWidth - contentMarge) / textConditionsSize);
		
		textContainer.ctaBackground.scaleX = (textCta.text.getBounds().width * textCta.scaleX + 30) / 130; //130 = start ctaBackground width
	}
	
	redraw();

	if(isOhlala)
		Utils.SetColor(this.asset.title, headerColor);
	
	Utils.SetColor(sides.left, backgroundColor);
	Utils.SetColor(sides.right, backgroundColor);
	Utils.SetColor(strokes.left, headerColor);
	Utils.SetColor(strokes.right, headerColor);
	Utils.SetColor(strokes.top, headerColor);
	Utils.SetColor(strokes.bottom, headerColor);
	Utils.SetColor(logo, backgroundColor);
	Utils.SetColor(background, backgroundColor);
	
	Utils.SetColor(textFrom, headerColor);
	Utils.SetColor(textCta, headerColor);
	Utils.SetColor(textConditions, backgroundColor);
	Utils.SetColor(ctaBackground, backgroundColor);
	
	Utils.SetColor(textGroupContainer, headerColor);
	
	function FormatTextPrice(textPriceGroup, textContent)//textTitle, textPrice, textCurrency, textAti, currencyIsBefore
	{
		var textTitle = textPriceGroup.textPriceTitle;
		var textPriceFrom = textPriceGroup.textPriceGroupLine2.textPriceFrom;
		var textPrice = textPriceGroup.textPriceGroupLine2.textPricePrice;
		var textCurrency = textPriceGroup.textPriceGroupLine2.textPriceCurrency;
		var textAti = textPriceGroup.textPriceGroupLine2.textPriceAti;
		
		Utils.SetText(textTitle.text, textContent.textTitle);
		Utils.SetText(textPriceFrom.text, textFromPriceContent);
		Utils.SetText(textPrice.text, textContent.textPrice);
		Utils.SetText(textCurrency.text, textContent.textCurrency);
		Utils.SetText(textAti.text, textContent.textAti);
		
		var titleSize = textTitle.text.getBounds().width;
		var priceSize = textPrice.text.getBounds().width;
		var currencySize = textCurrency.text.getBounds().width;
		var atiSize = textAti.text.getBounds().width;
		
		if(!textContent.currencyIsBefore)
		{
			textPrice.x = Math.ceil((priceSize + currencySize) * 0.5 - currencySize);
			textCurrency.x = textPrice.x;
			
				//textPriceFrom.x = Math.ceil(textPrice.x - priceSize + (priceSize + currencySize) * 0.5);
			if(!textContent.asianText) {
				textPriceFrom.x = Math.ceil(textPrice.x - priceSize + (priceSize + currencySize) * 0.5);
			}else{
				textPriceFrom.x = Math.ceil(textCurrency.x + currencySize + 10);
				textPriceFrom.y = Math.ceil(textPrice.y);
			}
		}
		else
		{
			textPrice.x = Math.ceil((priceSize + currencySize + 10) * 0.5);
			textCurrency.x = textPrice.x - priceSize - currencySize - 10;

				//textPriceFrom.x = Math.ceil(textPrice.x - (priceSize + currencySize + 10) * 0.5);
			if(!textContent.asianText) {
				textPriceFrom.x = Math.ceil(textPrice.x - (priceSize + currencySize + 10) * 0.5);
			}else{
				textPrice.x += -5;
				textPriceFrom.x = Math.ceil(textPrice.x + 10);
				textPriceFrom.y = Math.ceil(textPrice.y);
			}
		}

		if(titleSize >= stage.canvas.clientWidth - contentMarge)
			textTitle.scaleX = textTitle.scaleY = Math.min(1, (stage.canvas.clientWidth - contentMarge) / titleSize);
		
		var priceGroupLine2Size = textPriceGroup.textPriceGroupLine2.getBounds().width;
		var scale = 1;
		if(priceGroupLine2Size >= stage.canvas.clientWidth - contentMarge)
			scale = Math.min(1, (stage.canvas.clientWidth - contentMarge) / priceGroupLine2Size);
		
		textPriceGroup.textPriceGroupLine2.scaleX = textPriceGroup.textPriceGroupLine2.scaleY = scale;
	};
}