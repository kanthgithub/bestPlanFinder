function ImageModule(headerColor, backgroundColor, pastBackgroundColor, image_id, textCtaContent, textConditionsContent, contentMarge, isOhlala)
{
	this.asset = isOhlala ? new lib.ModuleOhlalaImage() : new lib.ModuleImage();
	
	var contentMarge = contentMarge;
	var sides = this.asset.sides;
	var fade = this.asset.fade;
	var strokes = this.asset.strokes;
	var logo = this.asset.logo;
	var imageHolder1 = this.asset.content.imageHolder1;
	var imageHolder2 = this.asset.content.imageHolder2;
	
	Utils.SetColor(fade, pastBackgroundColor);
	Utils.SetColor(sides.left, backgroundColor);
	Utils.SetColor(sides.right, backgroundColor);
	Utils.SetColor(strokes.left, headerColor);
	Utils.SetColor(strokes.right, headerColor);
	Utils.SetColor(strokes.top, headerColor);
	Utils.SetColor(strokes.bottom, headerColor);
	Utils.SetColor(logo, backgroundColor);

	if(isOhlala)
	{
		Utils.SetColor(this.asset.title, backgroundColor);
	}
	else
	{
		var textCta = this.asset.textPrice.textPriceCta;
		var textConditions = this.asset.textPrice.textPriceConditions;
		var ctaBackground = this.asset.textPrice.ctaBackground;

		Utils.SetText(textCta.text, textCtaContent);
		//Utils.SetText(textConditions.text, textConditionsContent);
		Utils.SetText(textConditions.text, "");
		
		var textCtaSize = Math.ceil(textCta.text.getBounds().width);
		//var textConditionsSize = Math.ceil(textConditions.text.getBounds().width);
		
		if(textCtaSize >= stage.canvas.clientWidth - contentMarge * 2)
			textCta.scaleX = textCta.scaleY = Math.min(1, (stage.canvas.clientWidth - contentMarge * 2) / textCtaSize);
		
		//if(textConditionsSize >= stage.canvas.clientWidth - contentMarge)
		//textConditions.scaleX = textConditions.scaleY = Math.min(1, (stage.canvas.clientWidth - contentMarge) / textConditionsSize);
		
		ctaBackground.scaleX = (textCta.text.getBounds().width * textCta.scaleX + 30) / 130; //130 = start ctaBackground width

		Utils.SetColor(textCta, headerColor);
		Utils.SetColor(ctaBackground, backgroundColor);
		//Utils.SetColor(textConditions, backgroundColor);
	}
	
	// swap the image
	imageHolder1.addChild(new lib[image_id]());
	imageHolder2.addChild(new lib[image_id]());
	
}