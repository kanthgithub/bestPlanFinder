function AnimationPlaceModule(headerColor, backgroundColor, pastBackgroundColor, textCtaContent, textConditionsContent, textReserved, textContent1, textContent2, contentMarge)
{
	this.asset = new lib.ModuleAnimationPlace();
	
	var contentMarge = contentMarge;
	var sides = this.asset.sides;
	var fade = this.asset.fade;
	var strokes = this.asset.strokes;
	var logo = this.asset.logo;
	var textBackground = this.asset.content.textBackground;
	var text1 = this.asset.content.textAnimationPlace1;
	var text2 = this.asset.content.textAnimationPlace2;
	var mask1text1 = this.asset.content.mask1TextAnimationPlace1;
	var mask1text2 = this.asset.content.mask2TextAnimationPlace1;
	var mask2text1 = this.asset.content.mask1TextAnimationPlace2;
	var mask2text2 = this.asset.content.mask2TextAnimationPlace2;
	var textReserved1 = this.asset.content.chairs.chair1.textReserved;
	var textReserved2 = this.asset.content.chairs.chair2.textReserved;
	var textReserved3 = this.asset.content.chairs.chair3.textReserved;
	var textReserved4 = this.asset.content.chairs.chair4.textReserved;
	var textReserved5 = this.asset.content.chairs.chair5.textReserved;
	var textReserved6 = this.asset.content.chairs.chair6.textReserved;
	var textReserved7 = this.asset.content.chairs.chair7.textReserved;
	
	FormatText(textReserved1, 105, textReserved);
	FormatText(textReserved2, 105, textReserved);
	FormatText(textReserved3, 105, textReserved);
	FormatText(textReserved4, 105, textReserved);
	FormatText(textReserved5, 105, textReserved);
	FormatText(textReserved6, 105, textReserved);
	FormatText(textReserved7, 105, textReserved);
	FormatText(text1, 270, textContent1);
	FormatText(text2, 270, textContent2);

	Utils.SetColor(fade, pastBackgroundColor);
	Utils.SetColor(sides.left, backgroundColor);
	Utils.SetColor(sides.right, backgroundColor);
	Utils.SetColor(strokes.left, headerColor);
	Utils.SetColor(strokes.right, headerColor);
	Utils.SetColor(strokes.top, headerColor);
	Utils.SetColor(strokes.bottom, headerColor);
	Utils.SetColor(logo, backgroundColor);
	Utils.SetColor(textBackground, backgroundColor);
	Utils.SetColor(mask1text1, backgroundColor);
	Utils.SetColor(mask1text2, backgroundColor);
	Utils.SetColor(mask2text1, backgroundColor);
	Utils.SetColor(mask2text2, backgroundColor);
	Utils.SetColor(text1, headerColor);
	Utils.SetColor(text2, headerColor);


	var textCta = this.asset.textPrice.textPriceCta;
	var textConditions = this.asset.textPrice.textPriceConditions;
	var ctaBackground = this.asset.textPrice.ctaBackground;

	Utils.SetText(textCta.text, textCtaContent);
	//Utils.SetText(textConditions.text, textConditionsContent);
	Utils.SetText(textConditions.text, "");

	var textCtaSize = Math.ceil(textCta.text.getBounds().width);
	//var textConditionsSize = Math.ceil(textConditions.text.getBounds().width);
	
	if(textCtaSize >= stage.canvas.clientWidth - contentMarge * 2)
		textCta.scaleX = textCta.scaleY = Math.min(1, (stage.canvas.clientWidth - contentMarge * 2) / textCtaSize);
	
	//if(textConditionsSize >= stage.canvas.clientWidth - contentMarge)
	//textConditions.scaleX = textConditions.scaleY = Math.min(1, (stage.canvas.clientWidth - contentMarge) / textConditionsSize);
	
	ctaBackground.scaleX = (textCta.text.getBounds().width * textCta.scaleX + 30) / 130; //130 = start ctaBackground width

	Utils.SetColor(textCta, headerColor);
	Utils.SetColor(ctaBackground, backgroundColor);
	//Utils.SetColor(textConditions, backgroundColor);


	function FormatText(textfield, sizeMax, textContent)
	{
		Utils.SetText(textfield.text, textContent);
		var textSize = Math.ceil(textfield.text.getBounds().width);
		if(textSize > sizeMax)
			textfield.scaleX = textfield.scaleY = sizeMax / textSize;
	}
}