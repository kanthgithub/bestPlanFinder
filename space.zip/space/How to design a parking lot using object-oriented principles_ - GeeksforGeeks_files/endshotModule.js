function EndshotModule(headerColor, backgroundColor, priceLines, textFromPriceContent, textFromContent, textCtaContent, textConditionsContent, contentMarge, isOhlala)
{
	var contentMarge = contentMarge;
	var isOhlala = isOhlala;
	
	this.asset = isOhlala ? new lib.ModuleOhlalaEndshot() : new lib.ModuleEndshot();
	
	var logo = this.asset.logo;
	var sides = this.asset.sides;
	var background = this.asset.background;
	var header = this.asset.header;
	var textPricesEndshotHolder = this.asset.textPricesEndshotHolder;
	
	var textPricesEndshot;
	var textPricesEndshotList = [];
	var bounds;

	if(priceLines.length == 3)
	{
		textPricesEndshot = isOhlala ? new lib.TextOhlalaPricesEndshot3() : new lib.TextPricesEndshot3();

		textPricesEndshotList.push(textPricesEndshot.textPriceEndshotLine3);
		FormatTextLine(textPricesEndshot.textPriceEndshotLine3, priceLines[2]);
		bounds = textPricesEndshot.textPriceEndshotLine3.getBounds();
		textPricesEndshot.textPriceEndshotLine3.cache(Math.ceil(bounds.x), Math.ceil(bounds.y), Math.ceil(bounds.width), Math.ceil(bounds.height));
	}
	
	if(priceLines.length >= 2)
	{
		if(textPricesEndshot == null)
			textPricesEndshot = isOhlala ? new lib.TextOhlalaPricesEndshot2() : new lib.TextPricesEndshot2();
		
		textPricesEndshotList.push(textPricesEndshot.textPriceEndshotLine2);
		FormatTextLine(textPricesEndshot.textPriceEndshotLine2, priceLines[1]);
		bounds = textPricesEndshot.textPriceEndshotLine2.getBounds();
		textPricesEndshot.textPriceEndshotLine2.cache(Math.ceil(bounds.x), Math.ceil(bounds.y), Math.ceil(bounds.width), Math.ceil(bounds.height));
	}

	if(textPricesEndshot == null)
		textPricesEndshot = isOhlala ? new lib.TextOhlalaPricesEndshot1() : new lib.TextPricesEndshot1();
	
	textPricesEndshotList.push(textPricesEndshot.textPriceEndshotLine1);
	FormatTextLine(textPricesEndshot.textPriceEndshotLine1, priceLines[0]);
	bounds = textPricesEndshot.textPriceEndshotLine1.getBounds();
	textPricesEndshot.textPriceEndshotLine1.cache(Math.ceil(bounds.x), Math.ceil(bounds.y), Math.ceil(bounds.width), Math.ceil(bounds.height));

	var textFrom = textPricesEndshot.textPriceFrom;
	var textCta = textPricesEndshot.textPriceCta;
	var textConditions = textPricesEndshot.textPriceConditions;

	Utils.SetText(textFrom.text, textFromContent);
	Utils.SetText(textCta.text, textCtaContent);
	Utils.SetText(textConditions.text, textConditionsContent);
	
	var textFromSize = Math.ceil(textFrom.text.getBounds().width);
	var textCtaSize = Math.ceil(textCta.text.getBounds().width);
	var textConditionsSize = Math.ceil(textConditions.text.getBounds().width);
	
	if(textFromSize >= stage.canvas.clientWidth - contentMarge)
		textFrom.scaleX = textFrom.scaleY = Math.min(1, (stage.canvas.clientWidth - contentMarge) / textFromSize);
	
	if(textCtaSize >= stage.canvas.clientWidth - contentMarge * 2)
		textCta.scaleX = textCta.scaleY = Math.min(1, (stage.canvas.clientWidth - contentMarge * 2) / textCtaSize);
	
	if(textConditionsSize >= stage.canvas.clientWidth - contentMarge)
		textConditions.scaleX = textConditions.scaleY = Math.min(1, (stage.canvas.clientWidth - contentMarge) / textConditionsSize);
	
	textPricesEndshot.ctaBackground.scaleX = (textCta.text.getBounds().width * textCta.scaleX + 30) / 130; //130 = start ctaBackground width
	
	textPricesEndshotHolder.addChild(textPricesEndshot);

	if(isOhlala)
		Utils.SetColor(this.asset.title, headerColor);
	
	Utils.SetColor(logo, backgroundColor);
	Utils.SetColor(background, backgroundColor);
	Utils.SetColor(header, headerColor);
	Utils.SetColor(sides.left, backgroundColor);
	Utils.SetColor(sides.right, backgroundColor);
	Utils.SetColor(textFrom, headerColor);
	Utils.SetColor(textCta, headerColor);
	Utils.SetColor(textConditions, backgroundColor);
	Utils.SetColor(textPricesEndshot.ctaBackground, backgroundColor);
	
	textPricesEndshotList.forEach(function(element, index, array)
	{
		Utils.SetColor(element, headerColor);
	});
	
	function FormatTextLine(textLine, textContent)//textTitle, textPrice, textCurrency, textAti, currencyIsBefore
	{
		var textTitle = textLine.textPriceTitle;
		var textPriceFrom = textLine.textPricePrice.textPriceFrom;
		var textPrice = textLine.textPricePrice.textPricePrice;
		var textCurrency = textLine.textPricePrice.textPriceCurrency;
		var textAti = textLine.textPriceAti;
		
		Utils.SetText(textTitle.text, textContent.textTitle);
		Utils.SetText(textPriceFrom.text, textFromPriceContent);
		Utils.SetText(textPrice.text, textContent.textPrice);
		Utils.SetText(textCurrency.text, textContent.textCurrency);
		Utils.SetText(textAti.text, textContent.textAti);
		
		var titleSize = Math.ceil(textTitle.text.getBounds().width);
		var priceSize = Math.ceil(textPrice.text.getBounds().width);
		var currencySize = Math.ceil(textCurrency.text.getBounds().width);
		var atiSize = Math.ceil(textAti.text.getBounds().width);

		if(!textContent.currencyIsBefore)
		{
			textPrice.x = Math.ceil((priceSize + currencySize) * 0.5 - currencySize);
			textCurrency.x = textPrice.x;

				//textPriceFrom.x = Math.ceil(textPrice.x - priceSize + (priceSize + currencySize) * 0.5);

			if(!textContent.asianText) {
				textPriceFrom.x = Math.ceil(textPrice.x - priceSize + (priceSize + currencySize) * 0.5);
			}else{
				textPriceFrom.x = Math.ceil(textCurrency.x + currencySize + 10);
				textPriceFrom.y = Math.ceil(textPrice.y);
			}

		}else{

			textPrice.x = Math.ceil((priceSize + currencySize + 10) * 0.5);
			textCurrency.x = textPrice.x - priceSize - currencySize - 10;
			
				// textPriceFrom.x = Math.ceil(textPrice.x - (priceSize + currencySize + 10) * 0.5);
			if(!textContent.asianText) {
				textPriceFrom.x = Math.ceil(textPrice.x - (priceSize + currencySize + 10) * 0.5);
			}else{
				textPrice.x += -10;
				textCurrency.x += -5;
				textPriceFrom.x = Math.ceil(textPrice.x + 5);
				textPriceFrom.y = Math.ceil(textPrice.y);
			}

		}


		if(isSecondaryFontUsed)
		{
			if(!isOnFirefox)
			{
				textTitle.y -= 2;
				textPriceFrom.y += 1;
				textPrice.y -= 2;
				textCurrency.y -= 2;
			}
			else
			{
				textTitle.y -= 1;
			}
		}

		ScaleElement(textTitle, titleSize + 10);
		ScaleElement(textLine.textPricePrice, priceSize + 5 + currencySize + 10);
		ScaleElement(textAti, atiSize + 10);
	}

	function ScaleElement(element, size)
	{
		element.scaleX = element.scaleY = Math.min(1, (stage.canvas.clientWidth - contentMarge) / size);
	}
}